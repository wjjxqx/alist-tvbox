-- H2 2.4.240; 
;              
CREATE USER IF NOT EXISTS "SA" SALT 'abe9af9165e96c1c' HASH '8a6f2edc64bd889ff60db9d3b0dbfb972b7044917b28aacefe6a7102f3a1390b' ADMIN;          
CREATE CACHED TABLE "PUBLIC"."flyway_schema_history"(
    "installed_rank" INTEGER NOT NULL,
    "version" CHARACTER VARYING(50),
    "description" CHARACTER VARYING(200) NOT NULL,
    "type" CHARACTER VARYING(20) NOT NULL,
    "script" CHARACTER VARYING(1000) NOT NULL,
    "checksum" INTEGER,
    "installed_by" CHARACTER VARYING(100) NOT NULL,
    "installed_on" TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "execution_time" INTEGER NOT NULL,
    "success" BOOLEAN NOT NULL
);           
ALTER TABLE "PUBLIC"."flyway_schema_history" ADD CONSTRAINT "PUBLIC"."flyway_schema_history_pk" PRIMARY KEY("installed_rank"); 
-- 57 +/- SELECT COUNT(*) FROM PUBLIC.flyway_schema_history;   
INSERT INTO "PUBLIC"."flyway_schema_history" VALUES
(-1, NULL, '<< Flyway Schema History table created >>', 'TABLE', '', NULL, 'SA', TIMESTAMP '2026-09-19 19:12:28.721002', 0, TRUE),
(1, '1', 'Create current schema', 'SQL', 'V1__Create_current_schema.sql', -1381866150, 'SA', TIMESTAMP '2026-09-19 19:12:30.087122', 378, TRUE),
(2, '2', 'Normalize reserved columns', 'JDBC', 'db.migration.current.V2__Normalize_reserved_columns', NULL, 'SA', TIMESTAMP '2026-09-19 19:12:30.327673', 74, TRUE),
(3, '3', 'Fix null sort order', 'JDBC', 'db.migration.current.V3__Fix_null_sort_order', NULL, 'SA', TIMESTAMP '2026-09-19 19:12:31.625791', 997, TRUE),
(4, '4', 'fix missing external id', 'SQL', 'V4__fix_missing_external_id.sql', 1009952364, 'SA', TIMESTAMP '2026-09-19 19:12:31.704383', 16, TRUE),
(5, '5', 'dedup users unique username', 'SQL', 'V5__dedup_users_unique_username.sql', 130591887, 'SA', TIMESTAMP '2026-09-19 19:12:31.808683', 78, TRUE),
(6, '6', 'add session login info', 'SQL', 'V6__add_session_login_info.sql', 1381303750, 'SA', TIMESTAMP '2026-09-19 19:12:31.964618', 65, TRUE),
(7, '7', 'widen douban columns', 'SQL', 'V7__widen_douban_columns.sql', 1878110728, 'SA', TIMESTAMP '2026-09-19 19:12:32.028348', 12, TRUE),
(8, '8', 'Normalize enum columns', 'JDBC', 'db.migration.current.V8__Normalize_enum_columns', NULL, 'SA', TIMESTAMP '2026-09-19 19:12:32.229746', 178, TRUE),
(9, '9', 'add share title', 'SQL', 'V9__add_share_title.sql', 1683775923, 'SA', TIMESTAMP '2026-09-19 19:12:32.354998', 23, TRUE),
(10, '10', 'PlaybackSync', 'JDBC', 'db.migration.current.V10__PlaybackSync', NULL, 'SA', TIMESTAMP '2026-09-19 19:12:32.721435', 353, TRUE),
(11, '11', 'PlaybackChangeSequence', 'JDBC', 'db.migration.current.V11__PlaybackChangeSequence', NULL, 'SA', TIMESTAMP '2026-09-19 19:12:32.997886', 213, TRUE),
(12, '12', 'WidenPlaybackVodId', 'JDBC', 'db.migration.current.V12__WidenPlaybackVodId', NULL, 'SA', TIMESTAMP '2026-09-19 19:12:33.096024', 89, TRUE),
(13, '13', 'PlaybackSourceName', 'JDBC', 'db.migration.current.V13__PlaybackSourceName', NULL, 'SA', TIMESTAMP '2026-09-19 19:12:33.185083', 46, TRUE),
(14, '14', 'PlaybackSelectionContext', 'JDBC', 'db.migration.current.V14__PlaybackSelectionContext', NULL, 'SA', TIMESTAMP '2026-09-19 19:12:33.59941', 392, TRUE),
(15, '15', 'PlaybackSyncScope', 'JDBC', 'db.migration.current.V15__PlaybackSyncScope', NULL, 'SA', TIMESTAMP '2026-09-19 19:12:33.873336', 229, TRUE),
(16, '16', 'MigrateLegacyHistory', 'JDBC', 'db.migration.current.V16__MigrateLegacyHistory', NULL, 'SA', TIMESTAMP '2026-09-19 19:12:34.004699', 25, TRUE),
(17, '17', 'FixChangeSequenceWatermark', 'JDBC', 'db.migration.current.V17__FixChangeSequenceWatermark', NULL, 'SA', TIMESTAMP '2026-09-19 19:12:34.048247', 39, TRUE),
(18, '18', 'PlaybackDrivePath', 'JDBC', 'db.migration.current.V18__PlaybackDrivePath', NULL, 'SA', TIMESTAMP '2026-09-19 19:12:34.172876', 65, TRUE),
(19, '19', 'LiveFollow', 'JDBC', 'db.migration.current.V19__LiveFollow', NULL, 'SA', TIMESTAMP '2026-09-19 19:12:34.255502', 36, TRUE),
(20, '20', 'MediaSubscription', 'JDBC', 'db.migration.current.V20__MediaSubscription', NULL, 'SA', TIMESTAMP '2026-09-19 19:12:34.375328', 74, TRUE),
(21, '21', 'MediaSubscriptionMeta', 'JDBC', 'db.migration.current.V21__MediaSubscriptionMeta', NULL, 'SA', TIMESTAMP '2026-09-19 19:12:34.828472', 414, TRUE),
(22, '22', 'MediaSubscriptionMetaFix', 'JDBC', 'db.migration.current.V22__MediaSubscriptionMetaFix', NULL, 'SA', TIMESTAMP '2026-09-19 19:12:34.879587', 46, TRUE),
(23, '23', 'MediaSubscriptionAccounts', 'JDBC', 'db.migration.current.V23__MediaSubscriptionAccounts', NULL, 'SA', TIMESTAMP '2026-09-19 19:12:34.980578', 46, TRUE),
(24, '24', 'MediaSubscriptionBrokenEpisodes', 'JDBC', 'db.migration.current.V24__MediaSubscriptionBrokenEpisodes', NULL, 'SA', TIMESTAMP '2026-09-19 19:12:35.059077', 73, TRUE),
(25, '25', 'MediaSubscriptionSchedule', 'JDBC', 'db.migration.current.V25__MediaSubscriptionSchedule', NULL, 'SA', TIMESTAMP '2026-09-19 19:12:35.36083', 111, TRUE),
(26, '26', 'MediaSubscriptionCrossDrive', 'JDBC', 'db.migration.current.V26__MediaSubscriptionCrossDrive', NULL, 'SA', TIMESTAMP '2026-09-19 19:12:35.516999', 24, TRUE);   
INSERT INTO "PUBLIC"."flyway_schema_history" VALUES
(27, '27', 'MediaSubscriptionAliases', 'JDBC', 'db.migration.current.V27__MediaSubscriptionAliases', NULL, 'SA', TIMESTAMP '2026-09-19 19:12:35.600254', 20, TRUE),
(28, '28', 'MediaSubscriptionMainDrives', 'JDBC', 'db.migration.current.V28__MediaSubscriptionMainDrives', NULL, 'SA', TIMESTAMP '2026-09-19 19:12:35.799829', 103, TRUE),
(29, '29', 'MediaSubscriptionMaxEpisode', 'JDBC', 'db.migration.current.V29__MediaSubscriptionMaxEpisode', NULL, 'SA', TIMESTAMP '2026-09-19 19:12:35.887681', 13, TRUE),
(30, '30', 'MediaSubscriptionEpisodeSource', 'JDBC', 'db.migration.current.V30__MediaSubscriptionEpisodeSource', NULL, 'SA', TIMESTAMP '2026-09-19 19:12:36.255707', 305, TRUE),
(31, '31', 'MediaSubscriptionCover', 'JDBC', 'db.migration.current.V31__MediaSubscriptionCover', NULL, 'SA', TIMESTAMP '2026-09-19 19:12:36.352199', 92, TRUE),
(32, '32', 'MediaMetadata', 'JDBC', 'db.migration.current.V32__MediaMetadata', NULL, 'SA', TIMESTAMP '2026-09-19 19:12:36.405432', 22, TRUE),
(33, '33', 'MediaSubscriptionCaughtUp', 'JDBC', 'db.migration.current.V33__MediaSubscriptionCaughtUp', NULL, 'SA', TIMESTAMP '2026-09-19 19:12:36.496828', 67, TRUE),
(34, '34', 'MediaSubscriptionResourceLinkHash', 'JDBC', 'db.migration.current.V34__MediaSubscriptionResourceLinkHash', NULL, 'SA', TIMESTAMP '2026-09-19 19:12:36.582703', 80, TRUE),
(35, '35', 'MediaSubscriptionResourcePinned', 'JDBC', 'db.migration.current.V35__MediaSubscriptionResourcePinned', NULL, 'SA', TIMESTAMP '2026-09-19 19:12:36.609468', 17, TRUE),
(36, '36', 'MediaSubscriptionNotify', 'JDBC', 'db.migration.current.V36__MediaSubscriptionNotify', NULL, 'SA', TIMESTAMP '2026-09-19 19:12:36.712721', 99, TRUE),
(37, '37', 'AccountOwnership', 'JDBC', 'db.migration.current.V37__AccountOwnership', NULL, 'SA', TIMESTAMP '2026-09-19 19:12:36.989001', 201, TRUE),
(38, '38', 'SubscriptionOwnership', 'JDBC', 'db.migration.current.V38__SubscriptionOwnership', NULL, 'SA', TIMESTAMP '2026-09-19 19:12:37.067448', 74, TRUE),
(39, '39', 'UserVodSecret', 'JDBC', 'db.migration.current.V39__UserVodSecret', NULL, 'SA', TIMESTAMP '2026-09-19 19:12:37.129356', 58, TRUE),
(40, '40', 'PlayUrlOwnership', 'JDBC', 'db.migration.current.V40__PlayUrlOwnership', NULL, 'SA', TIMESTAMP '2026-09-19 19:12:37.169959', 4, TRUE),
(41, '41', 'MediaSubscriptionAirClock', 'JDBC', 'db.migration.current.V41__MediaSubscriptionAirClock', NULL, 'SA', TIMESTAMP '2026-09-19 19:12:37.22184', 47, TRUE),
(42, '42', 'MediaSubscriptionSeasonStart', 'JDBC', 'db.migration.current.V42__MediaSubscriptionSeasonStart', NULL, 'SA', TIMESTAMP '2026-09-19 19:12:37.321024', 40, TRUE),
(43, '43', 'MediaSubscriptionResourceStart', 'JDBC', 'db.migration.current.V43__MediaSubscriptionResourceStart', NULL, 'SA', TIMESTAMP '2026-09-19 19:12:37.386357', 5, TRUE),
(44, '44', 'MediaSubscriptionResourceSeasonStarts', 'JDBC', 'db.migration.current.V44__MediaSubscriptionResourceSeasonStarts', NULL, 'SA', TIMESTAMP '2026-09-19 19:12:37.419793', 18, TRUE),
(45, '45', 'MovieDiffLog', 'JDBC', 'db.migration.current.V45__MovieDiffLog', NULL, 'SA', TIMESTAMP '2026-09-19 19:12:37.479697', 15, TRUE),
(46, '46', 'MediaSubscriptionManualTotal', 'JDBC', 'db.migration.current.V46__MediaSubscriptionManualTotal', NULL, 'SA', TIMESTAMP '2026-09-19 19:12:37.542358', 24, TRUE),
(47, '47', 'MediaSubscriptionResourceFailKind', 'JDBC', 'db.migration.current.V47__MediaSubscriptionResourceFailKind', NULL, 'SA', TIMESTAMP '2026-09-19 19:12:37.625126', 4, TRUE),
(48, '48', 'MediaSubscriptionMagnetOffline', 'JDBC', 'db.migration.current.V48__MediaSubscriptionMagnetOffline', NULL, 'SA', TIMESTAMP '2026-09-19 19:12:37.650109', 15, TRUE),
(49, '49', 'OfflineDownloadTaskMagnetQuota', 'JDBC', 'db.migration.current.V49__OfflineDownloadTaskMagnetQuota', NULL, 'SA', TIMESTAMP '2026-09-19 19:12:37.722738', 68, TRUE),
(50, '50', 'MediaSubscriptionCustomKeywords', 'JDBC', 'db.migration.current.V50__MediaSubscriptionCustomKeywords', NULL, 'SA', TIMESTAMP '2026-09-19 19:12:37.771796', 24, TRUE),
(51, '51', 'MediaSubscriptionAirWeekdays', 'JDBC', 'db.migration.current.V51__MediaSubscriptionAirWeekdays', NULL, 'SA', TIMESTAMP '2026-09-19 19:12:37.849187', 44, TRUE);       
INSERT INTO "PUBLIC"."flyway_schema_history" VALUES
(52, '52', 'MediaSubscriptionEpisodeFallback', 'JDBC', 'db.migration.current.V52__MediaSubscriptionEpisodeFallback', NULL, 'SA', TIMESTAMP '2026-09-19 19:12:37.879961', 11, TRUE),
(53, '53', 'MediaSubscriptionSelfShare', 'JDBC', 'db.migration.current.V53__MediaSubscriptionSelfShare', NULL, 'SA', TIMESTAMP '2026-09-19 19:12:37.927919', 44, TRUE),
(54, '54', 'OfflineDownloadTaskCleanup', 'JDBC', 'db.migration.current.V54__OfflineDownloadTaskCleanup', NULL, 'SA', TIMESTAMP '2026-09-19 19:12:38.085727', 138, TRUE),
(55, '55', 'OfflineDownloadTaskCleanupBackfill', 'JDBC', 'db.migration.current.V55__OfflineDownloadTaskCleanupBackfill', NULL, 'SA', TIMESTAMP '2026-09-19 19:12:38.117263', 28, TRUE),
(56, '56', 'WatchlistItem', 'JDBC', 'db.migration.current.V56__WatchlistItem', NULL, 'SA', TIMESTAMP '2026-09-19 19:12:38.149818', 3, TRUE);  
CREATE INDEX "PUBLIC"."flyway_schema_history_s_idx" ON "PUBLIC"."flyway_schema_history"("success" NULLS FIRST);
CREATE CACHED TABLE "PUBLIC"."ID_GENERATOR"(
    "ENTITY_NAME" CHARACTER VARYING(255) NOT NULL,
    "NEXT_ID" BIGINT
);        
ALTER TABLE "PUBLIC"."ID_GENERATOR" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_1" PRIMARY KEY("ENTITY_NAME");         
-- 24 +/- SELECT COUNT(*) FROM PUBLIC.ID_GENERATOR;            
INSERT INTO "PUBLIC"."ID_GENERATOR" VALUES
('tmdb', 1),
('tmdb_meta', 1),
('site', 2),
('driver_account', 10),
('pan_account', 1),
('pik_pak_account', 1),
('subscription', 8),
('plugin', 1),
('plugin_filter', 1),
('jellyfin', 1),
('emby', 1),
('feiniu', 1),
('navigation', 166),
('index_template', 1),
('config_file', 1),
('device', 1),
('tenant', 1),
('offline_download_task', 1),
('play_url', 915),
('history', 90),
('task', 49),
('meta', 1),
('playback_token', 1),
('playback_tombstone', 31);
CREATE CACHED TABLE "PUBLIC"."ACCOUNT"(
    "ID" INTEGER GENERATED BY DEFAULT AS IDENTITY(START WITH 1 RESTART WITH 33) NOT NULL,
    "ACCESS_TOKEN" CHARACTER VARYING,
    "ACCESS_TOKEN_TIME" TIMESTAMP,
    "AUTO_CHECKIN" BOOLEAN NOT NULL,
    "CHECKIN_DAYS" INTEGER NOT NULL,
    "CHECKIN_TIME" TIMESTAMP,
    "CHUNK_SIZE" INTEGER,
    "CLEAN" BOOLEAN DEFAULT FALSE,
    "CONCURRENCY" INTEGER,
    "MASTER" BOOLEAN DEFAULT FALSE,
    "NICKNAME" CHARACTER VARYING(255),
    "OPEN_ACCESS_TOKEN" CHARACTER VARYING,
    "OPEN_ACCESS_TOKEN_TIME" TIMESTAMP,
    "OPEN_TOKEN" CHARACTER VARYING,
    "OPEN_TOKEN_TIME" TIMESTAMP,
    "REFRESH_TOKEN" CHARACTER VARYING(255),
    "REFRESH_TOKEN_TIME" TIMESTAMP,
    "SHOW_MY_ALI" BOOLEAN NOT NULL,
    "USE_PROXY" BOOLEAN DEFAULT FALSE,
    "OWNER_UID" INTEGER DEFAULT 0 NOT NULL,
    "SHARED" BOOLEAN DEFAULT TRUE NOT NULL
);             
ALTER TABLE "PUBLIC"."ACCOUNT" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_E" PRIMARY KEY("ID");       
-- 1 +/- SELECT COUNT(*) FROM PUBLIC.ACCOUNT;  
INSERT INTO "PUBLIC"."ACCOUNT" VALUES
(1, 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIzZWY5MGQ1NmMxYWM0NmE2OWNkODVhOWZlNmQ1YmVkZCIsImN1c3RvbUpzb24iOiJ7XCJjbGllbnRJZFwiOlwicEpaSW5OSE4yZFpXazhxZ1wiLFwiZG9tYWluSWRcIjpcImJqMjlcIixcInNjb3BlXCI6W1wiRFJJVkUuQUxMXCIsXCJGSUxFLkFMTFwiLFwiVklFVy5BTExcIixcIlNIQVJFLkFMTFwiLFwiU1RPUkFHRS5BTExcIixcIlNUT1JBR0VGSUxFLkxJU1RcIixcIlVTRVIuQUxMXCIsXCJCQVRDSFwiLFwiQUNDT1VOVC5BTExcIixcIklNQUdFLkFMTFwiLFwiSU5WSVRFLkFMTFwiLFwiU1lOQ01BUFBJTkcuTElTVFwiXSxcInJvbGVcIjpcInVzZXJcIixcInJlZlwiOlwiXCIsXCJkZXZpY2VfaWRcIjpcImUwZDQ0NzcwZGExYjQ4OThhZWFjNDdmYjAyMWE5MGI1XCJ9IiwiZXhwIjoxNzg5OTY3MjkyLCJpYXQiOjE3ODk5NjAwMzJ9.X2Ka_HjAAG3XYUIO7zTyFIMiid_SXAMgh6l8Gj0Nsxz8DoWr3P_IX0BpykBHycENB7WPvZD6j4uAKxEq46_cAQETCJfD-N7Glwu2jQngmscaPHH1vVf60bZupjTCUWkRM-FSxW7VBo7xqbzfHH3psvGB5C3ubrpBLbjlyqJ9bSw', TIMESTAMP '2026-09-20 19:45:30.35788', TRUE, 4, TIMESTAMP '2026-09-21 08:59:57.773377', 256, FALSE, 2, TRUE, U&'\6dd8\4e2b\4e2b\54e6', '', TIMESTAMP '2026-09-21 11:08:10.66613', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiIzZWY5MGQ1NmMxYWM0NmE2OWNkODVhOWZlNmQ1YmVkZCIsImF1ZCI6ImI4Yzk5MGU2MGIxODQ0NmViMDdmNWRjYTMwMzk4ZThhIiwiZXhwIjoxNzk3NTg3MTcyLCJpYXQiOjE3ODk4MTExNzIsImp0aSI6IjRkMDIzNzMxMWY2YzQ5MjVhZGFjZTlkNjYzZTUxNTI3In0.K0RZsE3LrZYOS37FLKCGTammu9t6y5ocIbWPgJ4xWZJ9LNJeVS8MawCF1XzcyglQNUxN_XcH8MmNQaYow19oQQ', TIMESTAMP '2026-09-21 11:08:10.666126', 'e3d03640bdd6427d9652ef08af3acfd6', TIMESTAMP '2026-09-21 11:08:11.350991', TRUE, FALSE, 0, TRUE);         
CREATE INDEX "PUBLIC"."IDX_ACCOUNT_NICKNAME" ON "PUBLIC"."ACCOUNT"("NICKNAME" NULLS FIRST);    
CREATE CACHED TABLE "PUBLIC"."ALIST_ALIAS"(
    "ID" INTEGER NOT NULL,
    "CONTENT" CHARACTER VARYING,
    "PATH" CHARACTER VARYING(255)
);   
ALTER TABLE "PUBLIC"."ALIST_ALIAS" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_4A" PRIMARY KEY("ID");  
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.ALIST_ALIAS;              
CREATE CACHED TABLE "PUBLIC"."CONFIG_FILE"(
    "ID" INTEGER NOT NULL,
    "CONTENT" CHARACTER VARYING,
    "DIR" CHARACTER VARYING(255),
    "NAME" CHARACTER VARYING(255),
    "PATH" CHARACTER VARYING(255)
);              
ALTER TABLE "PUBLIC"."CONFIG_FILE" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_8" PRIMARY KEY("ID");   
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.CONFIG_FILE;              
CREATE CACHED TABLE "PUBLIC"."DEVICE"(
    "ID" INTEGER NOT NULL,
    "CONFIG" CHARACTER VARYING,
    "IP" CHARACTER VARYING(255),
    "NAME" CHARACTER VARYING(255),
    "TYPE" INTEGER NOT NULL,
    "UUID" CHARACTER VARYING(255)
);        
ALTER TABLE "PUBLIC"."DEVICE" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_7" PRIMARY KEY("ID");        
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.DEVICE;   
CREATE CACHED TABLE "PUBLIC"."SHARE"(
    "ID" INTEGER NOT NULL,
    "COOKIE" CHARACTER VARYING,
    "FOLDER_ID" CHARACTER VARYING(255),
    "PASSWORD" CHARACTER VARYING(255),
    "PATH" CHARACTER VARYING(255),
    "SHARE_ID" CHARACTER VARYING(255),
    "TEMP" BOOLEAN DEFAULT FALSE,
    "TIME" TIMESTAMP,
    "TYPE" INTEGER,
    "TITLE" CHARACTER VARYING(255)
);    
ALTER TABLE "PUBLIC"."SHARE" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_4B" PRIMARY KEY("ID");        
-- 14 +/- SELECT COUNT(*) FROM PUBLIC.SHARE;   
INSERT INTO "PUBLIC"."SHARE" VALUES
(8003, NULL, '/', 'jdcv', U&'/\6211\7684\767e\5ea6\5206\4eab/temp/baidu@1k12VpyArYB3O9yzQc83NZg@jdcv', '1k12VpyArYB3O9yzQc83NZg', TRUE, TIMESTAMP '2026-09-19 17:53:10.112597', 10, NULL),
(8004, NULL, '0', 'JZMM', U&'/\6211\7684123\5206\4eab/temp/123@IpPUVv-pTDj@JZMM', 'IpPUVv-pTDj', TRUE, TIMESTAMP '2026-09-19 17:53:18.965474', 3, NULL),
(8005, NULL, '', '', U&'/\6211\7684\5929\7ffc\5206\4eab/temp/189@2EZ3aqBZfEjy@', '2EZ3aqBZfEjy', TRUE, TIMESTAMP '2026-09-19 17:53:23.216161', 9, NULL),
(8006, NULL, '/', '932q', U&'/\6211\7684\767e\5ea6\5206\4eab/temp/baidu@1EEgGdvL5yt7rlODuFFtirA@932q', '1EEgGdvL5yt7rlODuFFtirA', TRUE, TIMESTAMP '2026-09-20 16:32:46.612528', 10, NULL),
(8007, NULL, '/', 'gepq', U&'/\6211\7684\767e\5ea6\5206\4eab/temp/baidu@1Z89kbo6qPGEibitcTnrWLA@gepq', '1Z89kbo6qPGEibitcTnrWLA', TRUE, TIMESTAMP '2026-09-20 16:32:56.365666', 10, NULL),
(8008, NULL, '0', '', U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@', '1063180c04f2', TRUE, TIMESTAMP '2026-09-20 16:33:36.584731', 5, NULL),
(8009, NULL, '0', '', U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@', '22026053db534', TRUE, TIMESTAMP '2026-09-20 16:34:07.726976', 7, NULL),
(8010, NULL, '0', '', U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-PQUWv@', 'u9izjv-PQUWv', TRUE, TIMESTAMP '2026-09-20 16:34:35.010572', 3, NULL),
(8011, NULL, 'root', '', U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@', 'QCjSTddJaXb', TRUE, TIMESTAMP '2026-09-20 16:34:50.366755', 0, NULL),
(8012, NULL, 'root', '', U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@uABsSgfqxjv@', 'uABsSgfqxjv', TRUE, TIMESTAMP '2026-09-20 19:46:24.930655', 0, NULL),
(8013, NULL, '0', '', U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@', 'u9izjv-GwuWv', TRUE, TIMESTAMP '2026-09-20 19:45:58.348285', 3, NULL),
(8014, NULL, 'root', '', U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@o2EbwmLSWJf@', 'o2EbwmLSWJf', TRUE, TIMESTAMP '2026-09-20 19:46:33.1304', 0, NULL),
(8015, NULL, '0', '', U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@cbacc0c41819@', 'cbacc0c41819', TRUE, TIMESTAMP '2026-09-20 19:46:48.967127', 5, NULL),
(8016, NULL, '0', '', U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@acdb7a629a8b@', 'acdb7a629a8b', TRUE, TIMESTAMP '2026-09-20 20:04:29.596179', 5, NULL);     
CREATE INDEX "PUBLIC"."IDX_SHARE_TYPE_SHAREID" ON "PUBLIC"."SHARE"("TYPE" NULLS FIRST, "SHARE_ID" NULLS FIRST);
CREATE CACHED TABLE "PUBLIC"."EMBY"(
    "ID" INTEGER NOT NULL,
    "CLIENT_NAME" CHARACTER VARYING(255),
    "CLIENT_VERSION" CHARACTER VARYING(255),
    "DEVICE_ID" CHARACTER VARYING(255),
    "DEVICE_NAME" CHARACTER VARYING(255),
    "ENABLE_IMAGE_PROXY" BOOLEAN DEFAULT FALSE,
    "NAME" CHARACTER VARYING(255),
    "PASSWORD" CHARACTER VARYING(255),
    "SORT_ORDER" INTEGER,
    "URL" CHARACTER VARYING(255),
    "USER_AGENT" CHARACTER VARYING(255),
    "USERNAME" CHARACTER VARYING(255)
);               
ALTER TABLE "PUBLIC"."EMBY" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_2" PRIMARY KEY("ID");          
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.EMBY;     
CREATE CACHED TABLE "PUBLIC"."FEINIU"(
    "ID" INTEGER NOT NULL,
    "NAME" CHARACTER VARYING(255),
    "PASSWORD" CHARACTER VARYING(255),
    "SORT_ORDER" INTEGER,
    "TOKEN" CHARACTER VARYING(255),
    "URL" CHARACTER VARYING(255),
    "USER_AGENT" CHARACTER VARYING(255),
    "USERNAME" CHARACTER VARYING(255)
);  
ALTER TABLE "PUBLIC"."FEINIU" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_7B" PRIMARY KEY("ID");       
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.FEINIU;   
CREATE CACHED TABLE "PUBLIC"."HISTORY"(
    "ID" INTEGER NOT NULL,
    "CID" INTEGER NOT NULL,
    "CREATE_TIME" BIGINT NOT NULL,
    "DURATION" BIGINT NOT NULL,
    "ENDING" BIGINT NOT NULL,
    "EPISODE" INTEGER NOT NULL,
    "EPISODE_URL" CHARACTER VARYING,
    "OPENING" BIGINT NOT NULL,
    "POSITION" BIGINT NOT NULL,
    "REV_PLAY" BOOLEAN NOT NULL,
    "REV_SORT" BOOLEAN NOT NULL,
    "SCALE" INTEGER NOT NULL,
    "SPEED" FLOAT NOT NULL,
    "UID" INTEGER,
    "VOD_FLAG" CHARACTER VARYING(255),
    "VOD_NAME" CHARACTER VARYING(255),
    "VOD_PIC" CHARACTER VARYING(255),
    "VOD_REMARKS" CHARACTER VARYING(255),
    "key" CHARACTER VARYING,
    "SOURCE_KIND" CHARACTER VARYING(255),
    "SOURCE_KEY" CHARACTER VARYING(255),
    "SOURCE_NAME" CHARACTER VARYING(255),
    "VOD_ID" CHARACTER VARYING,
    "UPDATED_AT" BIGINT,
    "CLIENT_KEY" CHARACTER VARYING(64),
    "CHANGE_SEQ" BIGINT,
    "PLAYLIST_INDEX" INTEGER,
    "SOURCE_GROUP_INDEX" INTEGER,
    "SOURCE_INDEX" INTEGER,
    "SOURCE_SUBGROUP_INDEX" INTEGER,
    "SOURCE_SUBGROUP_NAME" CHARACTER VARYING(255),
    "DRIVE_DIR_ID" CHARACTER VARYING,
    "SYNC_SCOPE" CHARACTER VARYING(255),
    "DRIVE_SHARE_KEY" CHARACTER VARYING(255),
    "DRIVE_PATH" CHARACTER VARYING
);    
ALTER TABLE "PUBLIC"."HISTORY" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_62" PRIMARY KEY("ID");      
-- 58 +/- SELECT COUNT(*) FROM PUBLIC.HISTORY; 
INSERT INTO "PUBLIC"."HISTORY" VALUES
(14, 0, 1789815340040, 3155221, 0, 0, '115:swzcho23zh9+z738+2956818097097615899+mkv+1695013660+BAE48C5864735FAD924DC5B9461B76A933F3B9A5', 0, 0, FALSE, FALSE, -1, 1.0, 1, U&'115R\539f\756b', 'Season 1', NULL, U&'[1.58GB] [Season 1] \4e00\628a\9752 - S01E01 - \7b2c1\96c6.mkv', 'AlistShare@@@https://anxia.com/s/swzcho23zh9?cid=2956818097055672858_FN_Season+1_FOLDER&password=z738@@@0', 'site', 'AlistShare', NULL, 'https://anxia.com/s/swzcho23zh9?cid=2956818097055672858_FN_Season+1_FOLDER&password=z738', 1789815340040, NULL, 1789893032116, NULL, NULL, NULL, 114, U&'115R\539f\756b', NULL, NULL, NULL, NULL),
(34, 0, 1789905946105, 1413824, 0, 0, '1@798@0@0', 0, 7197, FALSE, FALSE, -1, 1.0, 1, U&'\7b2c\4e00\5b63', U&'\65f6\5149\4ee3\7406\4eba', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2669131265.webp', U&'\756a\5916\7bc7 \6bd4\6b66\62db\4eb2(986.45 MB)', 'csp_TgWeb@@@https%3A%2F%2Fpan.quark.cn%2Fs%2Facdb7a629a8b@@@0', 'site', 'csp_TgWeb', NULL, 'https%3A%2F%2Fpan.quark.cn%2Fs%2Facdb7a629a8b', 1789905946105, NULL, 1789905929365, NULL, NULL, NULL, NULL, U&'\7b2c\4e00\5b63', NULL, NULL, 'quark@acdb7a629a8b@', U&'/S \65f6\5149\4ee3\7406\4eba/\7b2c\4e00\5b63/\756a\5916\7bc7 \6bd4\6b66\62db\4eb2.mp4'),
(35, 0, 1789906583684, 0, 0, 0, 'http://x.xinsite.top:4566/p/-/0@898', 0, 47979, FALSE, FALSE, -1, 1.0, 1, U&'\7ebf\8def1', U&'\606d\559c\732b\795e\5927\7c89\724c\5b50\ff01\ff01\ff01\ff01', 'http:\u002F\u002Flive-cover.msstatic.com\u002Fhuyalive\u002F1199665096295-1199665096295-5880758174750867456-2399330316046-10057-A-0-1\u002F20260920201258.jpg', U&'\8d85\6e05', 'csp_Live@@@huya$99101@@@0', 'site', 'csp_Live', NULL, 'huya$99101', 1789906583684, NULL, 1789906545495, NULL, NULL, NULL, NULL, U&'\7ebf\8def1', NULL, NULL, NULL, NULL),
(36, 0, 1789906465114, 0, 0, 0, 'http://x.xinsite.top:4566/p/-/0@895', 0, 924, FALSE, FALSE, -1, 1.0, 1, U&'\7ebf\8def1', U&'\62db\4e3b\6301\ff0c\62db\5927\54e5\ff0c\62db\5385\7ba1\5408\4f5c', 'https:\u002F\u002Fanchorpost.msstatic.com\u002Fcdnimage\u002Fanchorpost\u002F1027\u002F5c\u002F9132ffd8ff2789ad7b6910efe4f2d8_4079_1671022739.jpg?spformat=png,webp', U&'\8d85\6e05', 'csp_Live@@@huya$27780060@@@0', 'site', 'csp_Live', NULL, 'huya$27780060', 1789906465114, NULL, 1789906425125, NULL, NULL, NULL, NULL, U&'\7ebf\8def1', NULL, NULL, NULL, NULL),
(37, 0, 1789907499970, 0, 0, 0, 'http://x.xinsite.top:4566/p/-/0@883', 0, 1170, FALSE, FALSE, -1, 1.0, 1, U&'\7ebf\8def1', U&'\8d5a\94b1\4fee\623f\9876', 'https:\u002F\u002Fanchorpost.msstatic.com\u002Fcdnimage\u002Fanchorpost\u002F1022\u002Fbe\u002Fb4ce6e166d3a48045285186e5a2322_1663_1767176330.jpg?spformat=png,webp', U&'\84dd\514910M', 'csp_Live@@@huya$372582@@@0', 'site', 'csp_Live', NULL, 'huya$372582', 1789907499970, NULL, 1789907507720, NULL, NULL, NULL, NULL, U&'\7ebf\8def1', NULL, NULL, NULL, NULL),
(38, 0, 1789906453694, 0, 0, 0, 'http://x.xinsite.top:4566/p/-/0@880', 0, 1305, FALSE, FALSE, -1, 1.0, 1, U&'\7ebf\8def1', U&'\6d59\6c5f177 \84dd\8393 \82cf \671f\5f85\6765\81ea\76f8\9047', 'https:\u002F\u002Fanchorpost.msstatic.com\u002Fcdnimage\u002Fanchorpost\u002F1030\u002Fc1\u002Fd9b72376cbc8fcbef09572cf41c053_1663_1788739742.jpg?spformat=png,webp', U&'\6d41\7545', 'csp_Live@@@huya$342616@@@0', 'site', 'csp_Live', NULL, 'huya$342616', 1789906453694, NULL, 1789906425144, NULL, NULL, NULL, NULL, U&'\7ebf\8def1', NULL, NULL, NULL, NULL),
(39, 0, 1789906449451, 0, 0, 0, 'http://x.xinsite.top:4566/p/-/0@874', 0, 1286, FALSE, FALSE, -1, 1.0, 1, U&'\7ebf\8def1', U&'\5e0c\671b\5927\5bb6\4e0d\8981\62a0\95e8\5566\95e8\4f1a\75bc\\u002F\957f\5e0526\51a0', 'https:\u002F\u002Fanchorpost.msstatic.com\u002Fcdnimage\u002Fanchorpost\u002F1004\u002Fc2\u002Fdd02cfde911e20b7959b3a526bc1d0_4079_1785722127.jpg?spformat=png,webp', U&'\8d85\6e05', 'csp_Live@@@huya$168212@@@0', 'site', 'csp_Live', NULL, 'huya$168212', 1789906449451, NULL, 1789906425148, NULL, NULL, NULL, NULL, U&'\7ebf\8def1', NULL, NULL, NULL, NULL),
(40, 0, 1789906446404, 0, 0, 0, 'http://x.xinsite.top:4566/p/-/0@868', 0, 790, FALSE, FALSE, -1, 1.0, 1, U&'\7ebf\8def1', U&'\864e\7259\5e74\5ea6\76db\5178-18-116', 'http:\u002F\u002Flive-cover.msstatic.com\u002Fhuyalive\u002F1677942375-1677942375-7206707625197568000-3356008206-10057-A-0-1-imgplus\u002F20260920201218.jpg', U&'\8d85\6e05', 'csp_Live@@@huya$18@@@0', 'site', 'csp_Live', NULL, 'huya$18', 1789906446404, NULL, 1789906425151, NULL, NULL, NULL, NULL, U&'\7ebf\8def1', NULL, NULL, NULL, NULL);     
INSERT INTO "PUBLIC"."HISTORY" VALUES
(41, 0, 1789906440733, 0, 0, 0, 'http://x.xinsite.top:4566/p/-/0@862', 0, 1129, FALSE, FALSE, -1, 1.0, 1, U&'\7ebf\8def1', U&'\8fdb\6765\9886\8001\5a46\ff01798-1995-233', 'https:\u002F\u002Fanchorpost.msstatic.com\u002Fcdnimage\u002Fanchorpost\u002F1039\u002Fb2\u002Ff7a27be6dec5ca5c36fc1f5a71eec5_4079_1783395392.jpg?spformat=png,webp', U&'\8d85\6e05', 'csp_Live@@@huya$6952@@@0', 'site', 'csp_Live', NULL, 'huya$6952', 1789906440733, NULL, 1789906425155, NULL, NULL, NULL, NULL, U&'\7ebf\8def1', NULL, NULL, NULL, NULL),
(42, 0, 1789906435682, 0, 0, 0, 'http://x.xinsite.top:4566/p/-/0@850', 0, 1496, FALSE, FALSE, -1, 1.0, 1, U&'\7ebf\8def1', U&'\4eca\5929\559d\70b9\767d\7684', 'https:\u002F\u002Fanchorpost.msstatic.com\u002Fcdnimage\u002Fanchorpost\u002F1006\u002Ff4\u002F7bac209155c6f8a2f51e6d1594f6ca_1663_1789545062.jpg?spformat=png,webp', U&'\84dd\51498M', 'csp_Live@@@huya$520228@@@0', 'site', 'csp_Live', NULL, 'huya$520228', 1789906435682, NULL, 1789906425158, NULL, NULL, NULL, NULL, U&'\7ebf\8def1', NULL, NULL, NULL, NULL),
(43, 0, 1789906429486, 0, 0, 0, 'http://x.xinsite.top:4566/p/-/0@841', 0, 960, FALSE, FALSE, -1, 1.0, 1, U&'\7ebf\8def1', U&'\7231\4e0a\6211\50cf\547c\5438\4e00\6837\7b80\5355', 'https:\u002F\u002Fanchorpost.msstatic.com\u002Fcdnimage\u002Fanchorpost\u002F1032\u002F07\u002F52e2c776a28406363b193caec9bac3_4079_1778740020.jpg?spformat=png,webp', U&'\84dd\51494M', 'csp_Live@@@huya$52647@@@0', 'site', 'csp_Live', NULL, 'huya$52647', 1789906429486, NULL, 1789906425162, NULL, NULL, NULL, NULL, U&'\7ebf\8def1', NULL, NULL, NULL, NULL),
(44, 0, 1789906597730, 0, 0, 0, 'http://x.xinsite.top:4566/p/-/0@904', 0, 1726, FALSE, FALSE, -1, 1.0, 1, U&'\7ebf\8def1', U&'\3010\6210\90fd\3011\6211\4eec\662f\4e0d\662f\5728\54ea\89c1\8fc7[\5b9d]', 'https:\u002F\u002Fanchorpost.msstatic.com\u002Fcdnimage\u002Fanchorpost\u002F1056\u002Fc6\u002F787c496ffc106254b49c9f9e530c08_1663_1749380463.jpg?spformat=png,webp', U&'\84dd\51498M', 'csp_Live@@@huya$137492@@@0', 'site', 'csp_Live', NULL, 'huya$137492', 1789906597730, NULL, 1789906605719, NULL, NULL, NULL, NULL, U&'\7ebf\8def1', NULL, NULL, NULL, NULL),
(45, 0, 1789906769537, 0, 0, 0, 'http://pull-flv-t95.douyincdn.com/stage/stream-696579258367607607_or4.flv?expire=1790511520&sign=d71330f4b27eee3369405d87534cc8eb&arch_hrchy=w1&exp_hrchy=w1&major_anchor_level=common&unique_id=stream-696579258367607607_823_flv_or4&t_id=037-20260920201839729314225495317A4B00-16u2Zc', 0, 1042, FALSE, FALSE, -1, 1.0, 1, 'FLV', U&'\+01f338\968f\7f18\+01f497\5728\76f4\64ad', NULL, U&'\6807\6e05', 'csp_Live@@@douyin$958511082994@@@0', 'site', 'csp_Live', NULL, 'douyin$958511082994', 1789906769537, NULL, 1789906726059, NULL, NULL, NULL, NULL, 'FLV', NULL, NULL, NULL, NULL),
(46, 0, 1789906765435, 0, 0, 0, 'http://pull-flv-t11.douyincdn.com/stage/stream-696579258555302711_or4.flv?expire=1790511515&sign=5e34639cbbe90b73c65fbaaf54bf66b2&arch_hrchy=w1&exp_hrchy=w1&major_anchor_level=common&unique_id=stream-696579258555302711_823_flv_or4&t_id=037-202609202018353F20620E5BE4538F669D-gKb09w', 0, 982, FALSE, FALSE, -1, 1.0, 1, 'FLV', U&'\6b22\8fce\5927\5bb6\8d70\8fdb\76f4\64ad\95f4\ff5e', NULL, U&'\8d85\6e05', 'csp_Live@@@douyin$272001974292@@@0', 'site', 'csp_Live', NULL, 'douyin$272001974292', 1789906765435, NULL, 1789906726086, NULL, NULL, NULL, NULL, 'FLV', NULL, NULL, NULL, NULL),
(47, 0, 1789906760668, 0, 0, 0, 'http://pull-hs-f5.flive.douyincdn.com/stage/stream-408348882279858858_or4.flv?expire=1790511498&sign=466a6de553abcda5a67324ce678964ac&volcSecret=466a6de553abcda5a67324ce678964ac&volcTime=1790511498&exp_hrchy=w1&arch_hrchy=w1&major_anchor_level=common&unique_id=stream-408348882279858858_682_flv_or4&t_id=037-2026092020181724E077D4F94D95E9F65A-wlI5Y4', 0, 2322, FALSE, FALSE, -1, 1.0, 1, 'FLV', U&'\7b49\4e2a\540c\9891\7684\4eba\6bd4\767b\5929\8fd8\96be\ff01\ff01\ff01', NULL, U&'\84dd\5149', 'csp_Live@@@douyin$689197835329@@@0', 'site', 'csp_Live', NULL, 'douyin$689197835329', 1789906760668, NULL, 1789906726102, NULL, NULL, NULL, NULL, 'FLV', NULL, NULL, NULL, NULL),
(48, 0, 1789906737417, 0, 0, 0, 'http://pull-t5.douyincdn.com/thirdgame/stream-408348867239084859_uhd.flv?expire=1790511488&sign=d3984015570f12dbc0f63d77ccd0718e&volcSecret=d3984015570f12dbc0f63d77ccd0718e&volcTime=1790511488&major_anchor_level=common&arch_hrchy=h1&exp_hrchy=h2&unique_id=stream-408348867239084859_827_flv_uhd&t_id=037-2026092020180779829F7F2CB1CBD1007D-Wl1mh4', 0, 399, FALSE, FALSE, -1, 1.0, 1, 'FLV', U&'\5b9d\513f\6b63\5728\76f4\64ad', NULL, U&'\84dd\5149', 'csp_Live@@@douyin$166006779011@@@0', 'site', 'csp_Live', NULL, 'douyin$166006779011', 1789906737417, NULL, 1789906726106, NULL, NULL, NULL, NULL, 'FLV', NULL, NULL, NULL, NULL);             
INSERT INTO "PUBLIC"."HISTORY" VALUES
(49, 0, 1789906728085, 0, 0, 0, 'https://tx-origin.pull.yximgs.com/gifshow/oNe1-plycgI_GameAvcFhdL3.flv?txSecret=d1238d30af4239b2db8cbec2b7ba54a0&txTime=6ab12076&stat=8JJJDgC3S6p%2B37gPpnQmRFx0TofIzCNsrFGgu1sMB%2F6h%2Fp6UyRXTySV%2By2ksv%2FJP&tsc=origin&oidc=edgeWm&sidc=203562&no_script=1&ss=s20&tfc_buyer=0', 0, 735, FALSE, FALSE, -1, 1.0, 1, U&'\539f\753b', U&'\5927\8bdd\897f\6e38\6000\65e7', 'https://live2.static.yximgs.com/live/game/screenshot/oNe1-plycgI~1789906675381~1.jpg', U&'\84dd\5149 \8d28\81fb', 'csp_Live@@@ks$V-18337348789@@@0', 'site', 'csp_Live', NULL, 'ks$V-18337348789', 1789906728085, NULL, 1789906726114, NULL, NULL, NULL, NULL, U&'\539f\753b', NULL, NULL, NULL, NULL),
(50, 0, 1789906775761, 0, 0, 0, 'http://pull-flv-l95.douyincdn.com/stage/stream-408348881602216608_or4.flv?expire=1790511523&sign=a1263d6912091eb06c4d9faa6f352d7b&major_anchor_level=common&arch_hrchy=w1&exp_hrchy=w1&unique_id=stream-408348881602216608_672_flv_or4&t_id=037-20260920201843B3D26EF953A69388930E-1RYxyd', 0, 951, FALSE, FALSE, -1, 1.0, 1, 'FLV', U&'\8c01\613f\610f\5a36\4f60\56de\5bb6', NULL, U&'\84dd\5149', 'csp_Live@@@douyin$159692111744@@@0', 'site', 'csp_Live', NULL, 'douyin$159692111744', 1789906775761, NULL, 1789906786284, NULL, NULL, NULL, NULL, 'FLV', NULL, NULL, NULL, NULL),
(51, 0, 1789906885403, 0, 0, 0, 'http://pull-flv-gravity-t11.douyincdn.com/third/stream-408348807780893498_or4.flv?expire=1790511634&sign=8cacf3e9ebfe4400b1467d90cc95f521&exp_hrchy=w1&major_anchor_level=common&arch_hrchy=w1&unique_id=stream-408348807780893498_826_flv_or4&t_id=037-20260920202034CDB246A5BB2B6A0113D9-pniOmY', 0, 579, FALSE, FALSE, -1, 1.0, 1, 'FLV', U&'\4e03\6708\7684\98ce\6b63\5728\76f4\64ad', 'https://p11-webcast.douyinpic.com/img/aweme-avatar/tos-cn-avt-0015_5817f6d5d9c496680cde7b3a8ea8dd85~tplv-resize:0:0.image?biz_tag=app_6383_webcast&from=webcast.room.pack&l=20260920202034CDB246A5BB2B6A0113D9&s=enter_room&sc=webcast_cover', U&'\84dd\5149', 'csp_Live@@@douyin$162699784646@@@0', 'site', 'csp_Live', NULL, 'douyin$162699784646', 1789906885403, NULL, 1789906846439, NULL, NULL, NULL, NULL, 'FLV', NULL, NULL, NULL, NULL),
(52, 0, 1789906878431, 0, 0, 0, 'http://pull-flv-c11.douyincdn.com/stage/stream-696579184407609815.flv?expire=1790511626&sign=c6002568dd78a2989e5956bd713258a5&exp_hrchy=c1&major_anchor_level=common&arch_hrchy=c1&unique_id=stream-696579184407609815_471_flv&t_id=037-2026092020202554A02D36F38E24333778-FSphqf', 0, 3622, FALSE, FALSE, -1, 1.0, 1, 'FLV', U&'\751c\871c\871c\6b63\5728\76f4\64ad', 'https://p3-webcast.douyinpic.com/img/aweme-avatar/tos-cn-i-0813c000-ce_owArAff3DECqFAJARTEy8BEZkCoIy6CwqG9tmA~tplv-resize:0:0.image?biz_tag=app_6383_webcast&from=webcast.room.pack&l=2026092020202554A02D36F38E24333778&s=enter_room&sc=webcast_cover', U&'\9ad8\6e05', 'csp_Live@@@douyin$3989311096@@@0', 'site', 'csp_Live', NULL, 'douyin$3989311096', 1789906878431, NULL, 1789906846457, NULL, NULL, NULL, NULL, 'FLV', NULL, NULL, NULL, NULL),
(53, 0, 1789906953289, 0, 0, 0, 'http://pull-flv-l13.douyincdn.com/stage/stream-408348637589406136_or4.flv?expire=1790511703&sign=e8755fd9965ce52af9055ed2dcc57b09&exp_hrchy=c1&major_anchor_level=common&arch_hrchy=c1&unique_id=stream-408348637589406136_440_flv_or4&t_id=037-20260920202142F263AACE862C087CBE62-ggVEK5', 0, 1431, FALSE, FALSE, -1, 1.0, 1, 'FLV', U&'\4f60\966a\6211\4e00\7a0b\ff0c\6211\5ff5\4f60\4e00\751f\2026\2026', NULL, U&'\8d85\6e05', 'csp_Live@@@douyin$536252913895@@@0', 'site', 'csp_Live', NULL, 'douyin$536252913895', 1789906953289, NULL, 1789906906571, NULL, NULL, NULL, NULL, 'FLV', NULL, NULL, NULL, NULL),
(54, 0, 1789906948236, 0, 0, 0, 'http://pull-flv-l11.douyincdn.com/third/stream-408348638597611996_or4.flv?expire=1790511691&sign=ab46f27a6dab965c52ff579baa5a25a4&arch_hrchy=w1&exp_hrchy=w1&major_anchor_level=common&unique_id=stream-408348638597611996_476_flv_or4&t_id=037-20260920202129561B552F6B0B84718625-hW6LcZ', 0, 4968, FALSE, FALSE, -1, 1.0, 1, 'FLV', U&'\537f\537f\5fae\7b11\+01f399\fe0f\6b63\5728\76f4\64ad', NULL, U&'\84dd\5149', 'csp_Live@@@douyin$2426181604@@@0', 'site', 'csp_Live', NULL, 'douyin$2426181604', 1789906948236, NULL, 1789906906574, NULL, NULL, NULL, NULL, 'FLV', NULL, NULL, NULL, NULL);               
INSERT INTO "PUBLIC"."HISTORY" VALUES
(55, 0, 1789906936208, 0, 0, 0, 'http://pull-flv-l26.douyincdn.com/stage/stream-120118262913564811_or4.flv?expire=6ab90a46&sign=f5219ded6f12a8255b26f6c61c0560af&arch_hrchy=w1&exp_hrchy=w1&major_anchor_level=common&unique_id=stream-120118262913564811_139_flv_or4&t_id=037-20260920202125EEFDE436DDFA983D7598-H2QdF0', 0, 794, FALSE, FALSE, -1, 1.0, 1, 'FLV', U&'\8d5a\94b1\4f9b\59b9\59b9\4e0a\5927\5b66', NULL, U&'\84dd\5149', 'csp_Live@@@douyin$837578970937@@@0', 'site', 'csp_Live', NULL, 'douyin$837578970937', 1789906936208, NULL, 1789906906577, NULL, NULL, NULL, NULL, 'FLV', NULL, NULL, NULL, NULL),
(56, 0, 1789906931152, 0, 0, 0, 'http://pull-hs-f5.flive.douyincdn.com/stage/stream-120118268355674794_or4.flv?expire=1790511681&sign=6790f4dbcc13fcee6aefe06a29b7556e&volcSecret=6790f4dbcc13fcee6aefe06a29b7556e&volcTime=1790511681&exp_hrchy=w1&arch_hrchy=w1&major_anchor_level=common&unique_id=stream-120118268355674794_682_flv_or4&t_id=037-20260920202121D7B99D0C9A0C5F70CD76-s0vGU2', 0, 475, FALSE, FALSE, -1, 1.0, 1, 'FLV', U&'CHEN\6b63\5728\76f4\64ad', NULL, U&'\84dd\5149', 'csp_Live@@@douyin$476991750515@@@0', 'site', 'csp_Live', NULL, 'douyin$476991750515', 1789906931152, NULL, 1789906906580, NULL, NULL, NULL, NULL, 'FLV', NULL, NULL, NULL, NULL),
(57, 0, 1789906925642, 0, 0, 0, 'http://pull-flv-c11.douyincdn.com/stage/stream-696579023544517079_or4.flv?expire=1790511675&sign=39a90e079847079bf88583fad088860e&arch_hrchy=c1&exp_hrchy=c1&major_anchor_level=common&unique_id=stream-696579023544517079_471_flv_or4&t_id=037-2026092020211473D8CB94845B6B9331DB-QBeRmB', 0, 1165, FALSE, FALSE, -1, 1.0, 1, 'FLV', U&'\8fdb\6765\77a7\77a7\76f4\64ad\95f4\5728\5e72\5565\ff5e', NULL, U&'\8d85\6e05', 'csp_Live@@@douyin$741215865107@@@0', 'site', 'csp_Live', NULL, 'douyin$741215865107', 1789906925642, NULL, 1789906906583, NULL, NULL, NULL, NULL, 'FLV', NULL, NULL, NULL, NULL),
(58, 0, 1789906915943, 0, 0, 0, 'http://pull-flv-t95.douyincdn.com/stage/stream-696578914621588279_or4.flv?expire=1790511665&sign=4697a276bc90eaf76bd7b3286d73d54f&major_anchor_level=common&arch_hrchy=w1&exp_hrchy=w1&unique_id=stream-696578914621588279_823_flv_or4&t_id=037-20260920202104F817E5F0DA85128EB61F-9RJZ7H', 0, 1046, FALSE, FALSE, -1, 1.0, 1, 'FLV', U&'\5149\5934\6c6a\54e5\6b63\5728\76f4\64ad', NULL, U&'\6807\6e05', 'csp_Live@@@douyin$774700481844@@@0', 'site', 'csp_Live', NULL, 'douyin$774700481844', 1789906915943, NULL, 1789906906589, NULL, NULL, NULL, NULL, 'FLV', NULL, NULL, NULL, NULL),
(59, 0, 1789906902850, 0, 0, 0, 'http://pull-flv-l11.douyincdn.com/stage/stream-696579046039879825_or4.flv?expire=1790511642&sign=c1343b1418c778eb640b80c7d5d9fb9c&arch_hrchy=w1&exp_hrchy=w1&major_anchor_level=common&unique_id=stream-696579046039879825_145_flv_or4&t_id=037-2026092020204229E2709C3D235E162269-LYwgIx', 0, 6032, FALSE, FALSE, -1, 1.0, 1, 'FLV', U&'\8bbe\8ba1\5e08\52c7\95ef\76f4\64ad\754c\5440', NULL, U&'\84dd\5149', 'csp_Live@@@douyin$833849379239@@@0', 'site', 'csp_Live', NULL, 'douyin$833849379239', 1789906902850, NULL, 1789906906599, NULL, NULL, NULL, NULL, 'FLV', NULL, NULL, NULL, NULL),
(60, 0, 1789906974623, 0, 0, 0, 'http://pull-flv-l6.douyincdn.com/stage/stream-408348685310099487_or4.flv?k=b4ba2ab43a86bcd0&t=1790511718&arch_hrchy=w1&exp_hrchy=w1&major_anchor_level=common&unique_id=stream-408348685310099487_31_flv_or4&t_id=037-20260920202157F452811817F7E12E3D04-PKib4A', 0, 7655, FALSE, FALSE, -1, 1.0, 1, 'FLV', U&'\5b55\665a\671f', NULL, U&'\8d85\6e05', 'csp_Live@@@douyin$935931591734@@@0', 'site', 'csp_Live', NULL, 'douyin$935931591734', 1789906974623, NULL, 1789906966687, NULL, NULL, NULL, NULL, 'FLV', NULL, NULL, NULL, NULL),
(61, 0, 1789906961734, 0, 0, 0, 'http://pull-flv-l11.douyincdn.com/stage/stream-408348568335941777_or4.flv?expire=1790511711&sign=104dfa4916b99ec0862fdcbcac4caa77&exp_hrchy=w1&arch_hrchy=w1&major_anchor_level=common&unique_id=stream-408348568335941777_145_flv_or4&t_id=037-20260920202151E33AE4B22903EE2D3020-akCaZ1', 0, 728, FALSE, FALSE, -1, 1.0, 1, 'FLV', U&'\+01f340\5c0f\8bed\+01f340\6b63\5728\76f4\64ad', NULL, U&'\8d85\6e05', 'csp_Live@@@douyin$617852409143@@@0', 'site', 'csp_Live', NULL, 'douyin$617852409143', 1789906961734, NULL, 1789906966700, NULL, NULL, NULL, NULL, 'FLV', NULL, NULL, NULL, NULL);  
INSERT INTO "PUBLIC"."HISTORY" VALUES
(62, 0, 1789907157291, 2796840, 0, 0, 'https://vod1.maowushi.com/20260911/92PQbCFu/index.m3u8', 0, 1822, FALSE, FALSE, -1, 1.0, 1, '360zy', U&'\5170\9999\5982\6545', 'https://www.imgzy360.com:7788/upload/vod/20260911-1/b11792938a04ae2cda178d64e59e9eb2.webp', U&'\7b2c01\96c6', '360@@@105464@@@0', 'site', '360', NULL, '105464', 1789907157291, NULL, 1789907146984, NULL, NULL, NULL, 359, '360zy', NULL, NULL, NULL, NULL),
(63, 0, 1789907249719, 28000, 0, 0, 'https://euw13.playlist.ttvnw.net/v1/playlist/CqkFpSDsL9_ZPWIPbqnJXWiaXwaG0T352X2qFDDu5Z8Rgj2N_XR2ZsTDHFFfYmdm8JzbKyQn41TerQ_JtyL3axQfzKiG4j3HlYWLszuOeW-nVLtFR9qEPr78LRYbplyMU3oZ-mW0pwsD25boDLu49x0l06d6Dwrr3CcN09AcAVAfXWHdx50EQXK3kT2cUyEMxQOMLKx0hS9ueMLWh66hBehS12sKZl3AU_59dHA3txR4d2JRwP0QBIOSzIGgN1ewra4koOUbRJSBG5ruHQ692FXrHLKeaUmvkFOUsHrbAr798wCP1mCOPPD1mVfRRM3TNbGff4UFrgOdHbxsW1RfceG3tzDuFgyERCbyNSSzMLswJKdbCF636hvW0dHZc9mb1pu1Inah3T1h4dl08WazHidLi9WELSLnR_rT5kZYzZOkAF7IgGWAwakCdR606TrCsT_J6KRcV0r8QrOeyWR1i1mGKCs4ZhvRihAl5c6SPbsIzzcE0AGreDr2N5oeLl5_1fBS3RpfERjVUZuu3FiLejp-8UpHCYjv_K6lXUGgoXYw1zu1SVNBpW5aLGBYBhDdsi2nqzJPJx5oxQE4iGNd7s1gqYw9SwwZDssn8IqVYdGK3IZ4cRCRKUswy1ogwxhvF1m_YEKDrl0BqWTrLzHg7_9lOIlqEISJTd1Grqcw7QH8_W_9LOgPC3hx5yOG23Sow6ChkG-jLIYLSfeFFmvbU597jLpxWHQ5Azb1D-DexP4FDWdnRr5YmJodJdCLOzoDWb710jqLn1KvfFIrQLs-OVqnw-PungmXW8Ck2XA-2qUmPrs0dE_IFCYtLlVnI2m8x2s9fsZJOaO0ZFdj35EVSiolcVWQbXUAOcdtkD-nL4KT0BPKGJAocRiNJPruCzfb585jBEqZCCH4NRCgGgxuljA0-gqGXY4xMZsgASoJZXUtd2VzdC0yMJEQ.m3u8', 0, 3923, FALSE, FALSE, -1, 1.0, 1, U&'\7ebf\8def1', U&'\+01f37a\+01f338 OKTOBERFEST OHNE OKTOBERFEST \+01f62d\+01f338 || \2757gaming \2757holy \2757plan || @Kunshikitty', 'https://static-cdn.jtvnw.net/jtv_user_pictures/5ce7fde5-b3b1-48e9-a424-bda943765612-profile_image-70x70.png', U&'\539f\753b', 'csp_Live@@@twitch$kunshikitty@@@0', 'site', 'csp_Live', NULL, 'twitch$kunshikitty', 1789907249719, NULL, 1789907207061, NULL, NULL, NULL, NULL, U&'\7ebf\8def1', NULL, NULL, NULL, NULL),
(64, 0, 1789907203097, 3211720, 0, 0, 'https://vod1.maowushi.com/20260910/LaeKDCs3/index.m3u8', 0, 1418, FALSE, FALSE, -1, 1.0, 1, '360zy', U&'\51ac\57ce\730e\51f6', 'https://www.imgzy360.com:7788/upload/vod/20260910-1/c5adbb56d107eedbc54970114089b9aa.webp', U&'\7b2c01\96c6', 'xinsite2@@@382991@@@0', 'site', 'xinsite2', NULL, '382991', 1789907203097, NULL, 1789907207065, NULL, NULL, NULL, 359, '360zy', NULL, NULL, NULL, NULL),
(65, 0, 1789907310501, 28000, 0, 0, 'https://euw11.playlist.ttvnw.net/v1/playlist/CoUFx75y8lV-PR91oh4Bu-ZSO94ptVyR6mdbMvuqsUjW5FESTmUe-w9jFoPtQ_FTtpI1ovN9x68wa5B8mxROWCwgeAKS9tYyB8oEweSW6RdaNO3hP5BtMEsxtVsIrcEcagYCZKGqgWMMqSGLazWqQLuw-OvGVi0fokpp6bvotAD64OrmEdnmD8GpOXOsa30k95pswOIzlpMEwVLGeclssx8PmQPT9UPWkGex5peivpBBiXvuKrJfcMtzBGQm6wpE6Lm9o_oyLtCRGlT6DIFNzsR5L8O2ejBqfAqflBhQgjT44n0Ri0vGu-Gops7MU50RXBd3vYrElckMEfvLWQJbkdGC3XuiWbmVzitBZ_bWMbJOcZq0js5xx4iQy7nsxX9eD1HbzjXMy6Ymz2HLw8unhYIWljmtcTAoHaaoi8B5phZFqFKdVVXjMv2etw--AEDWPpYkYoj9jQJ_qW5xsmE5Iprpz9LOS_wd2PAjOexDmJwY1-K0iZQlXjAa4dQNfyrv8mcbrDL2AzhAhetGwSbtdDNStTvNSLgvEmyJMVer1ynxczt44UJzKAR1Ei1dTZKb-1euAIcoqhmQaDvVrgIZjm65XzFYS4y7VYB9tm3rZDFA9hfE41EnDXINVmcfIZnQreuF7kS7wU_dX9Eq9QJ9CvHzWBeU4xu-Tr5arCjkigRoPctk4cvSsHL6nbQ7PPcZOvkg0MjGGHYhjlG9TpvZR9RsQ2YHeE6d16_g3xt4TgYouxPTjzy3DZmYu3bZtvgis0oEdUwynk0cFbyyodVYlKju09xLLyyRCYzk88h6tulXOFVNZ0Sapc9jpvD1ZddRF6wuOH9G_2c7DwMrulb3P1cc5p4wj3bjGgxUD3wGk8jU8TGvXPAgASoJZXUtd2VzdC0yMJEQ.m3u8', 0, 8559, FALSE, FALSE, -1, 1.0, 1, U&'\7ebf\8def1', U&'\+01f493 EARLY GYM MIT EUCH \+01f6a8 WINTER ARC WIRD DURCHGEZOGEN \+01f493 !Socials !Clips !WG', 'https://static-cdn.jtvnw.net/jtv_user_pictures/e50e2c6a-c7f8-488e-b1cf-791352ed513a-profile_image-70x70.png', '480p30', 'csp_Live@@@twitch$mialiliaa@@@0', 'site', 'csp_Live', NULL, 'twitch$mialiliaa', 1789907310501, NULL, 1789907267169, NULL, NULL, NULL, NULL, U&'\7ebf\8def1', NULL, NULL, NULL, NULL),
(66, 0, 1789907276117, 10010, 0, 0, 'https://euw11.playlist.ttvnw.net/v1/playlist/Co0F6XN2o81TbXMyQwhR8FFMNl1ufdHLgbJxzv-AXnYYR7vwIYhAffCmmVtNNPA5LipTBKUhuaA_IOp0by1laJb4a95fweX0lwDOz37202fIcvN0yT9ZWJfOaLGsRQbNFElAlo51X41eY9uwR6fIgy8pgwUctcJLvGdNx335PZrJ0AwZgOCkJuAShHen5j0kN4ueKzrL7HF4K5ccPNQV2xl6g4eJoEiaQ48nL4nYvzKCHDX-6AMP4zoRJim9sSGVCJbQR7qPZOrOkMCPWa__PWhct1tTiXoO5iiR_5WWSs18rkywnMsRfivU-gvKNYKckMIB3CI3OfunBMGzcnMkoX6omkXZVBEEEnAzYnVPn_O37UzC29k30YHnlw9jOFbzZ5Ekgamkkj8O_2jxXbLt7wBG0hULKO2Pf2eP9t9QVaW4izJuQCGP7koKl0s529Dm2RR7TbrAUL9uOIOJ3sK57uGWBxqy6aMDc8RStOKfpIN3FUci_m9S6lBEAgWLZtq8IiSYwSbTYeArg2uIQEyscBAVuQ3V6kwxBqx5R3YwyapOJmakDX9Z63aIrArUpICM3TKLYBYQq5SrtT35n1PnCquLqBRk0r-7S2JTpC4fJxQ9XhpbVOEyK5H3DOhUqeQtxq91N0zlozwjyMlVJCfKiU1tUEz_mK8LWHW95UxmwQzldXvmL72ljvdpzU_A6kqCTr3WJxWNGmoUTxbm2OJaGpLnCpYhxMUQNF2HVvlw_yRqgH6UQfRYF_yPTfWwwxfft0oGBiYGUCemFL1YPwRT0jiDug90kCzTAOkSY1dpkSSi92i32Ea5dkw2IEDEfMF6CI7YKVrlYJ1BfWWK49p2p9NnUckxuG3LVM8ee8vzoL4aDMK4mlkKrS0jNqF_XSABKglldS13ZXN0LTIwkRA.m3u8', 0, 1880, FALSE, FALSE, -1, 1.0, 1, U&'\7ebf\8def1', U&'\+01f351 sol y playa en rr, nos vemos ma\00f1ana', 'https://static-cdn.jtvnw.net/jtv_user_pictures/0d6e9106-d9fa-4b13-8fd0-b5282ac7e7a5-profile_image-70x70.png', '480p30', 'csp_Live@@@twitch$gonsabellla@@@0', 'site', 'csp_Live', NULL, 'twitch$gonsabellla', 1789907276117, NULL, 1789907267180, NULL, NULL, NULL, NULL, U&'\7ebf\8def1', NULL, NULL, NULL, NULL);          
INSERT INTO "PUBLIC"."HISTORY" VALUES
(67, 0, 1789907393348, 29633, 0, 0, 'https://euw12.playlist.ttvnw.net/v1/playlist/CpsF7_ifhFiNunYTP9-0Cf-dNnoDHlNrKI0LHfADaz8ruafoC1z3kxj-_ZngGAdGlcxQ2kJosYanLxweimzvnQsM95F8BJv_zQRhtw5QA1S4M4AEkjdaCQx4pEt0Bd5CTrbVXlOvjpbtr-WTHxk3ybg8DULvFXv3xzbqA528rYXR1HoCIN9CweoEZICd8sZ7LCg6GhMtfGM0FYX4PJSS4OFv61u9xVnUl4XRmATM6i7yc8z7hVJ9Rw5MkTqt-mgXkHAQu5L3TO7SucFBjA5OEDuyGy1VCisfudegut9lbzmd-fyXWtsCQW3pzrBbwgILpN8tZ4nIEi4YAlFWUg-id2iZb8hTmGpQPFJeNsp-nmaX3Encg_kd_lQg1G2rUQi8mPPkKXIr4BOEfDnYH_IR-TtGg5804zag0KyufZInothiptNBscsIrmHO_PeFvtlG6vlAPUZdOqX1OL7IYk33pUj6GrH0fwE8EHh7Z2oKhJXOuO759wmOTiwtXdEiyWbcjTRpVO4UDHDw_nvN9eT8FkR8B9VS4ngE8ej00nKSrgXdBU_Jy39rQUwwbQ4N_Oc5ibFdnYh8Cz2sxCoB8eZ5pJin8EfZrV7voTaiW09tcN49TmhGPaO3ZxYTn_158uEFriJe9zDp-XWSjW9NEmW-HBzWxzS6FW6iCQyyWJCwjvtMVCop6tDHlZTPGTKjz0rC_z4aZeXbeUs_tm1SAhaG_rv-LsSfa-UijmUVQwmC80D-173fikRDlCygjxrB5_eV1ZUhKeY0YxuJTIhVEaMG84vVdel70y3_G3xoUOT5RsXgLasggl0NEkEhhpF5-OANOjd7DuPbfDNDUgfmBHhDkI4MzSWE2hcHtvW5rO-fpAlbz-DUPriWTgRsrb_9AxoMjwI3IEIfTIi2KY4kIAEqCWV1LXdlc3QtMjCREA.m3u8', 0, 7972, FALSE, FALSE, -1, 1.0, 1, U&'\7ebf\8def1', 'pretty cafe tour', 'https://static-cdn.jtvnw.net/jtv_user_pictures/b01c95c1-7ce9-4669-b36b-a18c3d26587e-profile_image-70x70.png', U&'\539f\753b', 'csp_Live@@@twitch$greennyang@@@0', 'site', 'csp_Live', NULL, 'twitch$greennyang', 1789907393348, NULL, 1789907387454, NULL, NULL, NULL, NULL, U&'\7ebf\8def1', NULL, NULL, NULL, NULL),
(68, 0, 1789907348203, 28000, 0, 0, 'https://euw12.playlist.ttvnw.net/v1/playlist/Cv8E0bSUDj08eW9YVaqDnCYDuOQUrIiwOVd-Y-gwCyMOM0OW37nVeYCRZlXz18wPcJLVbsHBhv1e2HIVxpLoGlpgRx4zTU2eiCYx2hSyBbgFb_2eeWWVLhZy-yZ8TfOEKSNiy7JqJQE2VCUb1hwmiZPNsiyiMQq7zFyEOkTIvjYgpH2zmJgdtzhI0qhY5RZLm7ZPq7yHtyGFlufd3fkY1udt6lvqAE5H_PoxpGzChPcMpAheYftD-DARJSt75D3T98izhlmf9GYu4HkgX1iz9pcPWq8yzXh9WkZh5Iyz88I5uu_E9T5HDrWHul7hkMEQRz0Exiv-G-wr31Zvs4512fF58MxxyVWz53-N22HHqbTBchaB3k6pQkfADVSch37sRltPqcMj5Hv-uXPVBmPXTa-tn_IQb9lyVnhQeunUEAnaxM8PV-pW2rKRso2QNK_Sl5JEbuGfp1PlHueB_yLhM4L5Z-_94_6thq2t9Redf4J87VKhK39UumUFeEUKkhZcfbRmAKe1QFF7HAFHx79XiMeJH2Y7LVtnDaF9nb0nVUC5qqZKQq6Bib1iMZZnjEvbrAAtEVl3yOZnQmJwH9kczU8s-FU4MRuf3Vzg7r2M-Wq1RTF8r_4qqWXsT2rfwmLGODKyLLi0f7c8ZgMsRsUA3hd17rDCwrI08rN57NbJ6_qz3dBtBShf1oIuFoKXfHZIXOwshEu_zqDxKKOSgmAiJ_qKF4HlNQfgp3GT1gQTcFOx72aKqYBRbXy5qaILa-PWq2N6njf1CQvSYXHUgedoLeGvhJcQSiVpkduQymJclrsw1YdVdhN7XICwbb_tca8oC9wozOAxdHkqxT_NU8Qzkwl8GgxjMrTQUh7TxNWSOWAgASoJZXUtd2VzdC0yMJEQ.m3u8', 0, 8120, FALSE, FALSE, -1, 1.0, 1, U&'\7ebf\8def1', U&'\0427\0418\041b\041b\0418\041c \0412 \0421\0410\0414\0423 \0423 @yavixse \+01f33e !tg !donat', 'https://static-cdn.jtvnw.net/jtv_user_pictures/1797ffdc-21f4-45f0-8527-33569c179b3c-profile_image-70x70.png', '480p30', 'csp_Live@@@twitch$mrsxxot@@@0', 'site', 'csp_Live', NULL, 'twitch$mrsxxot', 1789907348203, NULL, 1789907327261, NULL, NULL, NULL, NULL, U&'\7ebf\8def1', NULL, NULL, NULL, NULL),
(69, 0, 1789907418157, 12060, 0, 0, 'https://live-global-cdn-v02.sooplive.com/live-stmc-39/auth_playlist.m3u8?aid=.A32.pxqRXFPZNcY9Qg1.0uJbq5q9678mGDI96vyzUt-dqoF16Hq3jKMo-Kf2lF-RLXHGnzsxoaBr0WXwuyVS1cALTfYkKCG7MXTWEU3Rj2flrCGmKqp5GWP5qsAbGmOP0Y8UuWXZe-w-WnAyUzDrGr4WOOBA1Gy2I1PRAc3BcyxZEBEbSwzNSFdqf6kmC71ugY1Y-gdA-dxuy4Sb4UNt6a1qpSHbFABpOmeu0yomdtW4du9WRzGsyI6Fw0M6qhw', 0, 2557, FALSE, FALSE, -1, 1.0, 1, U&'\7ebf\8def1', U&'\d0b4\c131\d0dcx\c800\b77c\b383x\c624\c544VS\afc0\d0f1\d0f1x\b2e8\c218\c544x\b77c\ac70\ba38\d540 50000\ac1c \c624\d504\d53c\d30cCK', 'https://liveimg.sooplive.com/m/297261955', '1080p', 'csp_Live@@@soop$rrvv17@@@0', 'site', 'csp_Live', NULL, 'soop$rrvv17', 1789907418157, NULL, 1789907387442, NULL, NULL, NULL, NULL, U&'\7ebf\8def1', NULL, NULL, NULL, NULL),
(70, 0, 1789907483741, 0, 0, 0, 'https://d1--cn-gotcha04b.bilivideo.com/live-bvc/488333/live_yx8hkg8khd_S6FwwOF_x1x.flv?expires=1789911033&len=0&oi=3083333884&pt=web&qn=10000&trid=100077097e48933a442e592d7264526aafd1&bmt=2&sigparams=cdn,expires,len,oi,pt,qn,trid,bmt&cdn=cn-gotcha04&sign=ed3a4c53a2453829e64096a8f711306c&site=df45018f3f68ab649b6a31c7b058e307&free_type=0&mid=1323080650&sche=ban&trace=64&isp=cm&rg=North&pv=Hebei&sl=1&strategy_type=0&expected_qn=400&strategy_id=35&strategy_types=0,1&hdr_type=0&pp=&strategy_ids=35,35&suffix=origin&source=puv3_onetier&codec=0&hot_cdn=0&score=1&info_source=origin&media_type=0&ld=yllg&p2p_type=1&origin_bitrate=6153&deploy_env=prod&sk=349fc313d24b1840418f3121d3d2b58c&vd=bc&src=puv3&order=2', 0, 1734, FALSE, FALSE, -1, 1.0, 1, U&'\7ebf\8def1', U&'\7ae5\989c\5de8\53ef\7231~', 'http://x.xinsite.top:4566/images?url=https://i0.hdslb.com/bfs/live/new_room_cover/c04ecbe3ed9c3f2c0e83ada821337b9d6f1ae2fe.jpg', U&'\539f\753b-flv-avc-1', 'csp_Live@@@bili$1941163472@@@0', 'site', 'csp_Live', NULL, 'bili$1941163472', 1789907483741, NULL, 1789907447541, NULL, NULL, NULL, NULL, U&'\7ebf\8def1', NULL, NULL, NULL, NULL);
INSERT INTO "PUBLIC"."HISTORY" VALUES
(71, 0, 1789907476754, 17579, 0, 0, 'https://d1--cn-gotcha104.bilivideo.com/live-bvc/871916/live_10i1b93ivyr_SDOE0sG_9bm_2500.m3u8?expires=1789911008&len=0&oi=3083333884&pt=web&qn=250&trid=1003083407ab2fe188657978d4a40e6aafd1&bmt=2&sigparams=cdn,expires,len,oi,pt,qn,trid,bmt&cdn=cn-gotcha104&sign=036b97e962570c937fb0b1a4f63b1716&site=c299bc73599222f49a14c9ad287ec943&free_type=0&mid=1323080650&sche=ban&trace=64&isp=cm&rg=North&pv=Hebei&ld=yllg&info_source=cache&sk=1d78f669e43fe5bf6a49b690fc81818b&source=puv3_onetier&suffix=2500&expected_qn=400&sl=1&deploy_env=prod&strategy_type=0&strategy_ids=35,35&codec=0&pp=&strategy_types=0,1&media_type=0&strategy_id=35&p2p_type=1&score=40&origin_bitrate=1052&hdr_type=0&hot_cdn=0&vd=bc&src=puv3&order=1', 0, 1926, FALSE, FALSE, -1, 1.0, 1, U&'\7ebf\8def2', U&'\771f\7684\5927 \8c41\51fa\53bb\4e86', 'http://x.xinsite.top:4566/images?url=https://i0.hdslb.com/bfs/live/user_cover/18f4c7b3fbfad876bc2c7f9eed0cd114cbfe21ec.jpg', U&'\8d85\6e05-ts-avc-2', 'csp_Live@@@bili$1838154340@@@0', 'site', 'csp_Live', NULL, 'bili$1838154340', 1789907476754, NULL, 1789907447551, NULL, NULL, NULL, NULL, U&'\7ebf\8def2', NULL, NULL, NULL, NULL),
(72, 0, 1789911768685, 0, 0, 0, 'https://stream-shenyang-cmcc-120-201-109-167.edgesrv.com:443/live/36252rt3pSdsXfdT_900.flv?wsAuth=21e06a621afa2bf9ca9a64f17e69074c&token=web-h5-0-36252-cbf87396f8ab1982822eba20d56649e477db77ff2a5beb9d&logo=0&expire=0&did=6898c0e0d8e143feb69ae20680b2de03&ver=Douyu_223061205&pt=2&st=0&sid=436467834&mcid2=0&origin=dy&fcdn=scdn&fo=0&mix=0&isp=scdncmcclinsy2', 0, 1412, FALSE, FALSE, -1, 1.0, 1, U&'\7ebf\8def1', U&'Gemini\ff1a\9c7c\738b\676f\6765\4e86\ff01\ff01', 'https://rpic.douyucdn.cn/asrpic/260920/36252_src_2138.avif/dy4', U&'\84dd\51494M', 'csp_Live@@@douyu$36252@@@0', 'site', 'csp_Live', NULL, 'douyu$36252', 1789911768685, NULL, 1789911743065, NULL, NULL, NULL, NULL, U&'\7ebf\8def1', NULL, NULL, NULL, NULL),
(73, 0, 1789911323081, 693, 0, 0, 'https://hw3a.douyucdn2.cn/live/6588602rhLMwnFzo.flv?wsAuth=f140228760362a6bd8ff6895e47ee9b9&token=web-h5-0-6588602-8b99e56a5ddb44df1d696fc3d52fb86f1532b27e29b76739&logo=0&expire=0&did=72b0f0756ac542269059b4fcb9a20eb8&ver=Douyu_223061205&pt=2&st=0&sid=436478473&mcid2=0&origin=hw&fcdn=hw&fo=1&mix=0&isp=', 0, 693, FALSE, FALSE, -1, 1.0, 1, U&'\7ebf\8def7', U&'\2764\fe0f\738b\8005\5168\80fd\5973\795e', 'https://rpic.douyucdn.cn/asrpic/260920/6588602_src_2128.avif/dy4', U&'\539f\753b1080P60', 'csp_Live@@@douyu$6588602@@@0', 'site', 'csp_Live', NULL, 'douyu$6588602', 1789911323081, NULL, 1789911322383, NULL, NULL, NULL, NULL, U&'\7ebf\8def7', NULL, NULL, NULL, NULL),
(74, 0, 1789907811348, 0, 0, 0, 'https://hw3.douyucdn2.cn/live/8949741r5aVEkQ8G.flv?wsAuth=478adfa54e712d3e9fce4c2cac421ed7&token=web-h5-0-8949741-b128e61b9ae2170a01a2fbf587c861d14b45c108202af3c6&logo=0&expire=0&did=868ea45d85f44688813d703ac8938c12&ver=Douyu_223061205&pt=2&st=0&sid=436459673&mcid2=0&origin=hw&fcdn=hw&fo=1&mix=0&isp=', 0, 39661, FALSE, FALSE, -1, 1.0, 1, U&'\7ebf\8def7', U&'\514d\8d39\5e26\7c89\4e0a\8f66,5\4e07\573a\56fd\4e00\5218\5907 \514b\4e9a\745f', 'https://rpic.douyucdn.cn/asrpic/260920/8949741_src_2032.avif/dy4', U&'\539f\753b1080P60', 'csp_Live@@@douyu$8949741@@@0', 'site', 'csp_Live', NULL, 'douyu$8949741', 1789907811348, NULL, 1789907809690, NULL, NULL, NULL, NULL, U&'\7ebf\8def7', NULL, NULL, NULL, NULL),
(75, 0, 1789907923632, 0, 0, 0, 'https://hw3.douyucdn2.cn/live/2142608rKLEJP7Pq.flv?wsAuth=0cf5dc51fb828255dd7b68b5be2bce98&token=web-h5-0-2142608-18ac453c7da241a0354b7283f9946942cf3b2d4b08a610c4&logo=0&expire=0&did=db2f28c5390140e3a930fe0403753e42&ver=Douyu_223061205&pt=2&st=0&sid=436459679&mcid2=0&origin=hw&fcdn=hw&fo=1&mix=0&isp=', 0, 98288, FALSE, FALSE, -1, 1.0, 1, U&'\7ebf\8def7', U&'\514d\8d39\5e26\7c89\ff0c\4e94\4e07\573a\56fd\670d\5b59\5c1a\9999\5e26\7c89\8fde\80dc\6709\8f66\4f4d', 'https://rpic.douyucdn.cn/asrpic/260920/2142608_src_2032.avif/dy4', U&'\539f\753b1080P30', 'csp_Live@@@douyu$2142608@@@0', 'site', 'csp_Live', NULL, 'douyu$2142608', 1789907923632, NULL, 1789907929847, NULL, NULL, NULL, NULL, U&'\7ebf\8def7', NULL, NULL, NULL, NULL);               
INSERT INTO "PUBLIC"."HISTORY" VALUES
(76, 0, 1789907945155, 0, 0, 0, 'https://stream-shenyang-cmcc-120-201-109-166.edgesrv.com:443/live/793400reAC9hdf8M_900.flv?wsAuth=ac3d153cb74ab28a9573189bbb746fc8&token=web-h5-0-793400-eb65e8d273b5b1a8616c117a2f853cbaefced2161dca9424&logo=0&expire=0&did=daee358efe3e4eec8c373162a5e581ed&ver=Douyu_223061205&pt=2&st=0&sid=436477503&mcid2=0&origin=dy&fcdn=scdn&fo=0&mix=0&isp=scdncmcclinsy2', 0, 6132, FALSE, FALSE, -1, 1.0, 1, U&'\7ebf\8def1', U&'\8d44\683c\8d5b\51b3\8d5b\ff01~~~\ff01', 'https://rpic.douyucdn.cn/asrpic/260920/793400_src_2037.avif/dy4', U&'\539f\753b2K60', 'csp_Live@@@douyu$793400@@@0', 'site', 'csp_Live', NULL, 'douyu$793400', 1789907945155, NULL, 1789907929844, NULL, NULL, NULL, NULL, U&'\7ebf\8def1', NULL, NULL, NULL, NULL),
(77, 0, 1789910622856, 0, 0, 0, 'https://stream-shenyang-cmcc-120-201-109-166.edgesrv.com:443/live/11684641reybKf75_900.flv?wsAuth=1a03018dce61df6437daeaf23737d001&token=web-h5-0-11684641-0a38cd59e56a7bb20eaca7e839d06c75e85c9819dc3d8c14&logo=0&expire=0&did=e7777eac075446ec9ec04f1a483e7d71&ver=Douyu_223061205&pt=2&st=0&sid=436480637&mcid2=0&origin=hw&fcdn=scdn&fo=0&mix=0&isp=scdncmcclinsy2', 0, 1562, FALSE, FALSE, -1, 1.0, 1, U&'\7ebf\8def7', U&'\9996\64ad\6765\4e86\ff01', 'https://rpic.douyucdn.cn/asrpic/260920/11684641_src_2118.avif/dy4', U&'\539f\753b1080P60', 'csp_Live@@@douyu$11684641@@@0', 'site', 'csp_Live', NULL, 'douyu$11684641', 1789910622856, NULL, 1789910601040, NULL, NULL, NULL, NULL, U&'\7ebf\8def7', NULL, NULL, NULL, NULL),
(78, 0, 1789912049904, 0, 0, 0, 'https://stream-shenyang-cmcc-120-201-109-166.edgesrv.com:443/live/8813116r6lq30m6f_900.flv?wsAuth=1df492bcfcb3f866c8874c1515e8f24e&token=web-h5-0-8813116-6bfd0d9b1d5144a2d583b65249d383815dc9d440c50d64b0&logo=0&expire=0&did=f0674a08c2294886b151e60fd94b3e59&ver=Douyu_223061205&pt=2&st=0&sid=436480453&mcid2=0&origin=dy&fcdn=scdn&fo=0&mix=0&isp=scdncmcclinsy2', 0, 2072, FALSE, FALSE, -1, 1.0, 1, U&'\7ebf\8def7', U&'\6211\8349\8393\62db\4e86', 'https://rpic.douyucdn.cn/asrpic/260920/8813116_src_2138.avif/dy4', U&'\9ad8\6e05', 'csp_Live@@@douyu$8813116@@@0', 'site', 'csp_Live', NULL, 'douyu$8813116', 1789912049904, NULL, 1789912043624, NULL, NULL, NULL, NULL, U&'\7ebf\8def7', NULL, NULL, NULL, NULL),
(79, 0, 1789908492722, 0, 0, 0, 'https://stream-shenyang-cmcc-120-201-109-165.edgesrv.com:443/live/9756096rX2ULtvaK_900.flv?wsAuth=3228eb6a62a68e706f5738a18c131720&token=web-h5-0-9756096-1d1f1faf1f87d1351ffccb28a9322c41da8553403678cf67&logo=0&expire=0&did=9924d4c58abe40f08dafd1859ec6b37b&ver=Douyu_223061205&pt=2&st=0&sid=436471026&mcid2=0&origin=dy&fcdn=scdn&fo=0&mix=0&isp=scdncmcclinsy2', 0, 608, FALSE, FALSE, -1, 1.0, 1, U&'\7ebf\8def1', U&'\4e07\8c61\68cb\51b2\5206 66607', 'https://rpic.douyucdn.cn/asrpic/260920/9756096_src_2043.avif/dy4', U&'\539f\753b2K60', 'csp_Live@@@douyu$9756096@@@0', 'site', 'csp_Live', NULL, 'douyu$9756096', 1789908492722, NULL, 1789908470619, NULL, NULL, NULL, NULL, U&'\7ebf\8def1', NULL, NULL, NULL, NULL),
(80, 0, 1789908982458, 3730, 0, 0, 'https://stream-shenyang-cmcc-120-201-109-163.edgesrv.com:443/live/3014399rqLROsDZQ_900.flv?wsAuth=37dec59fb7d312d6f188983241ca6a9c&token=web-h5-0-3014399-a6c99c1a2d0c552098a447bfcdc8709c42da3d10db80d5fb&logo=0&expire=0&did=5a4b2c429e0f453c811d34d3e2d6c955&ver=Douyu_223061205&pt=2&st=0&sid=436463693&mcid2=0&origin=dy&fcdn=scdn&fo=0&mix=0&isp=scdncmcclinsy2', 0, 882, FALSE, FALSE, -1, 1.0, 1, U&'\7ebf\8def1', U&'\8d4f\91d1\6c34\53cb\8d5b\ff0c\6709\624d\4f60\5c31\6765', 'https://rpic.douyucdn.cn/asrpic/260920/3014399_src_2042.avif/dy4', U&'\539f\753b1080P30', 'csp_Live@@@douyu$3014399@@@0', 'site', 'csp_Live', NULL, 'douyu$3014399', 1789908982458, NULL, 1789908951334, NULL, NULL, NULL, NULL, U&'\7ebf\8def1', NULL, NULL, NULL, NULL),
(81, 0, 1789911002911, 0, 0, 0, 'https://stream-shenyang-cmcc-120-201-109-167.edgesrv.com:443/live/2127419rIgw2eQeS_900.flv?wsAuth=c96a68ec6313d0050a96fc2f0ff51486&token=web-h5-0-2127419-b37fcd85df6740631a701117272841f950c74d76e4e5d262&logo=0&expire=0&did=5a58f61439404c86a7029595a09ab5b4&ver=Douyu_223061205&pt=2&st=0&sid=436483535&mcid2=0&origin=hw&fcdn=scdn&fo=0&mix=0&isp=scdncmcclinsy2', 0, 1164, FALSE, FALSE, -1, 1.0, 1, U&'\7ebf\8def1', U&'\4e5d\65e5\ff1a\8c82\8749\5dc5\5cf0\8d5b', 'https://rpic.douyucdn.cn/asrpic/260920/2127419_src_2128.avif/dy4', U&'\539f\753b1080P60', 'csp_Live@@@douyu$2127419@@@0', 'site', 'csp_Live', NULL, 'douyu$2127419', 1789911002911, NULL, 1789910961642, NULL, NULL, NULL, NULL, U&'\7ebf\8def1', NULL, NULL, NULL, NULL);      
INSERT INTO "PUBLIC"."HISTORY" VALUES
(82, 0, 1789910635981, 0, 0, 0, 'https://stream-shenyang-cmcc-120-201-109-164.edgesrv.com:443/live/10267847rNRX3WSK_900.flv?wsAuth=dbf304a22515d8b7d8aaef09abe937bb&token=web-h5-0-10267847-8815340f4374a678d9818d4d03963cd39d4c54fcc1164e2c&logo=0&expire=0&did=5d58d1b329024af6a8e42f7d1ff10f83&ver=Douyu_223061205&pt=2&st=0&sid=436477561&mcid2=0&origin=dy&fcdn=scdn&fo=0&mix=0&isp=scdncmcclinsy2', 0, 2373, FALSE, FALSE, -1, 1.0, 1, U&'\7ebf\8def1', U&'\665a\4e0a\597d\ff01\ff01\ff01 10267847', 'https://rpic.douyucdn.cn/asrpic/260920/10267847_src_2118.avif/dy4', U&'\539f\753b1080P60', 'csp_Live@@@douyu$10267847@@@0', 'site', 'csp_Live', NULL, 'douyu$10267847', 1789910635981, NULL, 1789910601035, NULL, NULL, NULL, NULL, U&'\7ebf\8def1', NULL, NULL, NULL, NULL),
(83, 0, 1789912045818, 0, 0, 0, 'https://stream-shenyang-cmcc-120-201-109-167.edgesrv.com:443/live/10740395rMrmDbsg_900.flv?wsAuth=fdddb24dfd169b4617b7d5bd3936f787&token=web-h5-0-10740395-c654509976685c277c9d054757ef4b70a00e2e49c89087f4&logo=0&expire=0&did=70f5554323374b60b15aee66997cdec9&ver=Douyu_223061205&pt=2&st=0&sid=436480223&mcid2=0&origin=dy&fcdn=scdn&fo=0&mix=0&isp=scdncmcclinsy2', 0, 273184, FALSE, FALSE, -1, 1.0, 1, U&'\7ebf\8def1', U&'\5dc5\5cf0\8ba9\6211\8d62\5427', 'https://rpic.douyucdn.cn/asrpic/260920/10740395_src_2138.avif/dy4', U&'\539f\753b1080P60', 'csp_Live@@@douyu$10740395@@@0', 'site', 'csp_Live', NULL, 'douyu$10740395', 1789912045818, NULL, 1789912043633, NULL, NULL, NULL, NULL, U&'\7ebf\8def1', NULL, NULL, NULL, NULL),
(84, 0, 1789911158889, 0, 0, 0, 'https://hw3a.douyucdn2.cn/live/5741240reX7l9OTL.flv?wsAuth=da2933db29b56fe346d6d5392d34b085&token=web-h5-0-5741240-ee9487f5523eca13da8ce4e26398a92d061b875b42c9c66c&logo=0&expire=0&did=d23c1f10ba30460cb54e9c361d46d2a5&ver=Douyu_223061205&pt=2&st=0&sid=436458066&mcid2=0&origin=hw&fcdn=hw&fo=1&mix=0&isp=', 0, 136945, FALSE, FALSE, -1, 1.0, 1, U&'\7ebf\8def7', U&'\51b2\51b2\51b2\51b2\6218\795e 5741240', 'https://rpic.douyucdn.cn/asrpic/260920/5741240_src_2128.avif/dy4', U&'\539f\753b1080P60', 'csp_Live@@@douyu$5741240@@@0', 'site', 'csp_Live', NULL, 'douyu$5741240', 1789911158889, NULL, 1789911141988, NULL, NULL, NULL, NULL, U&'\7ebf\8def7', NULL, NULL, NULL, NULL),
(85, 0, 1789911012987, 0, 0, 0, 'https://stream-shenyang-cmcc-120-201-109-166.edgesrv.com:443/live/2561523rt7tzSNO5_900.flv?wsAuth=55aff1ee4e1bae83497be471337cbe33&token=web-h5-0-2561523-5efddb8823d4efc1949462d793fef9787acc574205f46138&logo=0&expire=0&did=8c98d810a28a4711967ac2335cfa55d8&ver=Douyu_223061205&pt=2&st=0&sid=436471153&mcid2=0&origin=dy&fcdn=scdn&fo=0&mix=0&isp=scdncmcclinsy2', 0, 856, FALSE, FALSE, -1, 1.0, 1, U&'\7ebf\8def1', U&'\54ac\7259\4e0a\56db\5148\82e6\540e\751c\ff01\ff01!', 'https://rpic.douyucdn.cn/asrpic/260920/2561523_src_2128.avif/dy4', U&'\539f\753b1080P60', 'csp_Live@@@douyu$2561523@@@0', 'site', 'csp_Live', NULL, 'douyu$2561523', 1789911012987, NULL, 1789911021783, NULL, NULL, NULL, NULL, U&'\7ebf\8def1', NULL, NULL, NULL, NULL),
(86, 0, 1789911291029, 0, 0, 0, 'https://hw3a.douyucdn2.cn/live/4871359riOKivByo.flv?wsAuth=b497943b09a52ee1f900afaf8bd03e31&token=web-h5-0-4871359-f2e0ed5ad1a9583b151462390c69811fb7c830b58bcd3d8c&logo=0&expire=0&did=b2352be7cd1a4587a1ab6cb2de4f4040&ver=Douyu_223061205&pt=2&st=0&sid=436480394&mcid2=0&origin=hw&fcdn=hw&fo=1&mix=0&isp=', 0, 123720, FALSE, FALSE, -1, 1.0, 1, U&'\7ebf\8def7', U&'\3014\76f4\64ad\3015\98de\673a\6253\53f7\4e0a\8f66', 'https://rpic.douyucdn.cn/asrpic/260920/4871359_src_2128.avif/dy4', U&'\539f\753b720P60', 'csp_Live@@@douyu$4871359@@@0', 'site', 'csp_Live', NULL, 'douyu$4871359', 1789911291029, NULL, 1789911262170, NULL, NULL, NULL, NULL, U&'\7ebf\8def7', NULL, NULL, NULL, NULL),
(87, 0, 1789911164485, 0, 0, 0, 'https://hw3.douyucdn2.cn/live/12887522rEhnNGds.flv?wsAuth=e9cad7a1d4b2578eee0f34549a72f1f2&token=web-h5-0-12887522-1ef4c9b477101354eedc9bed8720776d22b986fb3e04bed8&logo=0&expire=0&did=1dc50530074d4034a4ed0e8fe6a5efbd&ver=Douyu_223061205&pt=2&st=0&sid=436480606&mcid2=0&origin=hw&fcdn=hw&fo=1&mix=0&isp=', 0, 688, FALSE, FALSE, -1, 1.0, 1, U&'\7ebf\8def7', U&'\68a6\6eaaqwq\7684\76f4\64ad\95f4', 'https://rpic.douyucdn.cn/asrpic/260920/12887522_src_2128.avif/dy4', U&'\539f\753b1080P60', 'csp_Live@@@douyu$12887522@@@0', 'site', 'csp_Live', NULL, 'douyu$12887522', 1789911164485, NULL, 1789911141971, NULL, NULL, NULL, NULL, U&'\7ebf\8def7', NULL, NULL, NULL, NULL);      
INSERT INTO "PUBLIC"."HISTORY" VALUES
(88, 0, 1789911295633, 0, 0, 0, 'https://hw3.douyucdn2.cn/live/7517679rYLtLbpUM.flv?wsAuth=4c82237e5adfb0fe558e7fa781fa86e0&token=web-h5-0-7517679-c26fe125b4edeba2ec4143772bb3abaef012d98ed4f2091c&logo=0&expire=0&did=2259ab94538d470f9241ad4c9f911385&ver=Douyu_223061205&pt=2&st=0&sid=436486880&mcid2=0&origin=hw&fcdn=hw&fo=1&mix=0&isp=', 0, 505, FALSE, FALSE, -1, 1.0, 1, U&'\7ebf\8def7', U&'\4f60\7684\767e\661f\5973\91ce\738b\4e0a\7ebf\5566', 'https://rpic.douyucdn.cn/asrpic/260920/7517679_src_2133.avif/dy4', U&'\539f\753b1080P30', 'csp_Live@@@douyu$7517679@@@0', 'site', 'csp_Live', NULL, 'douyu$7517679', 1789911295633, NULL, 1789911262167, NULL, NULL, NULL, NULL, U&'\7ebf\8def7', NULL, NULL, NULL, NULL),
(89, 0, 1789911599890, 0, 0, 0, 'https://stream-shenyang-cmcc-120-201-109-164.edgesrv.com:443/live/2207607rH4F690Go_900.flv?wsAuth=0ae26ce1f6e8c6295839fb659ab6892f&token=web-h5-0-2207607-df851dcdab08ea82eaaa2a77d62f024a4344b1109e2a57ca&logo=0&expire=0&did=03fcf78b35554866b46defa9d55aa5dd&ver=Douyu_223061205&pt=2&st=0&sid=436484294&mcid2=0&origin=dy&fcdn=scdn&fo=0&mix=0&isp=scdncmcclinsy2', 0, 263679, FALSE, FALSE, -1, 1.0, 1, U&'\7ebf\8def1', U&'\5f00\5fc3\6bcf\4e00\5929...', 'https://rpic.douyucdn.cn/asrpic/260920/2207607_src_2133.avif/dy4', U&'\539f\753b1080P60', 'csp_Live@@@douyu$2207607@@@0', 'site', 'csp_Live', NULL, 'douyu$2207607', 1789911599890, NULL, 1789911562830, NULL, NULL, NULL, NULL, U&'\7ebf\8def1', NULL, NULL, NULL, NULL),
(90, 0, 1789960877785, 5444520, 0, 0, 'https://vod1.maowushi.com/20260917/WvP3sF9S/index.m3u8', 0, 1015, FALSE, FALSE, -1, 1.0, 1, '360zy', U&'\5173\7d22\5cad', 'https://www.imgzy360.com:7788/upload/vod/20260917-1/8655c50a50f3a5ccb2ce83c302604744.jpg', U&'\6b63\7247', 'xinsite4@@@382959@@@0', 'site', 'xinsite4', NULL, '382959', 1789960877785, NULL, 1789960845072, NULL, NULL, NULL, 359, '360zy', NULL, NULL, NULL, NULL);              
CREATE INDEX "PUBLIC"."IDX_HISTORY_CHANGE" ON "PUBLIC"."HISTORY"("UID" NULLS FIRST, "CHANGE_SEQ" NULLS FIRST); 
CREATE INDEX "PUBLIC"."IDX_HISTORY_SYNC" ON "PUBLIC"."HISTORY"("UID" NULLS FIRST, "SOURCE_KIND" NULLS FIRST, "SOURCE_KEY" NULLS FIRST);        
CREATE INDEX "PUBLIC"."IDX_HISTORY_SYNC_SCOPE" ON "PUBLIC"."HISTORY"("UID" NULLS FIRST, "SYNC_SCOPE" NULLS FIRST, "SOURCE_KIND" NULLS FIRST, "SOURCE_KEY" NULLS FIRST);        
CREATE CACHED TABLE "PUBLIC"."LIVE_FOLLOW"(
    "ID" INTEGER NOT NULL,
    "UID" INTEGER NOT NULL,
    "PLATFORM" CHARACTER VARYING(32) NOT NULL,
    "ROOM_ID" CHARACTER VARYING(64) NOT NULL,
    "ROOM_NAME" CHARACTER VARYING(255),
    "ANCHOR_NAME" CHARACTER VARYING(255),
    "COVER" CHARACTER VARYING(512),
    "CREATED_TIME" BIGINT NOT NULL
);    
ALTER TABLE "PUBLIC"."LIVE_FOLLOW" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_C8" PRIMARY KEY("ID");  
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.LIVE_FOLLOW;              
CREATE UNIQUE NULLS DISTINCT INDEX "PUBLIC"."UK_LIVE_FOLLOW" ON "PUBLIC"."LIVE_FOLLOW"("UID" NULLS FIRST, "PLATFORM" NULLS FIRST, "ROOM_ID" NULLS FIRST);      
CREATE CACHED TABLE "PUBLIC"."INDEX_TEMPLATE"(
    "ID" INTEGER NOT NULL,
    "CREATED_TIME" TIMESTAMP,
    "DATA" CHARACTER VARYING,
    "NAME" CHARACTER VARYING(255),
    "SCHEDULE_TIME" CHARACTER VARYING(255),
    "SCHEDULED" BOOLEAN DEFAULT FALSE,
    "SCRAPE" BOOLEAN DEFAULT FALSE,
    "SITE_ID" INTEGER,
    "SLEEP" INTEGER
);  
ALTER TABLE "PUBLIC"."INDEX_TEMPLATE" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_1F" PRIMARY KEY("ID");               
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.INDEX_TEMPLATE;           
CREATE CACHED TABLE "PUBLIC"."JELLYFIN"(
    "ID" INTEGER NOT NULL,
    "CLIENT_NAME" CHARACTER VARYING(255),
    "CLIENT_VERSION" CHARACTER VARYING(255),
    "DEVICE_ID" CHARACTER VARYING(255),
    "DEVICE_NAME" CHARACTER VARYING(255),
    "NAME" CHARACTER VARYING(255),
    "PASSWORD" CHARACTER VARYING(255),
    "SORT_ORDER" INTEGER,
    "URL" CHARACTER VARYING(255),
    "USER_AGENT" CHARACTER VARYING(255),
    "USERNAME" CHARACTER VARYING(255)
);           
ALTER TABLE "PUBLIC"."JELLYFIN" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_C" PRIMARY KEY("ID");      
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.JELLYFIN; 
CREATE CACHED TABLE "PUBLIC"."TMDB"(
    "ID" INTEGER NOT NULL,
    "ACTORS" CHARACTER VARYING(255),
    "COUNTRY" CHARACTER VARYING(255),
    "COVER" CHARACTER VARYING(255),
    "DESCRIPTION" CHARACTER VARYING(255),
    "DIRECTORS" CHARACTER VARYING(255),
    "EDITORS" CHARACTER VARYING(255),
    "GENRE" CHARACTER VARYING(255),
    "LANGUAGE" CHARACTER VARYING(255),
    "NAME" CHARACTER VARYING(255),
    "SCORE" CHARACTER VARYING(255),
    "TMDB_ID" INTEGER,
    "TYPE" CHARACTER VARYING(255),
    "year" INTEGER
);       
ALTER TABLE "PUBLIC"."TMDB" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_27" PRIMARY KEY("ID");         
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.TMDB;     
CREATE CACHED TABLE "PUBLIC"."NAVIGATION"(
    "ID" INTEGER NOT NULL,
    "NAME" CHARACTER VARYING(255),
    "PARENT_ID" INTEGER NOT NULL,
    "RESERVED" BOOLEAN DEFAULT FALSE,
    "VISIBLE" BOOLEAN DEFAULT TRUE,
    "SORT_ORDER" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "value" CHARACTER VARYING(255)
);     
ALTER TABLE "PUBLIC"."NAVIGATION" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_8B" PRIMARY KEY("ID");   
-- 165 +/- SELECT COUNT(*) FROM PUBLIC.NAVIGATION;             
INSERT INTO "PUBLIC"."NAVIGATION" VALUES
(1, U&'\63a8\8350', 0, TRUE, TRUE, 10, 1, 'recommend$0'),
(2, U&'\52a8\6001', 0, TRUE, FALSE, 11, 1, 'feed$0'),
(3, U&'\6211\7684\5173\6ce8', 0, TRUE, FALSE, 12, 1, 'follow$0'),
(4, U&'\6536\85cf\5939', 0, TRUE, FALSE, 13, 1, 'fav$0'),
(5, U&'\9891\9053', 0, TRUE, FALSE, 14, 1, 'channel$0'),
(6, U&'\5386\53f2\8bb0\5f55', 0, TRUE, FALSE, 15, 1, 'history$0'),
(7, U&'\5168\7ad9\70ed\699c', 0, TRUE, TRUE, 16, 1, '0'),
(8, U&'\7535\5f71\70ed\699c', 0, TRUE, TRUE, 17, 1, 'season$2'),
(9, U&'\7535\89c6\5267\70ed\699c', 0, TRUE, TRUE, 18, 1, 'season$5'),
(10, U&'\7efc\827a\70ed\699c', 0, TRUE, TRUE, 19, 1, 'season$7'),
(11, U&'\7eaa\5f55\7247\70ed\699c', 0, TRUE, TRUE, 20, 1, 'season$3'),
(12, U&'\52a8\753b\70ed\699c', 0, TRUE, TRUE, 21, 1, 'season$4'),
(13, U&'\756a\5267\70ed\699c', 0, TRUE, TRUE, 22, 1, 'season$1'),
(14, U&'\70ed\95e8', 0, TRUE, TRUE, 23, 1, 'pop$1'),
(15, U&'\56fd\521b', 0, TRUE, TRUE, 24, 1, '167'),
(16, U&'\7eaa\5f55\7247', 0, TRUE, TRUE, 25, 1, '177'),
(17, U&'\7535\5f71', 0, TRUE, TRUE, 26, 1, '23'),
(18, U&'\7535\89c6\5267', 0, TRUE, TRUE, 27, 1, '11'),
(19, U&'\79d1\6280', 0, TRUE, TRUE, 28, 1, '188'),
(20, U&'\77e5\8bc6', 0, TRUE, TRUE, 29, 1, '36'),
(21, U&'\52a8\753b', 0, TRUE, TRUE, 30, 1, '1'),
(22, U&'\756a\5267', 0, TRUE, TRUE, 31, 1, '13'),
(23, U&'\97f3\4e50', 0, TRUE, TRUE, 32, 1, '3'),
(24, U&'\6e38\620f', 0, TRUE, TRUE, 33, 1, '4'),
(25, U&'\5a31\4e50', 0, TRUE, TRUE, 34, 1, '5'),
(26, U&'\5f71\89c6', 0, TRUE, TRUE, 35, 1, '181'),
(27, U&'\821e\8e48', 0, TRUE, TRUE, 36, 1, '129'),
(28, U&'\8fd0\52a8', 0, TRUE, TRUE, 37, 1, '234'),
(29, U&'\6c7d\8f66', 0, TRUE, TRUE, 38, 1, '223'),
(30, U&'\751f\6d3b', 0, TRUE, TRUE, 39, 1, '160'),
(31, U&'\7f8e\98df', 0, TRUE, TRUE, 40, 1, '211'),
(32, U&'\52a8\7269\5708', 0, TRUE, TRUE, 41, 1, '217'),
(33, U&'\65f6\5c1a', 0, TRUE, TRUE, 42, 1, '155'),
(34, U&'\9b3c\755c', 0, TRUE, TRUE, 43, 1, '119'),
(35, U&'\539f\521b', 0, TRUE, FALSE, 44, 1, 'origin$0'),
(36, U&'\65b0\4eba', 0, TRUE, FALSE, 45, 1, 'rookie$0'),
(37, U&'\756a\5267\7d22\5f15', 0, TRUE, TRUE, 20, 1, 'index$1'),
(38, U&'UP\4e3b', 0, TRUE, FALSE, 21, 1, 'ups'),
(39, U&'\56fd\4ea7\52a8\753b', 15, TRUE, TRUE, 1, 2, '153'),
(40, U&'\56fd\4ea7\539f\521b', 15, TRUE, TRUE, 2, 2, '168'),
(41, U&'\5e03\888b\620f', 15, TRUE, TRUE, 3, 2, '169'),
(42, U&'\8d44\8baf', 15, TRUE, TRUE, 4, 2, '170'),
(43, U&'\52a8\6001\6f2b\00b7\5e7f\64ad\5267 ', 15, TRUE, TRUE, 5, 2, '195'),
(44, U&'\4eba\6587\00b7\5386\53f2', 16, TRUE, TRUE, 1, 2, '37'),
(45, U&'\79d1\5b66\00b7\63a2\7d22\00b7\81ea\7136', 16, TRUE, TRUE, 2, 2, '178'),
(46, U&'\519b\4e8b', 16, TRUE, TRUE, 3, 2, '179'),
(47, U&'\793e\4f1a\00b7\7f8e\98df\00b7\65c5\884c', 16, TRUE, TRUE, 4, 2, '180'),
(48, U&'\534e\8bed\7535\5f71', 17, TRUE, TRUE, 1, 2, '147'),
(49, U&'\6b27\7f8e\7535\5f71', 17, TRUE, TRUE, 2, 2, '145'),
(50, U&'\65e5\672c\7535\5f71', 17, TRUE, TRUE, 3, 2, '146'),
(51, U&'\5176\4ed6\56fd\5bb6', 17, TRUE, TRUE, 4, 2, '83'),
(52, U&'\56fd\4ea7\5267', 18, TRUE, TRUE, 1, 2, '185'),
(53, U&'\6d77\5916\5267', 18, TRUE, TRUE, 2, 2, '187'),
(54, U&'\6570\7801', 19, TRUE, TRUE, 1, 2, '95'),
(55, U&'\8f6f\4ef6\5e94\7528', 19, TRUE, TRUE, 2, 2, '230'),
(56, U&'\8ba1\7b97\673a\6280\672f', 19, TRUE, TRUE, 3, 2, '231'),
(57, U&'\6781\5ba2DIY', 19, TRUE, TRUE, 4, 2, '233'),
(58, U&'\79d1\5b66\79d1\666e', 20, TRUE, TRUE, 1, 2, '201'),
(59, U&'\793e\79d1\00b7\6cd5\5f8b\00b7\5fc3\7406', 20, TRUE, TRUE, 2, 2, '124'),
(60, U&'\4eba\6587\5386\53f2', 20, TRUE, TRUE, 3, 2, '228'),
(61, U&'\8d22\7ecf\5546\4e1a', 20, TRUE, TRUE, 4, 2, '207'),
(62, U&'\6821\56ed\5b66\4e60', 20, TRUE, TRUE, 5, 2, '208'),
(63, U&'\804c\4e1a\804c\573a', 20, TRUE, TRUE, 6, 2, '209'),
(64, U&'\8bbe\8ba1\00b7\521b\610f', 20, TRUE, TRUE, 7, 2, '229'),
(65, U&'\91ce\751f\6280\672f\534f\4f1a', 20, TRUE, TRUE, 8, 2, '122'),
(66, U&'MAD\00b7AMV', 21, TRUE, TRUE, 1, 2, '24'),
(67, U&'MMD\00b73D', 21, TRUE, TRUE, 2, 2, '25'),
(68, U&'\77ed\7247\00b7\624b\4e66\00b7\914d\97f3', 21, TRUE, TRUE, 3, 2, '47'),
(69, U&'\624b\529e\00b7\6a21\73a9', 21, TRUE, TRUE, 4, 2, '210');     
INSERT INTO "PUBLIC"."NAVIGATION" VALUES
(70, U&'\7279\6444', 21, TRUE, TRUE, 5, 2, '86'),
(71, U&'\52a8\6f2b\6742\8c08', 21, TRUE, TRUE, 6, 2, '253'),
(72, U&'\7efc\5408', 21, TRUE, TRUE, 7, 2, '27'),
(73, U&'\8d44\8baf', 22, TRUE, TRUE, 1, 2, '51'),
(74, U&'\5b98\65b9\5ef6\4f38', 22, TRUE, TRUE, 2, 2, '152'),
(75, U&'\5b8c\7ed3\52a8\753b', 22, TRUE, TRUE, 3, 2, '32'),
(76, U&'\8fde\8f7d\52a8\753b', 22, TRUE, TRUE, 4, 2, '33'),
(77, U&'\539f\521b\97f3\4e50', 23, TRUE, TRUE, 1, 2, '28'),
(78, U&'\7ffb\5531', 23, TRUE, TRUE, 2, 2, '31'),
(79, U&'VOCALOID\00b7UTAU', 23, TRUE, TRUE, 3, 2, '30'),
(80, U&'\6f14\594f', 23, TRUE, TRUE, 4, 2, '59'),
(81, 'MV', 23, TRUE, TRUE, 5, 2, '193'),
(82, U&'\97f3\4e50\73b0\573a', 23, TRUE, TRUE, 6, 2, '29'),
(83, U&'\97f3\4e50\7efc\5408', 23, TRUE, TRUE, 7, 2, '130'),
(84, U&'\4e50\8bc4\76d8\70b9', 23, TRUE, TRUE, 8, 2, '243'),
(85, U&'\97f3\4e50\6559\5b66', 23, TRUE, TRUE, 9, 2, '244'),
(86, U&'\5355\673a\6e38\620f', 24, TRUE, TRUE, 1, 2, '17'),
(87, U&'\7535\5b50\7ade\6280', 24, TRUE, TRUE, 2, 2, '171'),
(88, U&'\624b\673a\6e38\620f', 24, TRUE, TRUE, 3, 2, '172'),
(89, U&'\7f51\7edc\6e38\620f', 24, TRUE, TRUE, 4, 2, '65'),
(90, U&'\684c\6e38\68cb\724c', 24, TRUE, TRUE, 5, 2, '173'),
(91, 'GMV', 24, TRUE, TRUE, 6, 2, '121'),
(92, U&'\97f3\6e38', 24, TRUE, TRUE, 7, 2, '136'),
(93, 'Mugen', 24, TRUE, TRUE, 8, 2, '19'),
(94, U&'\7efc\827a', 25, TRUE, TRUE, 1, 2, '71'),
(95, U&'\5a31\4e50\6742\8c08', 25, TRUE, TRUE, 2, 2, '241'),
(96, U&'\7c89\4e1d\521b\4f5c', 25, TRUE, TRUE, 3, 2, '242'),
(97, U&'\660e\661f\7efc\5408', 25, TRUE, TRUE, 4, 2, '137'),
(98, U&'\5f71\89c6\6742\8c08', 26, TRUE, TRUE, 1, 2, '182'),
(99, U&'\5f71\89c6\526a\8f91', 26, TRUE, TRUE, 2, 2, '183'),
(100, U&'\5c0f\5267\573a', 26, TRUE, TRUE, 3, 2, '85'),
(101, U&'\9884\544a\00b7\8d44\8baf', 26, TRUE, TRUE, 4, 2, '184'),
(102, U&'\5b85\821e', 27, TRUE, TRUE, 1, 2, '20'),
(103, U&'\821e\8e48\7efc\5408', 27, TRUE, TRUE, 2, 2, '154'),
(104, U&'\821e\8e48\6559\7a0b', 27, TRUE, TRUE, 3, 2, '156'),
(105, U&'\8857\821e', 27, TRUE, TRUE, 4, 2, '198'),
(106, U&'\660e\661f\821e\8e48', 27, TRUE, TRUE, 5, 2, '199'),
(107, U&'\4e2d\56fd\821e', 27, TRUE, TRUE, 6, 2, '200'),
(108, U&'\7bee\7403', 28, TRUE, TRUE, 1, 2, '235'),
(109, U&'\8db3\7403', 28, TRUE, TRUE, 2, 2, '249'),
(110, U&'\5065\8eab', 28, TRUE, TRUE, 3, 2, '164'),
(111, U&'\7ade\6280\4f53\80b2', 28, TRUE, TRUE, 4, 2, '236'),
(112, U&'\8fd0\52a8\6587\5316', 28, TRUE, TRUE, 5, 2, '237'),
(113, U&'\8fd0\52a8\7efc\5408', 28, TRUE, TRUE, 6, 2, '238'),
(114, U&'\8d5b\8f66', 29, TRUE, TRUE, 1, 2, '245'),
(115, U&'\6539\88c5\73a9\8f66', 29, TRUE, TRUE, 2, 2, '246'),
(116, U&'\65b0\80fd\6e90\8f66', 29, TRUE, TRUE, 3, 2, '247'),
(117, U&'\623f\8f66', 29, TRUE, TRUE, 4, 2, '248'),
(118, U&'\6469\6258\8f66 ', 29, TRUE, TRUE, 5, 2, '240'),
(119, U&'\8d2d\8f66\653b\7565', 29, TRUE, TRUE, 6, 2, '227'),
(120, U&'\6c7d\8f66\751f\6d3b', 29, TRUE, TRUE, 7, 2, '176'),
(121, U&'\641e\7b11', 30, TRUE, TRUE, 1, 2, '138'),
(122, U&'\51fa\884c', 30, TRUE, TRUE, 2, 2, '250'),
(123, U&'\4e09\519c', 30, TRUE, TRUE, 3, 2, '251'),
(124, U&'\5bb6\5c45\623f\4ea7', 30, TRUE, TRUE, 4, 2, '239'),
(125, U&'\624b\5de5 ', 30, TRUE, TRUE, 5, 2, '161'),
(126, U&'\7ed8\753b', 30, TRUE, TRUE, 6, 2, '162'),
(127, U&'\65e5\5e38', 30, TRUE, TRUE, 7, 2, '21'),
(128, U&'\7f8e\98df\5236\4f5c', 31, TRUE, TRUE, 1, 2, '76'),
(129, U&'\7f8e\98df\4fa6\63a2', 31, TRUE, TRUE, 2, 2, '212'),
(130, U&'\7f8e\98df\6d4b\8bc4', 31, TRUE, TRUE, 3, 2, '213'),
(131, U&'\7530\56ed\7f8e\98df', 31, TRUE, TRUE, 4, 2, '214'),
(132, U&'\7f8e\98df\8bb0\5f55 ', 31, TRUE, TRUE, 5, 2, '215'),
(133, U&'\55b5\661f\4eba', 32, TRUE, TRUE, 1, 2, '218'),
(134, U&'\6c6a\661f\4eba', 32, TRUE, TRUE, 2, 2, '219'),
(135, U&'\5927\718a\732b', 32, TRUE, TRUE, 3, 2, '220'),
(136, U&'\91ce\751f\52a8\7269', 32, TRUE, TRUE, 4, 2, '221'),
(137, U&'\722c\5ba0 ', 32, TRUE, TRUE, 5, 2, '222'),
(138, U&'\52a8\7269\7efc\5408 ', 32, TRUE, TRUE, 6, 2, '75'),
(139, U&'\7f8e\5986\62a4\80a4', 33, TRUE, TRUE, 1, 2, '157'),
(140, U&'\4eff\5986cos', 33, TRUE, TRUE, 2, 2, '252'),
(141, U&'\7a7f\642d', 33, TRUE, TRUE, 3, 2, '158');          
INSERT INTO "PUBLIC"."NAVIGATION" VALUES
(142, U&'\65f6\5c1a\6f6e\6d41', 33, TRUE, TRUE, 4, 2, '159'),
(143, U&'\9b3c\755c\8c03\6559', 34, TRUE, TRUE, 1, 2, '22'),
(144, U&'\97f3MAD', 34, TRUE, TRUE, 2, 2, '26'),
(145, U&'\4eba\529bVOCALOID', 34, TRUE, TRUE, 3, 2, '126'),
(146, U&'\9b3c\755c\5267\573a', 34, TRUE, TRUE, 4, 2, '216'),
(147, U&'\6559\7a0b\6f14\793a ', 34, TRUE, TRUE, 5, 2, '127'),
(149, U&'\6211\7684\8ffd\756a', 0, TRUE, TRUE, 13, 1, 'follow:1'),
(150, U&'\6211\7684\8ffd\5267', 0, TRUE, TRUE, 14, 1, 'follow:2'),
(151, U&'\6211\7684\6295\5e01', 0, TRUE, TRUE, 15, 1, 'coin$0'),
(152, U&'\6211\7684\70b9\8d5e', 0, TRUE, TRUE, 16, 1, 'like$0'),
(153, U&'\6211\7684\6536\85cf', 0, TRUE, TRUE, 17, 1, 'collect$0'),
(154, U&'\914d\97f3', 21, TRUE, TRUE, 8, 2, '257'),
(155, U&'AI\97f3\4e50', 23, TRUE, TRUE, 10, 2, '265'),
(156, U&'\97f3\4e50\7c89\4e1d\996d\62cd', 23, TRUE, TRUE, 10, 2, '266'),
(157, U&'\7535\53f0', 23, TRUE, TRUE, 10, 2, '267'),
(158, U&'\6c7d\8f66\77e5\8bc6\79d1\666e', 29, TRUE, TRUE, 8, 2, '258'),
(159, U&'CP\5b89\5229', 25, TRUE, TRUE, 5, 2, '262'),
(160, U&'\989c\503c\5b89\5229', 25, TRUE, TRUE, 5, 2, '263'),
(161, U&'\5a31\4e50\8d44\8baf', 25, TRUE, TRUE, 5, 2, '264'),
(162, U&'\77ed\7247', 26, TRUE, TRUE, 5, 2, '256'),
(163, U&'\5f71\89c6\6574\6d3b', 26, TRUE, TRUE, 5, 2, '260'),
(164, U&'AI\5f71\50cf', 26, TRUE, TRUE, 5, 2, '259'),
(165, U&'\5f71\89c6\7efc\5408', 26, TRUE, TRUE, 5, 2, '261'),
(166, U&'\989c\503c\00b7\7f51\7ea2\821e', 27, TRUE, TRUE, 7, 2, '255');     
CREATE CACHED TABLE "PUBLIC"."WATCHLIST_ITEM"(
    "ID" INTEGER NOT NULL,
    "UID" INTEGER NOT NULL,
    "VOD_ID" CHARACTER VARYING(250) NOT NULL,
    "STATUS" CHARACTER VARYING(16) NOT NULL,
    "TITLE" CHARACTER VARYING(250) NOT NULL,
    "year" INTEGER,
    "SEASON" INTEGER,
    "PIC" CHARACTER VARYING(512),
    "REMARKS" CHARACTER VARYING(250),
    "CREATED_TIME" BIGINT NOT NULL,
    "STATUS_TIME" BIGINT
);
ALTER TABLE "PUBLIC"."WATCHLIST_ITEM" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_E3" PRIMARY KEY("ID");               
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.WATCHLIST_ITEM;           
CREATE UNIQUE NULLS DISTINCT INDEX "PUBLIC"."UK_WATCHLIST_ITEM" ON "PUBLIC"."WATCHLIST_ITEM"("UID" NULLS FIRST, "VOD_ID" NULLS FIRST);         
CREATE INDEX "PUBLIC"."IDX_WATCHLIST_UID_STATUS" ON "PUBLIC"."WATCHLIST_ITEM"("UID" NULLS FIRST, "STATUS" NULLS FIRST);        
CREATE CACHED TABLE "PUBLIC"."PAN_ACCOUNT"(
    "ID" INTEGER NOT NULL,
    "COOKIE" CHARACTER VARYING,
    "FOLDER" CHARACTER VARYING(255),
    "MASTER" BOOLEAN NOT NULL,
    "NAME" CHARACTER VARYING(255),
    "TOKEN" CHARACTER VARYING(255),
    "TYPE" TINYINT,
    "USE_PROXY" BOOLEAN DEFAULT FALSE
); 
ALTER TABLE "PUBLIC"."PAN_ACCOUNT" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_2C" PRIMARY KEY("ID");  
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.PAN_ACCOUNT;              
CREATE CACHED TABLE "PUBLIC"."PIK_PAK_ACCOUNT"(
    "ID" INTEGER NOT NULL,
    "MASTER" BOOLEAN NOT NULL,
    "NICKNAME" CHARACTER VARYING(255),
    "PASSWORD" CHARACTER VARYING(255),
    "PLATFORM" CHARACTER VARYING(255),
    "REFRESH_TOKEN_METHOD" CHARACTER VARYING(255),
    "USERNAME" CHARACTER VARYING(255),
    "OWNER_UID" INTEGER DEFAULT 0 NOT NULL,
    "SHARED" BOOLEAN DEFAULT TRUE NOT NULL
);             
ALTER TABLE "PUBLIC"."PIK_PAK_ACCOUNT" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_A" PRIMARY KEY("ID");               
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.PIK_PAK_ACCOUNT;          
CREATE INDEX "PUBLIC"."IDX_PIKPAK_ACCOUNT_USERNAME" ON "PUBLIC"."PIK_PAK_ACCOUNT"("USERNAME" NULLS FIRST);     
CREATE CACHED TABLE "PUBLIC"."MOVIE_DIFF"(
    "VERSION" CHARACTER VARYING(50) NOT NULL,
    "STATUS" CHARACTER VARYING(16) NOT NULL,
    "STATEMENTS" INTEGER DEFAULT 0 NOT NULL,
    "FAILED" INTEGER DEFAULT 0 NOT NULL,
    "ATTEMPTS" INTEGER DEFAULT 0 NOT NULL,
    "UPDATED_TIME" TIMESTAMP NOT NULL
);
ALTER TABLE "PUBLIC"."MOVIE_DIFF" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_B1" PRIMARY KEY("VERSION");              
-- 14 +/- SELECT COUNT(*) FROM PUBLIC.MOVIE_DIFF;              
INSERT INTO "PUBLIC"."MOVIE_DIFF" VALUES
('1343.2028', 'SUCCESS', 5, 0, 1, TIMESTAMP '2026-09-20 08:34:46.210269'),
('1344.2008', 'SUCCESS', 3, 0, 1, TIMESTAMP '2026-09-20 08:34:46.285043'),
('1345.2053', 'SUCCESS', 6, 0, 1, TIMESTAMP '2026-09-20 08:34:46.358367'),
('1346.2026', 'SUCCESS', 10, 0, 1, TIMESTAMP '2026-09-20 08:34:46.498654'),
('1347.1108', 'SUCCESS', 6, 0, 1, TIMESTAMP '2026-09-20 08:34:46.589883'),
('1348.1902', 'SUCCESS', 1158, 0, 1, TIMESTAMP '2026-09-20 08:34:50.152563'),
('1349.2001', 'SUCCESS', 15, 0, 1, TIMESTAMP '2026-09-20 08:34:50.190033'),
('1350.21', 'SUCCESS', 7, 0, 1, TIMESTAMP '2026-09-20 08:34:50.280748'),
('1351.2114', 'SUCCESS', 7, 0, 1, TIMESTAMP '2026-09-20 08:34:50.32583'),
('1352.2235', 'SUCCESS', 5, 0, 1, TIMESTAMP '2026-09-20 08:34:50.374386'),
('1354.1104', 'SUCCESS', 12, 0, 1, TIMESTAMP '2026-09-20 08:34:50.453743'),
('1355.2157', 'SUCCESS', 9, 0, 1, TIMESTAMP '2026-09-20 08:34:50.488423'),
('1358.1912', 'SUCCESS', 9, 0, 1, TIMESTAMP '2026-09-20 08:34:50.541201'),
('1359.201', 'SUCCESS', 23, 0, 1, TIMESTAMP '2026-09-20 08:34:50.609133');          
CREATE CACHED TABLE "PUBLIC"."PLUGIN"(
    "ID" INTEGER NOT NULL,
    "CONTENT" CHARACTER VARYING,
    "ENABLED" BOOLEAN NOT NULL,
    "EXTERNAL_ID" CHARACTER VARYING(255),
    "LAST_CHECKED_AT" TIMESTAMP,
    "LAST_ERROR" CHARACTER VARYING,
    "LOCAL_PATH" CHARACTER VARYING(255),
    "NAME" CHARACTER VARYING(255),
    "SORT_ORDER" INTEGER NOT NULL,
    "SOURCE_NAME" CHARACTER VARYING(255),
    "URL" CHARACTER VARYING,
    "extend" CHARACTER VARYING,
    "version" INTEGER
);               
ALTER TABLE "PUBLIC"."PLUGIN" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_8C" PRIMARY KEY("ID");       
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.PLUGIN;   
CREATE INDEX "PUBLIC"."IDX_PLUGIN_EXTERNAL_ID" ON "PUBLIC"."PLUGIN"("EXTERNAL_ID" NULLS FIRST);
CREATE INDEX "PUBLIC"."IDX_PLUGIN_URL" ON "PUBLIC"."PLUGIN"("URL" NULLS FIRST);
CREATE CACHED TABLE "PUBLIC"."PLUGIN_FILTER"(
    "ID" INTEGER NOT NULL,
    "CONTENT" CHARACTER VARYING,
    "ENABLED" BOOLEAN NOT NULL,
    "ERROR_STRATEGY" CHARACTER VARYING(255),
    "LAST_CHECKED_AT" TIMESTAMP,
    "LAST_ERROR" CHARACTER VARYING,
    "NAME" CHARACTER VARYING(255),
    "PLUGIN_IDS" CHARACTER VARYING(255),
    "PLUGIN_SCOPE" CHARACTER VARYING(255),
    "SORT_ORDER" INTEGER NOT NULL,
    "SOURCE_NAME" CHARACTER VARYING(255),
    "STAGES" CHARACTER VARYING(255),
    "URL" CHARACTER VARYING,
    "extend" CHARACTER VARYING,
    "version" INTEGER
);     
ALTER TABLE "PUBLIC"."PLUGIN_FILTER" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_D" PRIMARY KEY("ID"); 
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.PLUGIN_FILTER;            
CREATE INDEX "PUBLIC"."IDX_PLUGIN_FILTER_URL" ON "PUBLIC"."PLUGIN_FILTER"("URL" NULLS FIRST);  
CREATE CACHED TABLE "PUBLIC"."SESSION"(
    "ID" INTEGER GENERATED BY DEFAULT AS IDENTITY(START WITH 1 RESTART WITH 33) NOT NULL,
    "CREATE_TIME" TIMESTAMP,
    "EXPIRE_TIME" TIMESTAMP,
    "ROLE" CHARACTER VARYING(255),
    "TOKEN" CHARACTER VARYING(255),
    "USER_ID" INTEGER,
    "USERNAME" CHARACTER VARYING(255),
    "LOGIN_IP" CHARACTER VARYING(45),
    "USER_AGENT" CHARACTER VARYING(512)
);              
ALTER TABLE "PUBLIC"."SESSION" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_A1" PRIMARY KEY("ID");      
-- 4 +/- SELECT COUNT(*) FROM PUBLIC.SESSION;  
INSERT INTO "PUBLIC"."SESSION" VALUES
(2, TIMESTAMP '2026-09-19 17:11:23.88334', TIMESTAMP '2026-10-19 17:11:23.883417', 'ADMIN', '762d9352f8734c9fa28ac1dceeb4315e', 1, 'wjjxqx', '172.17.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36'),
(3, TIMESTAMP '2026-09-19 17:12:46.141516', TIMESTAMP '2026-10-19 17:12:46.141602', 'ADMIN', '3031e1f5398745fd90e26bae953835f9', 1, 'wjjxqx', '172.17.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36'),
(4, TIMESTAMP '2026-09-19 19:19:38.205292', TIMESTAMP '2026-10-19 19:19:38.205341', 'ADMIN', '131a835da09b42c6aaf8381189981495', 1, 'wjjxqx', '172.17.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36'),
(5, TIMESTAMP '2026-09-19 21:23:53.149911', TIMESTAMP '2026-10-19 21:23:53.149955', 'ADMIN', '508dc9575dee42c7a922feaf76706abf', 1, 'wjjxqx', '172.17.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36');               
CREATE CACHED TABLE "PUBLIC"."SETTING"(
    "NAME" CHARACTER VARYING(255) NOT NULL,
    "svalue" CHARACTER VARYING
);          
ALTER TABLE "PUBLIC"."SETTING" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_A12" PRIMARY KEY("NAME");   
-- 57 +/- SELECT COUNT(*) FROM PUBLIC.SETTING; 
INSERT INTO "PUBLIC"."SETTING" VALUES
('open_token_url', 'https://ycyup.cn/alipan/access_token'),
('subscription_source_sort_order_migrated', 'true'),
('token', 'j4vHw0x'),
('enabled_token', 'false'),
('fix_sid', 'true'),
('fix_sub_id', 'true'),
('install_mode', 'new'),
('tg_drivers', '9,10,5,7,8,3,2,0,6,1,12,magnet,ed2k'),
('tgDriverOrder', '9,10,5,7,8,3,2,0,6,1,12,magnet,ed2k,11'),
('tg_timeout', '5000'),
('search_excluded_paths', U&'/\7535\89c6\5267/\97e9\56fd,/\7535\89c6\5267/\82f1\56fd,/\7535\89c6\5267/\6e2f\53f0,/\7535\89c6\5267/\6cf0\5267,/\7535\89c6\5267/\6b27\7f8e,/\7535\89c6\5267/\65e5\672c,/\7535\89c6\5267/\65b0\52a0\5761,/\7535\89c6\5267/\4fc4\7f57\65af/,/\7535\89c6\5267/\6cd5\56fd/,/\7535\89c6\5267/\5fb7\56fd/,/\7535\89c6\5267/\4e2d\56fd/\4e03\7c73\84dd'),
('system_id', 'a792dba9-1b2c-4251-9300-546c205055b3'),
('api_key', 'c242975bb9384a8fb63b4a754136ccfa'),
('basic_auth_username', '7r8ZW1dB'),
('basic_auth_password', 'SRp9iw0wI1F7bdqk'),
('docker_version', 'v.2026.0902.1716(B)'),
('app_version', '1360.1555'),
('ali_secret', '5d24333fadf94374a41134c2b5881940'),
('fix_ali_concurrency', ''),
('fix_ali_chunk_size', ''),
('alist_login', 'true'),
('alist_username', 'wjjxqx'),
('alist_password', 'wjj3565198'),
('security_hardening', ''),
('atv_password', 'CMF8rWLUyVCP'),
('migrate_pan_account', 'true'),
('migrate_driver_account', 'true'),
('fix_driver_concurrency', ''),
('fix_driverChunkSize', ''),
('migrate_115_delete_code', ''),
('quark_device_id', '6bfcc3a41cc37396b65ec89f63765b1e'),
('fix_pikpak', 'true'),
('migrate_share_ids', ''),
('fix_share_path', ''),
('alist_restart_required', 'false'),
('alist_start_time', '2026-09-20T00:34:41.020778792Z'),
('movie_version', '1359.201'),
('fix_meta_id', 'true'),
('fix_emby_order', 'true'),
('fix_emby_metadata', 'true'),
('fix_emby_device_id', 'true'),
('fix_jellyfin_metadata', 'true'),
('web_pages_front_migrated', 'true'),
('anonymous_access', 'false'),
('builtin_subscription_sources', U&'{\000a  "csp_AList" : {\000a    "name" : "AList",\000a    "enabled" : false,\000a    "sortOrder" : 4\000a  },\000a  "csp_Push" : {\000a    "name" : "AT\63a8\9001",\000a    "enabled" : false,\000a    "sortOrder" : 10\000a  },\000a  "atv_home" : {\000a    "name" : "\5f71\89c6\9996\9875",\000a    "enabled" : false,\000a    "sortOrder" : 1\000a  },\000a  "csp_PianDan" : {\000a    "name" : "\7247\5355\5bfc\822a",\000a    "enabled" : false,\000a    "sortOrder" : 2\000a  },\000a  "csp_XiaoYa" : {\000a    "name" : "\672c\5730",\000a    "enabled" : false,\000a    "sortOrder" : 3\000a  },\000a  "csp_Media" : {\000a    "name" : "\6211\7684\8ffd\5267",\000a    "enabled" : false,\000a    "sortOrder" : 5\000a  },\000a  "csp_BiliBili" : {\000a    "name" : "BiliBili",\000a    "enabled" : false,\000a    "sortOrder" : 7\000a  },\000a  "csp_TgDouBan" : {\000a    "name" : "\7535\62a5\8c46\74e3",\000a    "enabled" : false,\000a    "sortOrder" : 9\000a  },\000a  "csp_TgWeb" : {\000a    "enabled" : true,\000a    "sortOrder" : 6\000a  },\000a  "csp_Live" : {\000a    "enabled" : true,\000a    "sortOrder" : 8\000a  }\000a}'),
('user_agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36'),
('tmdb_api_key', 'eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiJkZTk0MmQ3Yzc5YWQ4M2IzOWUwNjQyM2MyMjJlYThjMSIsIm5iZiI6MTcwOTIxNzY5My41OTIsInN1YiI6IjY1ZTA5NzlkMmQ1MzFhMDE4NWMwNDc0MSIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.5QiVrB4lOKDYEzkG4EFYk8D4ggWvpyk-VXmfLxb5T-U'),
('bilibili_cookie', 'SESSDATA=373609c2%2C1805363306%2Cf8c87%2A91CjDJ9JRzXhlog-zWi9vSv6lDQA6K7juZ3-tDdSyiLMwyn9tSmJr_V6FPK_5Qab2vR1YSVmNpdGdJeEpDRFdpNDVlLW00eFJwcXBWZ2FiN1dfQ0REWmxwd0ZEYmVGU2VnQXVpZFBTOU1FdmF3SlYxQmxMNVgyMDd6NVBtV0pRdDk1SWdlVjlJdjNnIIEC;bili_jct=f83dfa8d3a3ce14aab4bf4dd95c79943;DedeUserID=1323080650;DedeUserID__ckMd5=409685d2ed10c71f;sid=qljmrj3n; buvid3=3a1e3cca-6fdd-445d-9ef9-ac3b60a65beb72321infoc'),
('bilibili_token', 'd4fb99c522897382576ccb82d93c9a91'),
('playback_sync_enabled', 'true'),
('alist_token', 'openlist-77ab0b41-8562-4675-82e7-a27d91d51b15TefAWc4txnSF6GZyeHXtGENlMcONHeXSlDxH95K6PY8itUjd8YU4ox6LHcLn8tfQ');
INSERT INTO "PUBLIC"."SETTING" VALUES
('fix_site_id', 'true'),
('fix_sub_xs', 'true'),
('refresh_token_time', '2026-09-21T00:59:56.982802362Z'),
('bilibili_dash', 'true'),
('bilibili_qn', '16,32,64,74,80,112,116,120,125,126,127'),
('global_subscription_override', U&'{\000a  "notice" : "\6cb3\5317\65b0\65af\7279\7535\5b50\5de5\7a0b\6709\9650\516c\53f8",\000a  "lives" : [ {\000a    "name" : "\76f4\64ad6\56fe\6807",\000a    "type" : 0,\000a    "url" : "http://x.xinsite.top/tv.m3u",\000a    "playerType" : 2,\000a    "ua" : "okHttp/Mod-1.5.0.0",\000a    "epg" : "http://x.xinsite.top:5688/index.php?ch={name}&date={date}",\000a    "catchup" : {\000a      "type" : "append",\000a      "source" : "?livemode=4&starttime=${(b)yyyyMMdd''T''HHmm}00.00Z&endtime=${(e)yyyyMMdd''T''HHmm}00.00Z"\000a    },\000a    "logo" : "./yaya.jpg",\000a    "timeout" : 0,\000a    "boot" : false,\000a    "pass" : false\000a  }, {\000a    "name" : "\76f4\64ad6\56fe\6807-IJK",\000a    "type" : 0,\000a    "url" : "./tv.m3u",\000a    "playerType" : 1,\000a    "ua" : "okHttp/Mod-1.5.0.0",\000a    "epg" : "http://x.xinsite.top:5688/index.php?ch={name}&date={date}",\000a    "catchup" : {\000a      "type" : "append",\000a      "source" : "?livemode=4&starttime=${(b)yyyyMMdd''T''HHmm}00.00Z&endtime=${(e)yyyyMMdd''T''HHmm}00.00Z"\000a    },\000a    "logo" : "./yaya.jpg",\000a    "timeout" : 0,\000a    "boot" : false,\000a    "pass" : false\000a  }, {\000a    "name" : "\81ea\5efa\805a\540862",\000a    "type" : 0,\000a    "url" : "http://192.168.6.2:5688/tv.m3u?url=tv62",\000a    "playerType" : 2,\000a    "ua" : "okHttp/Mod-1.5.0.0",\000a    "epg" : "http://192.168.6.2:5688/index.php?ch={name}&date={date}",\000a    "catchup" : {\000a      "type" : "append",\000a      "source" : "?livemode=4&starttime=${(b)yyyyMMdd''T''HHmm}00.00Z&endtime=${(e)yyyyMMdd''T''HHmm}00.00Z"\000a    },\000a    "logo" : "./yaya.jpg",\000a    "timeout" : 0,\000a    "boot" : false,\000a    "pass" : false\000a  }, {\000a    "name" : "\81ea\5efa\805a\540862-ijk",\000a    "type" : 0,\000a    "url" : "http://192.168.6.2:5688/tv.m3u?url=tv62",\000a    "playerType" : 1,\000a    "ua" : "okHttp/Mod-1.5.0.0",\000a    "epg" : "http://192.168.6.2:5688/index.php?ch={name}&date={date}",\000a    "catchup" : {\000a      "type" : "append",\000a      "source" : "?livemode=4&starttime=${(b)yyyyMMdd''T''HHmm}00.00Z&endtime=${(e)yyyyMMdd''T''HHmm}00.00Z"\000a    },\000a    "logo" : "./yaya.jpg",\000a    "timeout" : 0,\000a    "boot" : false,\000a    "pass" : false\000a  }, {\000a    "name" : "\81ea\5efa\805a\5408V4",\000a    "type" : 0,\000a    "url" : "https://epg.xinsite.top/tv.m3u?url=tv4",\000a    "playerType" : 2,\000a    "ua" : "okHttp/Mod-1.5.0.0",\000a    "epg" : "http://epg.xinsite.top/index.php?ch={name}&date={date}",\000a    "catchup" : {\000a      "type" : "append",\000a      "source" : "?livemode=4&starttime=${(b)yyyyMMdd''T''HHmm}00.00Z&endtime=${(e)yyyyMMdd''T''HHmm}00.00Z"\000a    },\000a    "logo" : "./yaya.jpg",\000a    "timeout" : 0,\000a    "boot" : false,\000a    "pass" : false\000a  }, {\000a    "name" : "\81ea\5efa\805a\5408V4-IJK",\000a    "type" : 0,\000a    "url" : "https://epg.xinsite.top/tv.m3u?url=tv4",\000a    "playerType" : 1,\000a    "ua" : "okHttp/Mod-1.5.0.0",\000a    "epg" : "http://epg.xinsite.top/index.php?ch={name}&date={date}",\000a    "catchup" : {\000a      "type" : "append",\000a      "source" : "?livemode=4&starttime=${(b)yyyyMMdd''T''HHmm}00.00Z&endtime=${(e)yyyyMMdd''T''HHmm}00.00Z"\000a    },\000a    "logo" : "./yaya.jpg",\000a    "timeout" : 0,\000a    "boot" : false,\000a    "pass" : false\000a  }, {\000a    "name" : "\81ea\5efa\805a\5408",\000a    "type" : 0,\000a    "url" : "http://x.xinsite.top:5688/tv.m3u",\000a    "playerType" : 2,\000a    "ua" : "okHttp/Mod-1.5.0.0",\000a    "epg" : "http://x.xinsite.top:5688/index.php?ch={name}&date={date}",\000a    "catchup" : {\000a      "type" : "append",\000a      "source" : "?livemode=4&starttime=${(b)yyyyMMdd''T''HHmm}00.00Z&endtime=${(e)yyyyMMdd''T''HHmm}00.00Z"\000a    },\000a    "logo" : "./yaya.jpg",\000a    "timeout" : 0,\000a    "boot" : false,\000a    "pass" : false\000a  }, {\000a    "name" : "\81ea\5efa\805a\5408-IJK",\000a    "type" : 0,\000a    "url" : "http://x.xinsite.top:5688/tv.m3u",\000a    "playerType" : 1,\000a    "ua" : "okHttp/Mod-1.5.0.0",\000a    "epg" : "http://x.xinsite.top:5688/index.php?ch={name}&date={date}",\000a    "catchup" : {\000a      "type" : "append",\000a      "source" : "?livemode=4&starttime=${(b)yyyyMMdd''T''HHmm}00.00Z&endtime=${(e)yyyyMMdd''T''HHmm}00.00Z"\000a    },\000a    "logo" : "./yaya.jpg",\000a    "timeout" : 0,\000a    "boot" : false,\000a    "pass" : false\000a  }, {\000a    "name" : "\76f4\64ad\56fe\6807-V4",\000a    "type" : 0,\000a    "url" : "https://www.xinsite.top/tv4.m3u",\000a    "playerType" : 2,\000a    "ua" : "okHttp/Mod-1.5.0.0",\000a    "epg" : "http://epg.xinsite.top/index.php?ch={name}&date={date}",\000a    "catchup" : {\000a      "type" : "append",\000a      "source" : "?livemode=4&starttime=${(b)yyyyMMdd''T''HHmm}00.00Z&endtime=${(e)yyyyMMdd''T''HHmm}00.00Z"\000a    },\000a    "logo" : "./yaya.jpg",\000a    "timeout" : 0,\000a    "boot" : false,\000a    "pass" : false\000a  }, {\000a    "name" : "\76f4\64ad\56fe\6807IJK-V4",\000a    "type" : 0,\000a    "url" : "https://www.xinsite.top/tv4.m3u",\000a    "playerType" : 1,\000a    "ua" : "okHttp/Mod-1.5.0.0",\000a    "epg" : "http://epg.xinsite.top/index.php?ch={name}&date={date}",\000a    "catchup" : {\000a      "type" : "append",\000a      "source" : "?livemode=4&starttime=${(b)yyyyMMdd''T''HHmm}00.00Z&endtime=${(e)yyyyMMdd''T''HHmm}00.00Z"\000a    },\000a    "logo" : "./yaya.jpg",\000a    "timeout" : 0,\000a    "boot" : false,\000a    "pass" : false\000a  }, {\000a    "name" : "\91cd\5e86\8054\901a",\000a    "type" : 0,\000a    "url" : "https://ghfast.top/https://raw.githubusercontent.com/jia070310/4K-IPTV-M3U/main/m3u/%E9%87%8D%E5%BA%86%E8%81%94%E9%80%9A.m3u",\000a    "playerType" : 2,\000a    "ua" : "okHttp/Mod-1.5.0.0",\000a    "epg" : "http://x.xinsite.top:5688/index.php?ch={name}&date={date}",\000a    "catchup" : {\000a      "type" : "append",\000a      "source" : "?livemode=4&starttime=${(b)yyyyMMdd''T''HHmm}00.00Z&endtime=${(e)yyyyMMdd''T''HHmm}00.00Z"\000a    },\000a    "logo" : "./yaya.jpg",\000a    "timeout" : 0,\000a    "boot" : false,\000a    "pass" : false\000a  }, {\000a    "name" : "\91cd\5e86\8054\901a-IJK",\000a    "type" : 0,\000a    "url" : "https://ghfast.top/https://raw.githubusercontent.com/jia070310/4K-IPTV-M3U/main/m3u/%E9%87%8D%E5%BA%86%E8%81%94%E9%80%9A.m3u",\000a    "playerType" : 1,\000a    "ua" : "okHttp/Mod-1.5.0.0",\000a    "epg" : "http://x.xinsite.top:5688/index.php?ch={name}&date={date}",\000a    "catchup" : {\000a      "type" : "append",\000a      "source" : "?livemode=4&starttime=${(b)yyyyMMdd''T''HHmm}00.00Z&endtime=${(e)yyyyMMdd''T''HHmm}00.00Z"\000a    },\000a    "logo" : "./yaya.jpg",\000a    "timeout" : 0,\000a    "boot" : false,\000a    "pass" : false\000a  }, {\000a    "name" : "\5317\4eac\8054\901a",\000a    "type" : 0,\000a    "url" : "https://ghfast.top/https://raw.githubusercontent.com/jia070310/4K-IPTV-M3U/main/m3u/%E5%8C%97%E4%BA%AC%E8%81%94%E9%80%9A.m3u",\000a    "playerType" : 2,\000a    "ua" : "okHttp/Mod-1.5.0.0",\000a    "epg" : "http://x.xinsite.top:5688/index.php?ch={name}&date={date}",\000a    "catchup" : {\000a      "type" : "append",\000a      "source" : "?livemode=4&starttime=${(b)yyyyMMdd''T''HHmm}00.00Z&endtime=${(e)yyyyMMdd''T''HHmm}00.00Z"\000a    },\000a    "logo" : "./yaya.jpg",\000a    "timeout" : 0,\000a    "boot" : false,\000a    "pass" : false\000a  }, {\000a    "name" : "\5317\4eac\8054\901a-IJK",\000a    "type" : 0,\000a    "url" : "https://ghfast.top/https://raw.githubusercontent.com/jia070310/4K-IPTV-M3U/main/m3u/%E5%8C%97%E4%BA%AC%E8%81%94%E9%80%9A.m3u",\000a    "playerType" : 1,\000a    "ua" : "okHttp/Mod-1.5.0.0",\000a    "epg" : "http://x.xinsite.top:5688/index.php?ch={name}&date={date}",\000a    "catchup" : {\000a      "type" : "append",\000a      "source" : "?livemode=4&starttime=${(b)yyyyMMdd''T''HHmm}00.00Z&endtime=${(e)yyyyMMdd''T''HHmm}00.00Z"\000a    },\000a    "logo" : "./yaya.jpg",\000a    "timeout" : 0,\000a    "boot" : false,\000a    "pass" : false\000a  }, {\000a    "name" : "\5929\6d25\8054\901a",\000a    "type" : 0,\000a    "url" : "https://ghfast.top/https://raw.githubusercontent.com/jia070310/4K-IPTV-M3U/main/m3u/%E5%A4%A9%E6%B4%A5%E8%81%94%E9%80%9A.m3u",\000a    "playerType" : 2,\000a    "ua" : "okHttp/Mod-1.5.0.0",\000a    "epg" : "http://x.xinsite.top:5688/index.php?ch={name}&date={date}",\000a    "catchup" : {\000a      "type" : "append",\000a      "source" : "?livemode=4&starttime=${(b)yyyyMMdd''T''HHmm}00.00Z&endtime=${(e)yyyyMMdd''T''HHmm}00.00Z"\000a    },\000a    "logo" : "./yaya.jpg",\000a    "timeout" : 0,\000a    "boot" : false,\000a    "pass" : false\000a  }, {\000a    "name" : "\5929\6d25\8054\901a-IJK",\000a    "type" : 0,\000a    "url" : "https://ghfast.top/https://raw.githubusercontent.com/jia070310/4K-IPTV-M3U/main/m3u/%E5%A4%A9%E6%B4%A5%E8%81%94%E9%80%9A.m3u",\000a    "playerType" : 1,\000a    "ua" : "okHttp/Mod-1.5.0.0",\000a    "epg" : "http://x.xinsite.top:5688/index.php?ch={name}&date={date}",\000a    "catchup" : {\000a      "type" : "append",\000a      "source" : "?livemode=4&starttime=${(b)yyyyMMdd''T''HHmm}00.00Z&endtime=${(e)yyyyMMdd''T''HHmm}00.00Z"\000a    },\000a    "logo" : "./yaya.jpg",\000a    "timeout" : 0,\000a    "boot" : false,\000a    "pass" : false\000a  }, {\000a    "name" : "\7ec4\64ad\56fe\6807",\000a    "type" : 0,\000a    "url" : "https://www.xinsite.top/zubo/tv.m3u",\000a    "playerType" : 2,\000a    "ua" : "okHttp/Mod-1.5.0.0",\000a    "epg" : "http://x.xinsite.top:5688/index.php?ch={name}&date={date}",\000a    "catchup" : {\000a      "type" : "append",\000a      "source" : "?livemode=4&starttime=${(b)yyyyMMdd''T''HHmm}00.00Z&endtime=${(e)yyyyMMdd''T''HHmm}00.00Z"\000a    },\000a    "logo" : "./yaya.jpg",\000a    "timeout" : 0,\000a    "boot" : false,\000a    "pass" : false\000a  }, {\000a    "name" : "\7ec4\64ad\56fe\6807-IJK",\000a    "type" : 0,\000a    "url" : "https://www.xinsite.top/zubo/tv.m3u",\000a    "playerType" : 1,\000a    "ua" : "okHttp/Mod-1.5.0.0",\000a    "epg" : "http://x.xinsite.top:5688/index.php?ch={name}&date={date}",\000a    "catchup" : {\000a      "type" : "append",\000a      "source" : "?livemode=4&starttime=${(b)yyyyMMdd''T''HHmm}00.00Z&endtime=${(e)yyyyMMdd''T''HHmm}00.00Z"\000a    },\000a    "logo" : "./yaya.jpg",\000a    "timeout" : 0,\000a    "boot" : false,\000a    "pass" : false\000a  }, {\000a    "name" : "\5927\4f6c\76f4\64ad",\000a    "type" : 0,\000a    "url" : "https://live.ottiptv.cc/iptv.m3u?userid=7664369746&sign=adaa3bbe61645daae884aacf822ef6e250244028d60c83c9da9a57bcd974526d2975e8b668a3a435510f9fced115ab862bb40eb88b6123b522bed4a82f306e13aa07182c79a7fa&auth_token=1f89b6b477cea1a93673a826678af529",\000a    "playerType" : 2,\000a    "ua" : "okHttp/Mod-1.5.0.0",\000a    "epg" : "http://x.xinsite.top:5688/index.php?ch={name}&date={date}",\000a    "catchup" : {\000a      "type" : "append",\000a      "source" : "?livemode=4&starttime=${(b)yyyyMMdd''T''HHmm}00.00Z&endtime=${(e)yyyyMMdd''T''HHmm}00.00Z"\000a    },\000a    "logo" : "./yaya.jpg",\000a    "timeout" : 0,\000a    "boot" : false,\000a    "pass" : false\000a  }, {\000a    "name" : "\5927\4f6c\76f4\64ad-IJK",\000a    "type" : 0,\000a    "url" : "https://live.ottiptv.cc/iptv.m3u?userid=7664369746&sign=adaa3bbe61645daae884aacf822ef6e250244028d60c83c9da9a57bcd974526d2975e8b668a3a435510f9fced115ab862bb40eb88b6123b522bed4a82f306e13aa07182c79a7fa&auth_token=1f89b6b477cea1a93673a826678af529",\000a    "playerType" : 1,\000a    "ua" : "okHttp/Mod-1.5.0.0",\000a    "epg" : "http://x.xinsite.top:5688/index.php?ch={name}&date={date}",\000a    "catchup" : {\000a      "type" : "append",\000a      "source" : "?livemode=4&starttime=${(b)yyyyMMdd''T''HHmm}00.00Z&endtime=${(e)yyyyMMdd''T''HHmm}00.00Z"\000a    },\000a    "logo" : "./yaya.jpg",\000a    "timeout" : 0,\000a    "boot" : false,\000a    "pass" : false\000a  }, {\000a    "name" : "\76f4\64ad62\56fe\6807",\000a    "type" : 0,\000a    "url" : "http://192.168.6.2/tv62.m3u",\000a    "playerType" : 2,\000a    "ua" : "okHttp/Mod-1.5.0.0",\000a    "epg" : "http://192.168.6.2:5688/index.php?ch={name}&date={date}",\000a    "catchup" : {\000a      "type" : "append",\000a      "source" : "?livemode=4&starttime=${(b)yyyyMMdd''T''HHmm}00.00Z&endtime=${(e)yyyyMMdd''T''HHmm}00.00Z"\000a    },\000a    "logo" : "./yaya.jpg",\000a    "timeout" : 0,\000a    "boot" : false,\000a    "pass" : false\000a  }, {\000a    "name" : "\76f4\64ad62-ijk",\000a    "type" : 0,\000a    "url" : "http://192.168.6.2/tv62.m3u",\000a    "playerType" : 1,\000a    "ua" : "okHttp/Mod-1.5.0.0",\000a    "epg" : "http://192.168.6.2:5688/index.php?ch={name}&date={date}",\000a    "catchup" : {\000a      "type" : "append",\000a      "source" : "?livemode=4&starttime=${(b)yyyyMMdd''T''HHmm}00.00Z&endtime=${(e)yyyyMMdd''T''HHmm}00.00Z"\000a    },\000a    "logo" : "./yaya.jpg",\000a    "timeout" : 0,\000a    "boot" : false,\000a    "pass" : false\000a  }, {\000a    "name" : "\76f4\64ad\56fe\6807-V4",\000a    "type" : 0,\000a    "url" : "https://www.xinsite.top/tv4.m3u",\000a    "playerType" : 2,\000a    "ua" : "okHttp/Mod-1.5.0.0",\000a    "epg" : "http://epg.xinsite.top/index.php?ch={name}&date={date}",\000a    "catchup" : {\000a      "type" : "append",\000a      "source" : "?livemode=4&starttime=${(b)yyyyMMdd''T''HHmm}00.00Z&endtime=${(e)yyyyMMdd''T''HHmm}00.00Z"\000a    },\000a    "logo" : "./yaya.jpg",\000a    "timeout" : 0,\000a    "boot" : false,\000a    "pass" : false\000a  }, {\000a    "name" : "\76f4\64ad\56fe\6807IJK-V4",\000a    "type" : 0,\000a    "url" : "https://www.xinsite.top/tv4.m3u",\000a    "playerType" : 1,\000a    "ua" : "okHttp/Mod-1.5.0.0",\000a    "epg" : "http://epg.xinsite.top/index.php?ch={name}&date={date}",\000a    "catchup" : {\000a      "type" : "append",\000a      "source" : "?livemode=4&starttime=${(b)yyyyMMdd''T''HHmm}00.00Z&endtime=${(e)yyyyMMdd''T''HHmm}00.00Z"\000a    },\000a    "logo" : "./yaya.jpg",\000a    "timeout" : 0,\000a    "boot" : false,\000a    "pass" : false\000a  }, {\000a    "name" : "\672c\673a\76f4\64adV6",\000a    "type" : 0,\000a    "url" : "https://www.xinsite.top/benji.m3u",\000a    "playerType" : 2,\000a    "ua" : "okHttp/Mod-1.5.0.0",\000a    "epg" : "http://x.xinsite.top:5688/index.php?ch={name}&date={date}",\000a    "catchup" : {\000a      "type" : "append",\000a      "source" : "?livemode=4&starttime=${(b)yyyyMMdd''T''HHmm}00.00Z&endtime=${(e)yyyyMMdd''T''HHmm}00.00Z"\000a    },\000a    "logo" : "./yaya.jpg",\000a    "timeout" : 0,\000a    "boot" : false,\000a    "pass" : false\000a  }, {\000a    "name" : "\672c\673a\76f4\64adV6-IJK",\000a    "type" : 0,\000a    "url" : "https://www.xinsite.top/benji.m3u",\000a    "playerType" : 1,\000a    "ua" : "okHttp/Mod-1.5.0.0",\000a    "epg" : "http://x.xinsite.top:5688/index.php?ch={name}&date={date}",\000a    "catchup" : {\000a      "type" : "append",\000a      "source" : "?livemode=4&starttime=${(b)yyyyMMdd''T''HHmm}00.00Z&endtime=${(e)yyyyMMdd''T''HHmm}00.00Z"\000a    },\000a    "logo" : "./yaya.jpg",\000a    "timeout" : 0,\000a    "boot" : false,\000a    "pass" : false\000a  }, {\000a    "name" : "\672c\673a\76f4\64ad-V4",\000a    "type" : 0,\000a    "url" : "https://www.xinsite.top/benji4.m3u",\000a    "playerType" : 2,\000a    "ua" : "okHttp/Mod-1.5.0.0",\000a    "epg" : "http://epg.xinsite.top/index.php?ch={name}&date={date}",\000a    "catchup" : {\000a      "type" : "append",\000a      "source" : "?livemode=4&starttime=${(b)yyyyMMdd''T''HHmm}00.00Z&endtime=${(e)yyyyMMdd''T''HHmm}00.00Z"\000a    },\000a    "logo" : "./yaya.jpg",\000a    "timeout" : 0,\000a    "boot" : false,\000a    "pass" : false\000a  }, {\000a    "name" : "\672c\673a\76f4\64adIJK-V4",\000a    "type" : 0,\000a    "url" : "https://www.xinsite.top/benji4.m3u",\000a    "playerType" : 1,\000a    "ua" : "okHttp/Mod-1.5.0.0",\000a    "epg" : "http://epg.xinsite.top/index.php?ch={name}&date={date}",\000a    "catchup" : {\000a      "type" : "append",\000a      "source" : "?livemode=4&starttime=${(b)yyyyMMdd''T''HHmm}00.00Z&endtime=${(e)yyyyMMdd''T''HHmm}00.00Z"\000a    },\000a    "logo" : "./yaya.jpg",\000a    "timeout" : 0,\000a    "boot" : false,\000a    "pass" : false\000a  }, {\000a    "name" : "\76f4\64ad\575a\679c",\000a    "type" : 0,\000a    "url" : "https://39730458%40qq.com:anmjt8tq3537es8v@dav.jianguoyun.com/dav/pg/tv.m3u",\000a    "playerType" : 2,\000a    "ua" : "okHttp/Mod-1.5.0.0",\000a    "epg" : "http://epg.xinsite.top/index.php?ch={name}&date={date}",\000a    "catchup" : {\000a      "type" : "append",\000a      "source" : "?livemode=4&starttime=${(b)yyyyMMdd''T''HHmm}00.00Z&endtime=${(e)yyyyMMdd''T''HHmm}00.00Z"\000a    },\000a    "logo" : "https://39730458%40qq.com:anmjt8tq3537es8v@dav.jianguoyun.com/dav/pg/tvlogo/{name}.png",\000a    "timeout" : 0,\000a    "boot" : false,\000a    "pass" : false\000a  }, {\000a    "name" : "\76f4\64ad\575a\679cIJK",\000a    "type" : 0,\000a    "url" : "https://39730458%40qq.com:anmjt8tq3537es8v@dav.jianguoyun.com/dav/pg/tv.m3u",\000a    "playerType" : 1,\000a    "ua" : "okHttp/Mod-1.5.0.0",\000a    "epg" : "http://epg.xinsite.top/index.php?ch={name}&date={date}",\000a    "catchup" : {\000a      "type" : "append",\000a      "source" : "?livemode=4&starttime=${(b)yyyyMMdd''T''HHmm}00.00Z&endtime=${(e)yyyyMMdd''T''HHmm}00.00Z"\000a    },\000a    "logo" : "https://39730458%40qq.com:anmjt8tq3537es8v@dav.jianguoyun.com/dav/pg/tvlogo/{name}.png",\000a    "timeout" : 0,\000a    "boot" : false,\000a    "pass" : false\000a  }, {\000a    "name" : "\864e\7259\76f4\64ad6",\000a    "type" : 0,\000a    "url" : "http://x.xinsite.top:35455/huyayqk.m3u?url=http://x.xinsite.top:35455",\000a    "playerType" : 2,\000a    "ua" : "okHttp/Mod-1.5.0.0",\000a    "epg" : "http://x.xinsite.top:5688/index.php?ch={name}&date={date}",\000a    "logo" : "http://x.xinsite.top/tvlogo/{name}.png",\000a    "timeout" : 0,\000a    "boot" : false,\000a    "pass" : false\000a  }, {\000a    "name" : "\54d4\54e9\76f4\64ad6",\000a    "type" : 0,\000a    "url" : "http://x.xinsite.top:35455/bililive.m3u?url=http://x.xinsite.top:35455",\000a    "playerType" : 2,\000a    "ua" : "okHttp/Mod-1.5.0.0",\000a    "epg" : "http://x.xinsite.top:5688/index.php?ch={name}&date={date}",\000a    "logo" : "http://x.xinsite.top/tvlogo/{name}.png",\000a    "timeout" : 0,\000a    "boot" : false,\000a    "pass" : false\000a  }, {\000a    "name" : "\6597\9c7c\76f4\64ad6",\000a    "type" : 0,\000a    "url" : "http://x.xinsite.top:35455/douyuyqk.m3u?url=http://x.xinsite.top:35455",\000a    "playerType" : 2,\000a    "ua" : "okHttp/Mod-1.5.0.0",\000a    "epg" : "http://x.xinsite.top:5688/index.php?ch={name}&date={date}",\000a    "logo" : "http://x.xinsite.top/tvlogo/{name}.png",\000a    "timeout" : 0,\000a    "boot" : false,\000a    "pass" : false\000a  }, {\000a    "name" : "YY\8f6e\64ad6",\000a    "type" : 0,\000a    "url" : "http://x.xinsite.top:35455/yylunbo.m3u?url=http://x.xinsite.top:35455",\000a    "playerType" : 2,\000a    "ua" : "okHttp/Mod-1.5.0.0",\000a    "epg" : "http://x.xinsite.top:5688/index.php?ch={name}&date={date}",\000a    "logo" : "http://x.xinsite.top/tvlogo/{name}.png",\000a    "timeout" : 0,\000a    "boot" : false,\000a    "pass" : false\000a  }, {\000a    "name" : "\54d4\54e9\76f4\64ad-62",\000a    "type" : 0,\000a    "url" : "http://192.168.6.2:35455/bililive.m3u?url=http://192.168.6.2:35455",\000a    "playerType" : 2,\000a    "ua" : "okHttp/Mod-1.5.0.0",\000a    "epg" : "http://192.168.6.2:5688/index.php?ch={name}&date={date}",\000a    "logo" : "http://192.168.6.2/tvlogo/{name}.png",\000a    "timeout" : 0,\000a    "boot" : false,\000a    "pass" : false\000a  }, {\000a    "name" : "\864e\7259\76f4\64ad\5916\7f51",\000a    "type" : 0,\000a    "url" : "http://iptv.xinsite.top/huyayqk.m3u?url=http://iptv.xinsite.top",\000a    "playerType" : 2,\000a    "ua" : "okHttp/Mod-1.5.0.0",\000a    "epg" : "http://x.xinsite.top:5688/index.php?ch={name}&date={date}",\000a    "logo" : "http://x.xinsite.top/tvlogo/{name}.png",\000a    "timeout" : 0,\000a    "boot" : false,\000a    "pass" : false\000a  }, {\000a    "name" : "\54d4\54e9\76f4\64ad\5916\7f51",\000a    "type" : 0,\000a    "url" : "http://iptv.xinsite.top/huyayqk.m3u?url=http://iptv.xinsite.top",\000a    "playerType" : 2,\000a    "ua" : "okHttp/Mod-1.5.0.0",\000a    "epg" : "http://x.xinsite.top:5688/index.php?ch={name}&date={date}",\000a    "logo" : "http://x.xinsite.top/tvlogo/{name}.png",\000a    "timeout" : 0,\000a    "boot" : false,\000a    "pass" : false\000a  }, {\000a    "name" : "\6597\9c7c\76f4\64ad\5916\7f51",\000a    "type" : 0,\000a    "url" : "http://iptv.xinsite.top/huyayqk.m3u?url=http://iptv.xinsite.top",\000a    "playerType" : 2,\000a    "ua" : "okHttp/Mod-1.5.0.0",\000a    "epg" : "http://x.xinsite.top:5688/index.php?ch={name}&date={date}",\000a    "logo" : "http://x.xinsite.top/tvlogo/{name}.png",\000a    "timeout" : 0,\000a    "boot" : false,\000a    "pass" : false\000a  }, {\000a    "name" : "YY\8f6e\64ad\5916\7f51",\000a    "type" : 0,\000a    "url" : "http://iptv.xinsite.top/huyayqk.m3u?url=http://iptv.xinsite.top",\000a    "playerType" : 2,\000a    "ua" : "okHttp/Mod-1.5.0.0",\000a    "epg" : "http://x.xinsite.top:5688/index.php?ch={name}&date={date}",\000a    "logo" : "http://x.xinsite.top/tvlogo/{name}.png",\000a    "timeout" : 0,\000a    "boot" : false,\000a    "pass" : false\000a  }, {\000a    "name" : "\54d4\54e9\76f4\64ad\5916\7f51",\000a    "type" : 0,\000a    "url" : "http://iptv.xinsite.top/huyayqk.m3u?url=http://iptv.xinsite.top",\000a    "playerType" : 2,\000a    "ua" : "okHttp/Mod-1.5.0.0",\000a    "epg" : "http://192.168.6.2:5688/index.php?ch={name}&date={date}",\000a    "logo" : "http://192.168.6.2/tvlogo/{name}.png",\000a    "timeout" : 0,\000a    "boot" : false,\000a    "pass" : false\000a  }, {\000a    "name" : "\6597\9c7c\76f4\64ad-62",\000a    "type" : 0,\000a    "url" : "http://192.168.6.2:35455/douyuyqk.m3u?url=http://192.168.6.2:35455",\000a    "playerType" : 2,\000a    "ua" : "okHttp/Mod-1.5.0.0",\000a    "epg" : "http://192.168.6.2:5688/index.php?ch={name}&date={date}",\000a    "logo" : "http://192.168.6.2/tvlogo/{name}.png",\000a    "timeout" : 0,\000a    "boot" : false,\000a    "pass" : false\000a  }, {\000a    "name" : "YY\8f6e\64ad-62",\000a    "type" : 0,\000a    "url" : "http://192.168.6.2:35455/yylunbo.m3u?url=http://192.168.6.2:35455",\000a    "playerType" : 2,\000a    "ua" : "okHttp/Mod-1.5.0.0",\000a    "epg" : "http://192.168.6.2:5688/index.php?ch={name}&date={date}",\000a    "logo" : "http://192.168.6.2/tvlogo/{name}.png",\000a    "timeout" : 0,\000a    "boot" : false,\000a    "pass" : false\000a  }, {\000a    "name" : "\536b\89c6\76f4\64ad",\000a    "type" : 0,\000a    "url" : "./xxxx.txt",\000a    "playerType" : 2,\000a    "ua" : "okHttp/Mod-1.5.0.0",\000a    "epg" : "http://x.xinsite.top:5688/index.php?ch={name}&date={date}",\000a    "catchup" : {\000a      "type" : "append",\000a      "source" : "?livemode=4&starttime=${(b)yyyyMMdd''T''HHmm}00.00Z&endtime=${(e)yyyyMMdd''T''HHmm}00.00Z"\000a    },\000a    "logo" : "http://x.xinsite.top/tvlogo/{name}.png",\000a    "timeout" : 0,\000a    "boot" : false,\000a    "pass" : false\000a  }, {\000a    "name" : "\536b\89c6\76f4\64ad-IJK",\000a    "type" : 0,\000a    "url" : "./xxxx.txt",\000a    "playerType" : 1,\000a    "ua" : "okHttp/Mod-1.5.0.0",\000a    "epg" : "http://x.xinsite.top:5688/index.php?ch={name}&date={date}",\000a    "catchup" : {\000a      "type" : "append",\000a      "source" : "?livemode=4&starttime=${(b)yyyyMMdd''T''HHmm}00.00Z&endtime=${(e)yyyyMMdd''T''HHmm}00.00Z"\000a    },\000a    "logo" : "http://x.xinsite.top/tvlogo/{name}.png",\000a    "timeout" : 0,\000a    "boot" : false,\000a    "pass" : false\000a  }, {\000a    "name" : "\536b\89c6\76f4\64ad2",\000a    "type" : 0,\000a    "url" : "./xxxx2.txt",\000a    "playerType" : 2,\000a    "ua" : "okHttp/Mod-1.5.0.0",\000a    "epg" : "http://x.xinsite.top:5688/index.php?ch={name}&date={date}",\000a    "catchup" : {\000a      "type" : "append",\000a      "source" : "?livemode=4&starttime=${(b)yyyyMMdd''T''HHmm}00.00Z&endtime=${(e)yyyyMMdd''T''HHmm}00.00Z"\000a    },\000a    "logo" : "http://x.xinsite.top/tvlogo/{name}.png",\000a    "timeout" : 0,\000a    "boot" : false,\000a    "pass" : false\000a  }, {\000a    "name" : "\536b\89c6\76f4\64ad2-IJK",\000a    "type" : 0,\000a    "url" : "./xxxx2.txt",\000a    "playerType" : 1,\000a    "ua" : "okHttp/Mod-1.5.0.0",\000a    "epg" : "http://x.xinsite.top:5688/index.php?ch={name}&date={date}",\000a    "catchup" : {\000a      "type" : "append",\000a      "source" : "?livemode=4&starttime=${(b)yyyyMMdd''T''HHmm}00.00Z&endtime=${(e)yyyyMMdd''T''HHmm}00.00Z"\000a    },\000a    "logo" : "http://x.xinsite.top/tvlogo/{name}.png",\000a    "timeout" : 0,\000a    "boot" : false,\000a    "pass" : false\000a  } ],\000a  "sites" : [ {\000a    "key" : "\6dd8\4e2b\4e2b",\000a    "name" : "\6dd8\4e2b\4e2b",\000a    "type" : 1,\000a    "api" : "https://vip.xinsite.top/tvbox_proxy.php/provide/vod/at/json/",\000a    "searchable" : 1,\000a    "quickSearch" : 1,\000a    "filterable" : 1,\000a    "changeable" : 1,\000a    "style" : {\000a      "type" : "rect"\000a    }\000a  }, {\000a    "key" : "360",\000a    "name" : "\+01f4a2\6dd8\4e2b\4e2b\5f71\89c6",\000a    "type" : 1,\000a    "api" : "https://360zy.com/api.php/provide/vod?",\000a    "searchable" : 1,\000a    "quickSearch" : 1,\000a    "filterable" : 0,\000a    "changeable" : 1,\000a    "style" : {\000a      "type" : "rect"\000a    },\000a    "order" : 1\000a  }, {\000a    "key" : "xinsite",\000a    "name" : "\+01f3ac\6781\5ba2\5f71\89c6",\000a    "type" : 1,\000a    "api" : "http://x.xinsite.top:8082/tvbox_proxy.php/provide/vod/at/json/",\000a    "searchable" : 1,\000a    "quickSearch" : 1,\000a    "filterable" : 0,\000a    "changeable" : 1,\000a    "style" : {\000a      "type" : "rect"\000a    }\000a  }, {\000a    "key" : "xinsite2",\000a    "name" : "\+01f3ac\6781\5ba2\5f71\89c62",\000a    "type" : 1,\000a    "api" : "http://192.168.6.2:8082/tvbox_proxy.php/provide/vod/at/json/",\000a    "searchable" : 1,\000a    "quickSearch" : 1,\000a    "filterable" : 0,\000a    "changeable" : 1,\000a    "style" : {\000a      "type" : "rect"\000a    }\000a  }, {\000a    "key" : "xinsite4",\000a    "name" : "\+01f3ac\6781\5ba2\5f71\89c63",\000a    "type" : 1,\000a    "api" : "https://vip.xinsite.top/tvbox_proxy.php/provide/vod/at/json/",\000a    "searchable" : 1,\000a    "quickSearch" : 1,\000a    "filterable" : 0,\000a    "changeable" : 1,\000a    "style" : {\000a      "type" : "rect"\000a    },\000a    "order" : 0\000a  }, {\000a    "key" : "\8c46\74e3",\000a    "name" : "\8c46\74e3\ff5c\9996\9875",\000a    "type" : 3,\000a    "api" : "csp_Douban",\000a    "searchable" : 0,\000a    "quickSearch" : 1,\000a    "filterable" : 0,\000a    "changeable" : 1,\000a    "style" : {\000a      "type" : "rect"\000a    }\000a  }, {\000a    "key" : "drpyS_\6ce5\89c6\9891[\4f18]",\000a    "name" : "\6ce5\89c6\9891[\4f18](DS)",\000a    "type" : 4,\000a    "api" : "https://drpy2.xinsite.top/api/\6ce5\89c6\9891[\4f18]",\000a    "searchable" : 1,\000a    "quickSearch" : 1,\000a    "filterable" : 1,\000a    "changeable" : 1,\000a    "style" : {\000a      "type" : "rect"\000a    }\000a  }, {\000a    "key" : "drpyS_\70ed\64ad\5f71\89c6[\4f18]",\000a    "name" : "\70ed\64ad\5f71\89c6[\4f18](DS)",\000a    "type" : 4,\000a    "api" : "https://drpy2.xinsite.top/api/\70ed\64ad\5f71\89c6[\4f18]",\000a    "searchable" : 1,\000a    "quickSearch" : 1,\000a    "filterable" : 1,\000a    "changeable" : 1,\000a    "style" : {\000a      "type" : "rect"\000a    }\000a  }, {\000a    "key" : "drpyS_\72ec\64ad\5e93[\4f18]",\000a    "name" : "\72ec\64ad\5e93[\4f18](DS)",\000a    "type" : 4,\000a    "api" : "https://drpy2.xinsite.top/api/\72ec\64ad\5e93[\4f18]",\000a    "searchable" : 1,\000a    "quickSearch" : 0,\000a    "filterable" : 1,\000a    "changeable" : 1,\000a    "style" : {\000a      "type" : "rect"\000a    }\000a  }, {\000a    "key" : "drpyS_\6c38\4e50\89c6\9891[\4f18]",\000a    "name" : "\6c38\4e50\89c6\9891[\4f18](DS)",\000a    "type" : 4,\000a    "api" : "https://drpy2.xinsite.top/api/\6c38\4e50\89c6\9891[\4f18]",\000a    "searchable" : 1,\000a    "quickSearch" : 1,\000a    "filterable" : 1,\000a    "changeable" : 1,\000a    "style" : {\000a      "type" : "rect"\000a    }\000a  }, {\000a    "key" : "drpyS_\8d1d\4e50\864e[\513f]",\000a    "name" : "\8d1d\4e50\864e[\513f](DS)",\000a    "type" : 4,\000a    "api" : "http://drpy.xinsite.top/api/\8d1d\4e50\864e[\513f]?pwd=wjj3565198",\000a    "searchable" : 0,\000a    "quickSearch" : 0,\000a    "filterable" : 0,\000a    "changeable" : 1,\000a    "style" : {\000a      "type" : "rect"\000a    }\000a  }, {\000a    "key" : "drpyS_\5154\5c0f\8d1d[\513f]",\000a    "name" : "\5154\5c0f\8d1d[\513f](DS)",\000a    "type" : 4,\000a    "api" : "http://drpy.xinsite.top/api/\5154\5c0f\8d1d[\513f]?pwd=wjj3565198",\000a    "searchable" : 2,\000a    "quickSearch" : 0,\000a    "filterable" : 0,\000a    "changeable" : 1,\000a    "style" : {\000a      "type" : "rect"\000a    }\000a  }, {\000a    "key" : "drpyS_\7231\52a8\6f2b[\6f2b]",\000a    "name" : "\7231\52a8\6f2b[\6f2b](DS)",\000a    "type" : 4,\000a    "api" : "https://drpy2.xinsite.top/api/\7231\52a8\6f2b[\6f2b]",\000a    "searchable" : 2,\000a    "quickSearch" : 0,\000a    "filterable" : 1,\000a    "changeable" : 1,\000a    "style" : {\000a      "type" : "rect"\000a    }\000a  }, {\000a    "key" : "drpyS_\7ca4\6f2b\4e4b\5bb6[\4f18]",\000a    "name" : "\7ca4\6f2b\4e4b\5bb6[\4f18](DS)",\000a    "type" : 4,\000a    "api" : "https://drpy2.xinsite.top/api/\7ca4\6f2b\4e4b\5bb6[\4f18]",\000a    "searchable" : 0,\000a    "quickSearch" : 0,\000a    "filterable" : 1,\000a    "changeable" : 1,\000a    "style" : {\000a      "type" : "rect"\000a    }\000a  }, {\000a    "key" : "drpyS_\7231\58f9\5e06",\000a    "name" : "\7231\58f9\5e06(DS)",\000a    "type" : 4,\000a    "api" : "https://drpy2.xinsite.top/api/\7231\58f9\5e06",\000a    "searchable" : 2,\000a    "quickSearch" : 0,\000a    "filterable" : 0,\000a    "changeable" : 1,\000a    "style" : {\000a      "type" : "rect"\000a    }\000a  }, {\000a    "key" : "drpyS_\68a8\56ed\884c[\620f]",\000a    "name" : "\68a8\56ed\884c[\620f](DS)",\000a    "type" : 4,\000a    "api" : "https://drpy2.xinsite.top/api/\68a8\56ed\884c[\620f]",\000a    "searchable" : 1,\000a    "quickSearch" : 0,\000a    "filterable" : 1,\000a    "changeable" : 1,\000a    "style" : {\000a      "type" : "rect"\000a    }\000a  }, {\000a    "key" : "drpyS_\7c73\5154\97f3\4e50[\542c]",\000a    "name" : "\7c73\5154\97f3\4e50[\542c](DS)",\000a    "type" : 4,\000a    "api" : "https://drpy2.xinsite.top/api/\7c73\5154\97f3\4e50[\542c]",\000a    "searchable" : 2,\000a    "quickSearch" : 0,\000a    "filterable" : 0,\000a    "changeable" : 1,\000a    "style" : {\000a      "type" : "rect"\000a    }\000a  }, {\000a    "key" : "drpyS_\873b\8713FM[\542c]",\000a    "name" : "\873b\8713FM[\542c](DS)",\000a    "type" : 4,\000a    "api" : "https://drpy2.xinsite.top/api/\873b\8713FM[\542c]",\000a    "searchable" : 0,\000a    "quickSearch" : 0,\000a    "filterable" : 0,\000a    "changeable" : 1,\000a    "style" : {\000a      "type" : "rect"\000a    }\000a  }, {\000a    "key" : "drpyS_\72d7\72d7\97f3\4e50[\542c]",\000a    "name" : "\72d7\72d7\97f3\4e50[\542c](DS)",\000a    "type" : 4,\000a    "api" : "https://drpy2.xinsite.top/api/\72d7\72d7\97f3\4e50[\542c]",\000a    "searchable" : 1,\000a    "quickSearch" : 1,\000a    "filterable" : 0,\000a    "changeable" : 1,\000a    "style" : {\000a      "type" : "rect"\000a    }\000a  }, {\000a    "key" : "drpyS_DJ\97f3\4e50[\542c]",\000a    "name" : "DJ\97f3\4e50[\542c](DS)",\000a    "type" : 4,\000a    "api" : "https://drpy2.xinsite.top/api/DJ\97f3\4e50[\542c]",\000a    "searchable" : 2,\000a    "quickSearch" : 0,\000a    "filterable" : 0,\000a    "changeable" : 1,\000a    "style" : {\000a      "type" : "rect"\000a    }\000a  }, {\000a    "key" : "drpyS_\542c\53cb[\542c]",\000a    "name" : "\542c\53cb[\542c](DS)",\000a    "type" : 4,\000a    "api" : "https://drpy2.xinsite.top/api/\542c\53cb[\542c]",\000a    "searchable" : 2,\000a    "quickSearch" : 0,\000a    "filterable" : 1,\000a    "changeable" : 1,\000a    "style" : {\000a      "type" : "rect"\000a    }\000a  }, {\000a    "key" : "drpyS_\5e03\8c37\97f3\4e50[\542c]",\000a    "name" : "\5e03\8c37\97f3\4e50[\542c](DS)",\000a    "type" : 4,\000a    "api" : "https://drpy2.xinsite.top/api/\5e03\8c37\97f3\4e50[\542c]",\000a    "searchable" : 2,\000a    "quickSearch" : 0,\000a    "filterable" : 0,\000a    "changeable" : 1,\000a    "style" : {\000a      "type" : "rect"\000a    }\000a  }, {\000a    "key" : "drpyS_\897f\996d\77ed\5267[\77ed]",\000a    "name" : "\897f\996d\77ed\5267[\77ed](DS)",\000a    "type" : 4,\000a    "api" : "https://drpy2.xinsite.top/api/\897f\996d\77ed\5267[\77ed]",\000a    "searchable" : 2,\000a    "quickSearch" : 0,\000a    "filterable" : 1,\000a    "changeable" : 1,\000a    "style" : {\000a      "type" : "rect"\000a    }\000a  }, {\000a    "key" : "drpyS_\4e03\732b\77ed\5267[\77ed]",\000a    "name" : "\4e03\732b\77ed\5267[\77ed](DS)",\000a    "type" : 4,\000a    "api" : "https://drpy2.xinsite.top/api/\4e03\732b\77ed\5267[\77ed]",\000a    "searchable" : 1,\000a    "quickSearch" : 0,\000a    "filterable" : 1,\000a    "changeable" : 1,\000a    "style" : {\000a      "type" : "rect"\000a    }\000a  }, {\000a    "key" : "drpyS_\661f\82bd\77ed\5267[\77ed]",\000a    "name" : "\661f\82bd\77ed\5267[\77ed](DS)",\000a    "type" : 4,\000a    "api" : "https://drpy2.xinsite.top/api/\661f\82bd\77ed\5267[\77ed]",\000a    "searchable" : 2,\000a    "quickSearch" : 1,\000a    "filterable" : 1,\000a    "changeable" : 1,\000a    "style" : {\000a      "type" : "rect"\000a    }\000a  } ]\000a}');           
CREATE CACHED TABLE "PUBLIC"."PLAYBACK_TOMBSTONE"(
    "ID" INTEGER NOT NULL,
    "UID" INTEGER NOT NULL,
    "SCOPE" CHARACTER VARYING(16),
    "SOURCE_KIND" CHARACTER VARYING(255),
    "SOURCE_KEY" CHARACTER VARYING(255),
    "VOD_ID" CHARACTER VARYING,
    "HISTORY_KEY" CHARACTER VARYING,
    "DELETED_AT" BIGINT NOT NULL,
    "EXPIRE_AT" BIGINT NOT NULL,
    "CHANGE_SEQ" BIGINT,
    "SYNC_SCOPE" CHARACTER VARYING(255)
);    
ALTER TABLE "PUBLIC"."PLAYBACK_TOMBSTONE" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_B" PRIMARY KEY("ID");            
-- 31 +/- SELECT COUNT(*) FROM PUBLIC.PLAYBACK_TOMBSTONE;      
INSERT INTO "PUBLIC"."PLAYBACK_TOMBSTONE" VALUES
(1, 1, 'item', 'site', 'HongGuo', 'hgv2i_c2VyaWVzX2lkOjc2NzkzNTU0MDU1MzI2NjI4MDk', 'HongGuo@@@hgv2i_c2VyaWVzX2lkOjc2NzkzNTU0MDU1MzI2NjI4MDk@@@0', 1789815315488, 1797591315488, 1789904807038, NULL),
(2, 1, 'item', 'site', 'taoyaya', '306408', 'taoyaya@@@306408@@@0', 1789815291172, 1797591291172, 1789904807062, NULL),
(3, 1, 'item', 'site', 'Guazi', '34426/0', 'Guazi@@@34426/0@@@0', 1789817937276, 1797593937276, 1789904807082, NULL),
(4, 1, 'item', 'site', 'Guazi', '62995/43', 'Guazi@@@62995/43@@@0', 1789818219435, 1797594219435, 1789904807148, NULL),
(5, 1, 'item', 'site', 'xinsite4', '337656', 'xinsite4@@@337656@@@0', 1789903371786, 1797679371786, 1789904807181, NULL),
(6, 1, 'item', 'site', 'taoyaya', '333073', 'taoyaya@@@333073@@@0', 1789815129492, 1797591129492, 1789904807197, NULL),
(7, 1, 'item', 'site', 'csp_TgWeb', 'https%3A%2F%2Fdrive.uc.cn%2Fs%2F22026053db534', 'csp_TgWeb@@@https%3A%2F%2Fdrive.uc.cn%2Fs%2F22026053db534@@@0', 1789893314705, 1797669314705, 1789904807201, NULL),
(8, 1, 'item', 'site', 'xinsite4', '375854', 'xinsite4@@@375854@@@0', 1789903360299, 1797679360299, 1789904807220, NULL),
(9, 1, 'item', 'site', 'csp_BiliBili', U&'search$\5019\8f66\5927\5385$0$0', U&'csp_BiliBili@@@search$\5019\8f66\5927\5385$0$0@@@0', 1789818179551, 1797594179551, 1789904807223, NULL),
(10, 1, 'item', 'site', 'xinsite4', '306142', 'xinsite4@@@306142@@@0', 1789818198212, 1797594198212, 1789904807243, NULL),
(11, 1, 'item', 'site', 'csp_TgWeb', 'https%3A%2F%2Fpan.quark.cn%2Fs%2F1063180c04f2', 'csp_TgWeb@@@https%3A%2F%2Fpan.quark.cn%2Fs%2F1063180c04f2@@@0', 1789893287617, 1797669287617, 1789904807261, NULL),
(12, 1, 'item', 'site', 'AlistShare', 'https://anxia.com/s/swzcho23zh9?cid=2956818097936476731_FN_Season+1_FOLDER&password=z738', 'AlistShare@@@https://anxia.com/s/swzcho23zh9?cid=2956818097936476731_FN_Season+1_FOLDER&password=z738@@@0', 1789817238300, 1797593238300, 1789904807264, NULL),
(13, 1, 'item', 'site', 'taoyaya', '382959', 'taoyaya@@@382959@@@0', 1789813175600, 1797589175600, 1789904807275, NULL),
(14, 1, 'item', 'site', 'Guazi', '12387/11', 'Guazi@@@12387/11@@@0', 1789811676352, 1797587676352, 1789904807284, NULL),
(15, 1, 'item', 'site', 'Youtube', U&'RfMQB-1EKYc$$$\4e1c\6e38\8bb0 \4e3b\9898\66f2\300a\900d\9065\6e38\300b\516b\4ed9\8fc7\6d77\5404\663e\795e\901a \516b\4ed9\805a\4e49,\4eba\95f4\6709\60c5$$$AUTHOR:\70ed\6b4c\98ce\60c5$$$CHANNELID:', U&'Youtube@@@RfMQB-1EKYc$$$\4e1c\6e38\8bb0 \4e3b\9898\66f2\300a\900d\9065\6e38\300b\516b\4ed9\8fc7\6d77\5404\663e\795e\901a \516b\4ed9\805a\4e49,\4eba\95f4\6709\60c5$$$AUTHOR:\70ed\6b4c\98ce\60c5$$$CHANNELID:@@@0', 1789815415173, 1797591415173, 1789904807291, NULL),
(16, 1, 'item', 'site', 'bili', 'BV1RGmMBAETf@115699640960160', 'bili@@@BV1RGmMBAETf@115699640960160@@@0', 1789815298419, 1797591298419, 1789904807294, NULL),
(17, 1, 'item', 'site', 'xinsite4', '383008', 'xinsite4@@@383008@@@0', 1789903324180, 1797679324180, 1789904807322, NULL),
(18, 1, 'item', 'site', 'csp_TgWeb', 'https%3A%2F%2Fwww.123684.com%2Fs%2Fu9izjv-PQUWv', 'csp_TgWeb@@@https%3A%2F%2Fwww.123684.com%2Fs%2Fu9izjv-PQUWv@@@0', 1789893329640, 1797669329640, 1789904807328, NULL),
(19, 1, 'item', 'site', 'taoyaya', '383184', 'taoyaya@@@383184@@@0', 1789814274657, 1797590274657, 1789904807346, NULL),
(20, 1, 'item', 'site', 'csp_BiliBili', U&'search$\55dc\8840\6cd5\533b$0$0', U&'csp_BiliBili@@@search$\55dc\8840\6cd5\533b$0$0@@@0', 1789811545473, 1797587545473, 1789904807351, NULL),
(21, 1, 'item', 'site', 'Guazi', '3977/20241028', 'Guazi@@@3977/20241028@@@0', 1789893399371, 1797669399371, 1789904807369, NULL),
(22, 1, 'item', 'site', 'Mogg', '/index.php/vod/detail/id/3380.html', 'Mogg@@@/index.php/vod/detail/id/3380.html@@@0', 1789817647161, 1797593647161, 1789904807383, NULL),
(23, 1, 'item', 'site', 'taoyaya', '373320', 'taoyaya@@@373320@@@0', 1789813730021, 1797589730021, 1789904807396, NULL),
(24, 1, 'item', 'site', 'xinsite2', '241609', 'xinsite2@@@241609@@@0', 1789863299813, 1797639299813, 1789904807401, NULL),
(25, 1, 'item', 'site', 'taoyaya', '233922', 'taoyaya@@@233922@@@0', 1789813078265, 1797589078265, 1789904807418, NULL);             
INSERT INTO "PUBLIC"."PLAYBACK_TOMBSTONE" VALUES
(26, 1, 'item', 'site', 'csp_TgWeb', 'https%3A%2F%2Fcloud.189.cn%2Ft%2F2EZ3aqBZfEjy', 'csp_TgWeb@@@https%3A%2F%2Fcloud.189.cn%2Ft%2F2EZ3aqBZfEjy@@@0', 1789811659883, 1797587659883, 1789904807423, NULL),
(27, 1, 'item', 'site', 'Mogg', '/index.php/vod/detail/id/8563.html', 'Mogg@@@/index.php/vod/detail/id/8563.html@@@0', 1789818388087, 1797594388087, 1789904807438, NULL),
(28, 1, 'item', 'site', 'AlistShare', 'https://anxia.com/s/swfuxfy3nu8?cid=3082918625176037952_FN_%E5%A4%A7%E9%95%BF%E4%BB%8A_FOLDER&password=qf10', 'AlistShare@@@https://anxia.com/s/swfuxfy3nu8?cid=3082918625176037952_FN_%E5%A4%A7%E9%95%BF%E4%BB%8A_FOLDER&password=qf10@@@0', 1789818331345, 1797594331345, 1789904807445, NULL),
(29, 1, 'item', 'site', 'Mogg', '/index.php/vod/detail/id/3377.html', 'Mogg@@@/index.php/vod/detail/id/3377.html@@@0', 1789817921062, 1797593921062, 1789904807461, NULL),
(30, 1, 'item', 'site', '115Share', U&'PLAYURL_115:[17.12GB] [\6c34\6d52\4f20 The Water Margin 1972][\65e5\7248 \90b5\6c0f \539f\76d8\56fd\8bed DIY\7b80\7e41\4e2d\5b57_Anitafayer][17.12GB].iso$swzfv793fwo+8888+2827019557216975947+iso+18387369984+BFE0C8ABA73B4BDC00869FC7AF4243A6EF874081', U&'115Share@@@PLAYURL_115:[17.12GB] [\6c34\6d52\4f20 The Water Margin 1972][\65e5\7248 \90b5\6c0f \539f\76d8\56fd\8bed DIY\7b80\7e41\4e2d\5b57_Anitafayer][17.12GB].iso$swzfv793fwo+8888+2827019557216975947+iso+18387369984+BFE0C8ABA73B4BDC00869FC7AF4243A6EF874081@@@0', 1789818262825, 1797594262825, 1789904807468, NULL),
(31, 1, 'item', 'site', 'HongGuo', 'hgv2i_c2VyaWVzX2lkOjc1OTQxNDY1MjExOTM0MDEzNjg', 'HongGuo@@@hgv2i_c2VyaWVzX2lkOjc1OTQxNDY1MjExOTM0MDEzNjg@@@0', 1789811627093, 1797587627093, 1789904807482, NULL);             
CREATE INDEX "PUBLIC"."IDX_PB_TOMB_CHANGE" ON "PUBLIC"."PLAYBACK_TOMBSTONE"("UID" NULLS FIRST, "CHANGE_SEQ" NULLS FIRST);      
CREATE INDEX "PUBLIC"."IDX_PB_TOMB" ON "PUBLIC"."PLAYBACK_TOMBSTONE"("UID" NULLS FIRST, "SOURCE_KIND" NULLS FIRST, "SOURCE_KEY" NULLS FIRST);  
CREATE CACHED TABLE "PUBLIC"."PLAYBACK_CHANGE_SEQUENCE"(
    "ID" INTEGER NOT NULL,
    "NEXT_VAL" BIGINT NOT NULL
);          
ALTER TABLE "PUBLIC"."PLAYBACK_CHANGE_SEQUENCE" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_A3" PRIMARY KEY("ID");     
-- 1 +/- SELECT COUNT(*) FROM PUBLIC.PLAYBACK_CHANGE_SEQUENCE; 
INSERT INTO "PUBLIC"."PLAYBACK_CHANGE_SEQUENCE" VALUES
(1, 1789960845072);     
CREATE CACHED TABLE "PUBLIC"."SITE"(
    "ID" INTEGER NOT NULL,
    "DISABLED" BOOLEAN NOT NULL,
    "FOLDER" CHARACTER VARYING(255),
    "INDEX_FILE" CHARACTER VARYING(255),
    "NAME" CHARACTER VARYING(255),
    "PASSWORD" CHARACTER VARYING(255),
    "SEARCHABLE" BOOLEAN NOT NULL,
    "SORT_ORDER" INTEGER NOT NULL,
    "STORAGE_VERSION" INTEGER,
    "TOKEN" CHARACTER VARYING(255),
    "URL" CHARACTER VARYING(255),
    "XIAOYA" BOOLEAN DEFAULT FALSE
);      
ALTER TABLE "PUBLIC"."SITE" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_26" PRIMARY KEY("ID");         
-- 2 +/- SELECT COUNT(*) FROM PUBLIC.SITE;     
INSERT INTO "PUBLIC"."SITE" VALUES
(1, FALSE, '', NULL, U&'\672c\5730', '', TRUE, 1, 4, 'openlist-77ab0b41-8562-4675-82e7-a27d91d51b15TefAWc4txnSF6GZyeHXtGENlMcONHeXSlDxH95K6PY8itUjd8YU4ox6LHcLn8tfQ', 'http://localhost', FALSE),
(2, FALSE, '', '', U&'115\5206\4eab', '', TRUE, 2, 1, '', 'http://localhost', FALSE);     
CREATE INDEX "PUBLIC"."IDX_SITE_URL" ON "PUBLIC"."SITE"("URL" NULLS FIRST);    
CREATE CACHED TABLE "PUBLIC"."X_USER"(
    "ID" INTEGER GENERATED BY DEFAULT AS IDENTITY(START WITH 1 RESTART WITH 33) NOT NULL,
    "CREATED_TIME" TIMESTAMP,
    "PASSWORD" CHARACTER VARYING(255),
    "ROLE" CHARACTER VARYING(255),
    "USERNAME" CHARACTER VARYING(255),
    "VOD_SECRET" CHARACTER VARYING(32)
);      
ALTER TABLE "PUBLIC"."X_USER" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_9B" PRIMARY KEY("ID");       
-- 1 +/- SELECT COUNT(*) FROM PUBLIC.X_USER;   
INSERT INTO "PUBLIC"."X_USER" VALUES
(1, TIMESTAMP '2026-09-19 16:56:17.334126', '$2a$10$seuX5.uAEdZQVPbo7NTRceL0MdwpipbGQpPfN.yVdMapcljb0Qmvy', 'ADMIN', 'wjjxqx', NULL);     
CREATE CACHED TABLE "PUBLIC"."TASK"(
    "ID" INTEGER NOT NULL,
    "CREATED_TIME" TIMESTAMP,
    "DATA" CHARACTER VARYING,
    "END_TIME" TIMESTAMP,
    "ERROR" CHARACTER VARYING(255),
    "NAME" CHARACTER VARYING(255),
    "RESULT" TINYINT,
    "START_TIME" TIMESTAMP,
    "STATUS" TINYINT,
    "SUMMARY" CHARACTER VARYING,
    "TASK_TYPE" CHARACTER VARYING(255),
    "UPDATED_TIME" TIMESTAMP
);  
ALTER TABLE "PUBLIC"."TASK" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_272" PRIMARY KEY("ID");        
-- 48 +/- SELECT COUNT(*) FROM PUBLIC.TASK;    
INSERT INTO "PUBLIC"."TASK" VALUES
(1, TIMESTAMP '2026-09-19 16:58:18.666509', '20260918-1544', TIMESTAMP '2026-09-19 16:58:35.855318', NULL, U&'\4e0b\8f7d\6587\4ef6 - pg', 0, TIMESTAMP '2026-09-19 16:58:18.74792', 2, U&'\6587\4ef6\4e0b\8f7d\6210\529f', 'DOWNLOAD', NULL),
(2, TIMESTAMP '2026-09-19 16:58:18.7066', '20260907-0848', TIMESTAMP '2026-09-19 16:58:58.512497', NULL, U&'\4e0b\8f7d\6587\4ef6 - zx', 0, TIMESTAMP '2026-09-19 16:58:35.872471', 2, U&'\6587\4ef6\4e0b\8f7d\6210\529f', 'DOWNLOAD', NULL),
(3, TIMESTAMP '2026-09-19 16:58:18.710015', '09.18', TIMESTAMP '2026-09-19 16:59:00.969509', NULL, U&'\4e0b\8f7d\6587\4ef6 - xs', 0, TIMESTAMP '2026-09-19 16:58:58.572479', 2, U&'\6587\4ef6\4e0b\8f7d\6210\529f', 'DOWNLOAD', NULL),
(4, TIMESTAMP '2026-09-19 16:58:35.38596', '1359.2010', TIMESTAMP '2026-09-19 16:59:01.285089', NULL, U&'\4e0b\8f7d\6587\4ef6 - movie', 0, TIMESTAMP '2026-09-19 16:59:00.973111', 2, U&'\6587\4ef6\4e0b\8f7d\6210\529f', 'DOWNLOAD', NULL),
(5, TIMESTAMP '2026-09-19 17:15:27.610884', NULL, TIMESTAMP '2026-09-20 08:34:30.734862', NULL, U&'\4e0b\8f7d\6587\4ef6 - movie', 2, TIMESTAMP '2026-09-19 17:15:27.674231', 2, NULL, 'DOWNLOAD', NULL),
(6, TIMESTAMP '2026-09-19 17:22:39.473591', NULL, TIMESTAMP '2026-09-20 08:34:30.828049', NULL, U&'\4e0b\8f7d\6587\4ef6 - movie', 2, TIMESTAMP '2026-09-19 17:22:39.480071', 2, NULL, 'DOWNLOAD', NULL),
(7, TIMESTAMP '2026-09-19 18:47:45.876585', NULL, TIMESTAMP '2026-09-20 08:34:30.833687', NULL, U&'\4e0b\8f7d\6587\4ef6 - movie', 2, TIMESTAMP '2026-09-19 18:47:45.961925', 2, NULL, 'DOWNLOAD', NULL),
(8, TIMESTAMP '2026-09-19 18:50:17.334524', NULL, TIMESTAMP '2026-09-20 08:34:30.838545', NULL, U&'\4e0b\8f7d\6587\4ef6 - movie', 2, TIMESTAMP '2026-09-19 18:50:17.350774', 2, NULL, 'DOWNLOAD', NULL),
(9, TIMESTAMP '2026-09-19 18:52:46.212412', '20260918-1544', TIMESTAMP '2026-09-19 18:52:46.565349', NULL, U&'\4e0b\8f7d\6587\4ef6 - pg', 0, TIMESTAMP '2026-09-19 18:52:46.237786', 2, U&'\6587\4ef6\4e0b\8f7d\6210\529f', 'DOWNLOAD', NULL),
(10, TIMESTAMP '2026-09-19 18:52:46.227509', '20260907-0848', TIMESTAMP '2026-09-19 18:52:46.629891', NULL, U&'\4e0b\8f7d\6587\4ef6 - zx', 0, TIMESTAMP '2026-09-19 18:52:46.571238', 2, U&'\6587\4ef6\4e0b\8f7d\6210\529f', 'DOWNLOAD', NULL),
(11, TIMESTAMP '2026-09-19 18:52:46.22917', '09.18', TIMESTAMP '2026-09-19 18:52:46.693394', NULL, U&'\4e0b\8f7d\6587\4ef6 - xs', 0, TIMESTAMP '2026-09-19 18:52:46.645325', 2, U&'\6587\4ef6\4e0b\8f7d\6210\529f', 'DOWNLOAD', NULL),
(12, TIMESTAMP '2026-09-19 19:07:36.649184', NULL, TIMESTAMP '2026-09-20 08:34:30.849269', NULL, U&'\4e0b\8f7d\6587\4ef6 - movie', 2, TIMESTAMP '2026-09-19 19:07:36.679787', 2, NULL, 'DOWNLOAD', NULL),
(14, TIMESTAMP '2026-09-19 19:19:51.347026', NULL, TIMESTAMP '2026-09-20 08:34:30.860792', NULL, U&'\4e0b\8f7d\6587\4ef6 - movie', 2, TIMESTAMP '2026-09-19 19:19:51.443547', 2, NULL, 'DOWNLOAD', NULL),
(15, TIMESTAMP '2026-09-19 19:24:16.310392', NULL, TIMESTAMP '2026-09-20 08:34:30.873641', NULL, U&'\4e0b\8f7d\6587\4ef6 - movie', 2, TIMESTAMP '2026-09-19 19:24:16.368332', 2, NULL, 'DOWNLOAD', NULL),
(16, TIMESTAMP '2026-09-19 20:03:48.168401', NULL, TIMESTAMP '2026-09-20 08:34:30.878866', NULL, U&'\4e0b\8f7d\6587\4ef6 - movie', 2, TIMESTAMP '2026-09-19 20:03:48.262222', 2, NULL, 'DOWNLOAD', NULL),
(17, TIMESTAMP '2026-09-19 20:31:07.936727', '20260919-1946', TIMESTAMP '2026-09-19 20:31:17.36595', NULL, U&'\4e0b\8f7d\6587\4ef6 - pg', 0, TIMESTAMP '2026-09-19 20:31:07.939951', 2, U&'\6587\4ef6\4e0b\8f7d\6210\529f', 'DOWNLOAD', NULL),
(18, TIMESTAMP '2026-09-19 20:31:07.94971', '20260907-0848', TIMESTAMP '2026-09-19 20:31:17.517042', NULL, U&'\4e0b\8f7d\6587\4ef6 - zx', 0, TIMESTAMP '2026-09-19 20:31:17.372433', 2, U&'\6587\4ef6\4e0b\8f7d\6210\529f', 'DOWNLOAD', NULL),
(19, TIMESTAMP '2026-09-19 20:31:07.952023', '09.18', TIMESTAMP '2026-09-19 20:31:17.566911', NULL, U&'\4e0b\8f7d\6587\4ef6 - xs', 0, TIMESTAMP '2026-09-19 20:31:17.524478', 2, U&'\6587\4ef6\4e0b\8f7d\6210\529f', 'DOWNLOAD', NULL),
(20, TIMESTAMP '2026-09-19 20:39:11.538807', NULL, TIMESTAMP '2026-09-20 08:34:30.890875', NULL, U&'\4e0b\8f7d\6587\4ef6 - movie', 2, TIMESTAMP '2026-09-19 20:39:11.543067', 2, NULL, 'DOWNLOAD', NULL);            
INSERT INTO "PUBLIC"."TASK" VALUES
(21, TIMESTAMP '2026-09-19 21:24:04.545877', NULL, TIMESTAMP '2026-09-20 08:34:30.900885', NULL, U&'\4e0b\8f7d\6587\4ef6 - movie', 2, TIMESTAMP '2026-09-19 21:24:04.552941', 2, NULL, 'DOWNLOAD', NULL),
(22, TIMESTAMP '2026-09-19 21:25:22.782384', NULL, TIMESTAMP '2026-09-20 08:34:30.911141', NULL, U&'\4e0b\8f7d\6587\4ef6 - movie', 2, TIMESTAMP '2026-09-19 21:25:22.791867', 2, NULL, 'DOWNLOAD', NULL),
(23, TIMESTAMP '2026-09-19 22:35:11.282852', NULL, TIMESTAMP '2026-09-20 08:34:30.922266', NULL, U&'\4e0b\8f7d\6587\4ef6 - movie', 2, TIMESTAMP '2026-09-19 22:35:11.287203', 2, NULL, 'DOWNLOAD', NULL),
(24, TIMESTAMP '2026-09-20 08:16:00.469015', NULL, TIMESTAMP '2026-09-20 08:34:30.934863', NULL, U&'\4e0b\8f7d\6587\4ef6 - movie', 2, TIMESTAMP '2026-09-20 08:16:00.471794', 2, NULL, 'DOWNLOAD', NULL),
(25, TIMESTAMP '2026-09-20 08:16:28.247702', '20260920-0745', TIMESTAMP '2026-09-20 08:16:37.36315', NULL, U&'\4e0b\8f7d\6587\4ef6 - pg', 0, TIMESTAMP '2026-09-20 08:16:28.254463', 2, U&'\6587\4ef6\4e0b\8f7d\6210\529f', 'DOWNLOAD', NULL),
(26, TIMESTAMP '2026-09-20 08:16:28.25202', '20260907-0848', TIMESTAMP '2026-09-20 08:16:37.611319', NULL, U&'\4e0b\8f7d\6587\4ef6 - zx', 0, TIMESTAMP '2026-09-20 08:16:37.365029', 2, U&'\6587\4ef6\4e0b\8f7d\6210\529f', 'DOWNLOAD', NULL),
(27, TIMESTAMP '2026-09-20 08:16:28.253522', '09.18', TIMESTAMP '2026-09-20 08:16:37.655955', NULL, U&'\4e0b\8f7d\6587\4ef6 - xs', 0, TIMESTAMP '2026-09-20 08:16:37.617924', 2, U&'\6587\4ef6\4e0b\8f7d\6210\529f', 'DOWNLOAD', NULL),
(28, TIMESTAMP '2026-09-20 16:09:57.354991', '1359.2010', TIMESTAMP '2026-09-20 16:09:58.039142', NULL, U&'\4e0b\8f7d\6587\4ef6 - movie', 0, TIMESTAMP '2026-09-20 16:09:57.370664', 2, U&'\6587\4ef6\4e0b\8f7d\6210\529f', 'DOWNLOAD', NULL),
(29, TIMESTAMP '2026-09-20 16:10:10.928706', NULL, NULL, NULL, U&'\4e0b\8f7d\6587\4ef6 - movie', NULL, TIMESTAMP '2026-09-20 16:10:10.939174', 1, NULL, 'DOWNLOAD', NULL),
(30, TIMESTAMP '2026-09-20 16:10:33.299533', '20260920-1444', TIMESTAMP '2026-09-20 16:10:43.772783', NULL, U&'\4e0b\8f7d\6587\4ef6 - pg', 0, TIMESTAMP '2026-09-20 16:10:33.30981', 2, U&'\6587\4ef6\4e0b\8f7d\6210\529f', 'DOWNLOAD', NULL),
(31, TIMESTAMP '2026-09-20 16:10:33.31206', '20260907-0848', TIMESTAMP '2026-09-20 16:10:43.918769', NULL, U&'\4e0b\8f7d\6587\4ef6 - zx', 0, TIMESTAMP '2026-09-20 16:10:43.777467', 2, U&'\6587\4ef6\4e0b\8f7d\6210\529f', 'DOWNLOAD', NULL),
(32, TIMESTAMP '2026-09-20 16:10:33.314606', '09.20', TIMESTAMP '2026-09-20 16:10:46.048676', NULL, U&'\4e0b\8f7d\6587\4ef6 - xs', 0, TIMESTAMP '2026-09-20 16:10:43.931886', 2, U&'\6587\4ef6\4e0b\8f7d\6210\529f', 'DOWNLOAD', NULL),
(33, TIMESTAMP '2026-09-20 16:12:44.27854', NULL, NULL, NULL, U&'\4e0b\8f7d\6587\4ef6 - movie', NULL, TIMESTAMP '2026-09-20 16:12:44.286313', 1, NULL, 'DOWNLOAD', NULL),
(34, TIMESTAMP '2026-09-20 17:29:31.686055', NULL, NULL, NULL, U&'\4e0b\8f7d\6587\4ef6 - movie', NULL, TIMESTAMP '2026-09-20 17:29:31.690644', 1, NULL, 'DOWNLOAD', NULL),
(35, TIMESTAMP '2026-09-20 17:30:20.749874', '20260920-1600', TIMESTAMP '2026-09-20 17:30:29.024209', NULL, U&'\4e0b\8f7d\6587\4ef6 - pg', 0, TIMESTAMP '2026-09-20 17:30:20.759892', 2, U&'\6587\4ef6\4e0b\8f7d\6210\529f', 'DOWNLOAD', NULL),
(36, TIMESTAMP '2026-09-20 17:30:20.751674', '20260907-0848', TIMESTAMP '2026-09-20 17:30:29.152474', NULL, U&'\4e0b\8f7d\6587\4ef6 - zx', 0, TIMESTAMP '2026-09-20 17:30:29.028318', 2, U&'\6587\4ef6\4e0b\8f7d\6210\529f', 'DOWNLOAD', NULL),
(37, TIMESTAMP '2026-09-20 17:30:20.752656', '09.20', TIMESTAMP '2026-09-20 17:30:29.195174', NULL, U&'\4e0b\8f7d\6587\4ef6 - xs', 0, TIMESTAMP '2026-09-20 17:30:29.154364', 2, U&'\6587\4ef6\4e0b\8f7d\6210\529f', 'DOWNLOAD', NULL),
(38, TIMESTAMP '2026-09-20 19:33:58.339845', NULL, NULL, NULL, U&'\4e0b\8f7d\6587\4ef6 - movie', NULL, TIMESTAMP '2026-09-20 19:33:58.348071', 1, NULL, 'DOWNLOAD', NULL),
(39, TIMESTAMP '2026-09-20 19:35:25.177594', NULL, NULL, NULL, U&'\4e0b\8f7d\6587\4ef6 - movie', NULL, TIMESTAMP '2026-09-20 19:35:25.187078', 1, NULL, 'DOWNLOAD', NULL),
(40, TIMESTAMP '2026-09-20 20:09:58.181533', '20260920-1600', TIMESTAMP '2026-09-20 20:09:58.43523', NULL, U&'\4e0b\8f7d\6587\4ef6 - pg', 0, TIMESTAMP '2026-09-20 20:09:58.186993', 2, U&'\6587\4ef6\4e0b\8f7d\6210\529f', 'DOWNLOAD', NULL);             
INSERT INTO "PUBLIC"."TASK" VALUES
(41, TIMESTAMP '2026-09-20 20:09:58.199929', '20260907-0848', TIMESTAMP '2026-09-20 20:09:58.475449', NULL, U&'\4e0b\8f7d\6587\4ef6 - zx', 0, TIMESTAMP '2026-09-20 20:09:58.43705', 2, U&'\6587\4ef6\4e0b\8f7d\6210\529f', 'DOWNLOAD', NULL),
(42, TIMESTAMP '2026-09-20 20:09:58.20438', '09.20', TIMESTAMP '2026-09-20 20:09:58.514251', NULL, U&'\4e0b\8f7d\6587\4ef6 - xs', 0, TIMESTAMP '2026-09-20 20:09:58.476899', 2, U&'\6587\4ef6\4e0b\8f7d\6210\529f', 'DOWNLOAD', NULL),
(43, TIMESTAMP '2026-09-20 20:26:58.389968', NULL, NULL, NULL, U&'\4e0b\8f7d\6587\4ef6 - movie', NULL, TIMESTAMP '2026-09-20 20:26:58.392641', 1, NULL, 'DOWNLOAD', NULL),
(44, TIMESTAMP '2026-09-20 22:16:59.826536', NULL, NULL, NULL, U&'\4e0b\8f7d\6587\4ef6 - movie', NULL, TIMESTAMP '2026-09-20 22:16:59.829411', 1, NULL, 'DOWNLOAD', NULL),
(45, TIMESTAMP '2026-09-21 10:39:04.91228', NULL, NULL, NULL, U&'\4e0b\8f7d\6587\4ef6 - movie', NULL, TIMESTAMP '2026-09-21 10:39:04.92845', 1, NULL, 'DOWNLOAD', NULL),
(46, TIMESTAMP '2026-09-21 10:39:12.439956', '20260921-0933', TIMESTAMP '2026-09-21 10:39:22.367642', NULL, U&'\4e0b\8f7d\6587\4ef6 - pg', 0, TIMESTAMP '2026-09-21 10:39:12.471232', 2, U&'\6587\4ef6\4e0b\8f7d\6210\529f', 'DOWNLOAD', NULL),
(47, TIMESTAMP '2026-09-21 10:39:12.441154', '20260907-0848', TIMESTAMP '2026-09-21 10:39:22.498031', NULL, U&'\4e0b\8f7d\6587\4ef6 - zx', 0, TIMESTAMP '2026-09-21 10:39:22.370962', 2, U&'\6587\4ef6\4e0b\8f7d\6210\529f', 'DOWNLOAD', NULL),
(48, TIMESTAMP '2026-09-21 10:39:12.441738', '09.20', TIMESTAMP '2026-09-21 10:39:22.541252', NULL, U&'\4e0b\8f7d\6587\4ef6 - xs', 0, TIMESTAMP '2026-09-21 10:39:22.499021', 2, U&'\6587\4ef6\4e0b\8f7d\6210\529f', 'DOWNLOAD', NULL),
(49, TIMESTAMP '2026-09-21 11:29:15.482167', NULL, NULL, NULL, U&'\4e0b\8f7d\6587\4ef6 - movie', NULL, TIMESTAMP '2026-09-21 11:29:15.497014', 1, NULL, 'DOWNLOAD', NULL);     
CREATE CACHED TABLE "PUBLIC"."TELEGRAM_CHANNEL"(
    "ID" BIGINT NOT NULL,
    "ACCESS_HASH" BIGINT NOT NULL,
    "ENABLED" BOOLEAN NOT NULL,
    "SORT_ORDER" INTEGER NOT NULL,
    "TITLE" CHARACTER VARYING(255),
    "TYPE" INTEGER NOT NULL,
    "USERNAME" CHARACTER VARYING(255),
    "VALID" BOOLEAN NOT NULL,
    "WEB_ACCESS" BOOLEAN NOT NULL
);    
ALTER TABLE "PUBLIC"."TELEGRAM_CHANNEL" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_E9" PRIMARY KEY("ID");             
-- 64 +/- SELECT COUNT(*) FROM PUBLIC.TELEGRAM_CHANNEL;        
INSERT INTO "PUBLIC"."TELEGRAM_CHANNEL" VALUES
(1281567720, -7516261264212772000, FALSE, 58, U&'\8fc5\96f7\4e91\76d8', -1, 'xunleiyunpan', TRUE, FALSE),
(1344815419, -7531943445487548000, TRUE, 13, U&'\61d2\72d7\96c6\4e2d\8425-115/\963f\91cc/\767e\5ea6/\8fc5\96f7/\5938\514b \5f71\89c6\5206\4eab \963f\91cc\4e91\76d8\767e\5ea6\7f51\76d8115\7f51\76d8', -1, 'vip115hot', TRUE, TRUE),
(1431002521, 1477405556333033700, TRUE, 5, U&'\75af\72c2\306e\661f\671f\56db\+01f37f\+01f37f', -1, 'KFCYeah', TRUE, FALSE),
(1469109660, -5807787899893268000, FALSE, 19, U&'\963f\91cc\4e91\76d8\53d1\5e03\9891\9053', 0, 'shareAliyun', TRUE, TRUE),
(1514918410, 5997029393838606343, FALSE, 61, U&'\52a8\6f2b\10e6\6f2b\753b', 5, 'dianyingshare', TRUE, TRUE),
(1520702906, 6360037381398135000, FALSE, 31, U&'\+01f3ac \963f\91cc\4e91\76d8\8d44\6e90 \+01f199 \+01f6a6', 0, 'zaihuayun', TRUE, TRUE),
(1598490288, -2765653269949374500, FALSE, 36, U&'\963f\91cc\4e91\76d8\8d44\6e90\641c\7d22', -1, 'aliyunshares', TRUE, FALSE),
(1674292882, -3160960352502949000, TRUE, 7, U&'\963f\91cc\3001\5938\514b\3001\767e\5ea6\7b49\7f51\76d84K\5f71\89c6\8d44\6e90', -1, 'Aliyun_4K_Movies', TRUE, TRUE),
(1723949888, -1811973884206044700, FALSE, 33, U&'\7f51\76d8\8d44\6e90(\7eaa\5f55\7247)\9891\9053', 5, 'alyp_JLP', TRUE, TRUE),
(1730775689, 3501754392396409000, FALSE, 46, U&'\7f51\76d8\8d44\6e90\8ba8\8bba\533a', -1, 'yunpanchat', TRUE, FALSE),
(1738738799, -8548012649410930000, FALSE, 51, U&'\4e91\76d8\8d44\6e90\53d1\5e03\9891\9053-\8bc4\8bba\533a\53ef\641c\7d22', 0, 'qixingzhenren', TRUE, TRUE),
(1754812960, 5918510924593753000, FALSE, 32, U&'\7f51\76d8\8d44\6e90(\7535\89c6\5267)\9891\9053', 5, 'alyp_TV', TRUE, TRUE),
(1783715708, -4858094990139272930, FALSE, 59, U&'\7f51\76d8(\9ad8\54c1\8d28)\5f71\89c6', 5, 'alyp_1', TRUE, TRUE),
(1785931263, 8064671713701422000, FALSE, 54, U&'\5929\7ffc\4e91\76d8\8d44\6e90\53d1\5e03\9891\9053', 9, 'cloudtianyi', TRUE, TRUE),
(1864209911, -1376098077992027400, TRUE, 9, U&'\5965\65af\53614K\84dd\5149(\7cbe\54c1)\5f71\89c6\78c1\529b\7ad9\+01f35f', -1, 'Oscar_4Kmovies', TRUE, TRUE),
(1871164136, -3626298013094924300, FALSE, 38, U&'\5929\7ffc\4e91\76d82\7fa4', 9, 'cloud189_group', TRUE, FALSE),
(1934703847, 7220415620182865000, FALSE, 30, U&'\7f51\76d8\8d44\6e90(\52a8\753b/\52a8\6f2b)\9891\9053', 5, 'alyp_Animation', TRUE, TRUE),
(1941021574, -7776578014181683000, FALSE, 18, U&'\7f51\76d8\8d44\6e90(\7535\5f71)\9891\9053', 5, 'alyp_4K_Movies', TRUE, TRUE),
(1959723113, 6595875366223957000, FALSE, 27, U&'\5938\514b\4e91\76d8\7efc\5408\8d44\6e90', 5, 'Quark_Movies', TRUE, TRUE),
(2021074267, -4242006413182737000, FALSE, 41, U&'\90a3\4e48\591a\7f51\76d8\7a76\7adf\5982\4f55\53bb\4f7f\7528', -1, 'share_pan', TRUE, FALSE),
(2023050367, 6921435979207574000, TRUE, 3, U&'\90a3\4e48\591a\7f51\76d8\771f\6ca1\90a3\4e48\591a\4e8b\513f', -1, 'SharePanBaidu', TRUE, FALSE),
(2101294501, 3112934083899780000, FALSE, 40, U&'\5938\514b\6d4f\89c8\5668\2122\7684\4e8c\4e09\4e8b\513f\53cd\9988\7fa4/\4ea4\6d41\8bf7\52a0 @Quark_Share_Group\ff08\7981\6b62\52a0\5165\ff09', 5, 'NSFW_Quark', TRUE, FALSE),
(2110524172, 522815723089697600, FALSE, 21, U&'\767e\5ea6\7f51\76d8\7efc\5408\9891\9053', 10, 'bdwpzhpd', TRUE, TRUE),
(2121362585, 5455542343593102000, TRUE, 28, U&'115\7f51\76d8\8d44\6e90\5206\4eab\9891\9053', 8, 'Lsp115', TRUE, TRUE),
(2161339929, 6830707267405989000, FALSE, 29, U&'\76d8\9171\9171Club\+01f308', 5, 'PanjClub', TRUE, TRUE),
(2167886055, 4281990202073309000, TRUE, 35, U&'115\7f51\76d8\8d44\6e90\6536\85cf', 8, 'oneonefivewpfx', TRUE, TRUE),
(2177855695, -8246820731055631000, TRUE, 11, U&'\767e\5ea6\7f51\76d8\8d44\6e90\5206\4eab', 10, 'BaiduCloudDisk', TRUE, TRUE),
(2188663986, -3347557024702104600, TRUE, 53, 'Shares_115_Channel', 8, 'Channel_Shares_115', TRUE, TRUE),
(2197007471, 6015357312323779000, FALSE, 45, U&'\76d8\9171\9171Club\5f00\5fc3\7fa4', 5, 'PanjjClub', TRUE, FALSE),
(2204035832, -6957125960970784471, FALSE, 62, U&'\5f71\89c6\70ed\95e8\66f4\65b0', 5, 'hdhhd21', TRUE, TRUE),
(2228081326, 4259547594327125000, TRUE, 8, U&'\7f51\76d8\8d44\6e90\6536\85cf(\7efc\5408)\8ba8\8bba\533a', -1, 'YPallChat', TRUE, FALSE); 
INSERT INTO "PUBLIC"."TELEGRAM_CHANNEL" VALUES
(2244753465, -5787467105409569000, FALSE, 44, U&'\767e\5ea6\7f51\76d8\5206\4eab\3010\4ea4\6d41\7fa4\3011', 10, 'BaiduCloudDiskchat', TRUE, FALSE),
(2245898899, 8783507736659227000, TRUE, 52, U&'115\5f71\89c6\8d44\6e90\5206\4eab\9891\9053', 8, 'QukanMovie', TRUE, TRUE),
(2255128290, 4860567457274884574, FALSE, 64, U&'LEO\7f51\76d8\641c\96c6', 5, 'leoziyuan', TRUE, TRUE),
(2258594100, -1254277485380665600, FALSE, 23, U&'\7f51\76d8\8d44\6e90\6536\85cf(\8fc5\96f7\4e91\76d8)', 2, 'yunpanxunlei', TRUE, TRUE),
(2295602839, 9066564069833649000, FALSE, 47, U&'\7f51\76d8\8d44\6e90\6536\85cf(\79fb\52a8\4e91\76d8)', 6, 'yunpan139', TRUE, TRUE),
(2310771279, -5196808501705779000, FALSE, 20, '112233', 3, 'zyfb123', TRUE, TRUE),
(2330381084, -6059575258041815000, FALSE, 49, U&'115\7f51\76d8\8d44\6e90\53d1\5e03', 8, 'ysxb48', TRUE, TRUE),
(2343614575, 255770793619690620, FALSE, 43, U&'\8d44\6e90\5b87\5b99[\7fa4\7ec4]', -1, 'ResourceUniverse', TRUE, FALSE),
(2346815333, -3924786434258599000, TRUE, 17, U&'\7f51\76d8\8d44\6e90\5408\96c6\9891\9053', -1, 'yydf_hzl', TRUE, TRUE),
(2360216293, 8067246005996964000, TRUE, 12, U&'\5929\7ffc\4e91\76d8\8d44\6e90\9891\9053', 9, 'tianyirigeng', TRUE, TRUE),
(2364282469, -6004654727248164000, FALSE, 39, U&'123\4e91\76d8\4ea4\6d41\4e92\52a9\7fa4', 3, 'xx123pan1', TRUE, FALSE),
(2377909685, -4139536853427361300, TRUE, 10, U&'\6211\7684\8d44\6e90\9891\9053', -1, 'taoxgzy', TRUE, TRUE),
(2387978917, -2477838294311916000, FALSE, 56, U&'\5929\7ffc\4e91\76d8\7efc\5408\9891\9053', 9, 'tyypzhpd', TRUE, TRUE),
(2390179057, 6916552512628745000, TRUE, 4, U&'UC\5938\514b\767e\5ea6\8fc5\96f7\8d44\6e90\5206\4eab', -1, 'ucquark', TRUE, TRUE),
(2403035372, 4979388029557253000, TRUE, 15, U&'\52a8\6f2b\ff5c\5f71\89c6\ff5c\5938\514bUC\963f\91cc\7f51\76d8\8d44\6e90 \6bcf\65e5\66f4\65b0', -1, 'yggpan', TRUE, TRUE),
(2418548288, -7044175180570117000, FALSE, 48, U&'\4e00\751f\76f8\4f34', 8, 'ysxb69', TRUE, FALSE),
(2438273165, 2668332394048518621, FALSE, 60, 'ClouddriveResources', 5, 'clouddriveresources', TRUE, TRUE),
(2445082199, -3187465304536364000, FALSE, 26, U&'\7f51\76d8\8d44\6e90\6536\85cf(UC\7f51\76d8)', 7, 'yunpanuc', TRUE, TRUE),
(2450480448, -7883065161223288000, FALSE, 50, U&'\963f\91cc\5df4\5df4\5f71\4e1a\96c6\56e2\2122', 0, 'NewAliPan', TRUE, TRUE),
(2462269637, -7306613997821041000, FALSE, 42, U&'\98ce\8f66\7f51\76d8\8d44\6e90\4ea4\6d41\53cd\9988\7fa4', -1, 'uckuake', TRUE, FALSE),
(2463707870, -7266561220804366000, FALSE, 24, U&'\5938\514b\6d4f\89c8\5668\2122\7684\4e8c\4e09\4e8b\513f', 5, 'NewQuark', TRUE, TRUE),
(2465812117, -7992478171801823000, TRUE, 1, U&'\8d44\6e90\5b87\5b99[\9891\9053]', -1, 'tgsearchers2', TRUE, TRUE),
(2483434865, -9010742194592091541, FALSE, 63, U&'\77ed\5267\7f51\76d8\5206\4eab', 5, 'jdjdn1111', TRUE, TRUE),
(2491519755, -3666014754287934000, FALSE, 37, U&'123\4e91\76d8\793e\533a Chat', -1, 'fx123pan2', TRUE, FALSE),
(2535456987, 6638679219572630000, FALSE, 34, U&'\7f51\76d8\8d44\6e90\6536\85cf(\5929\7ffc\4e91\76d8)', 9, 'yunpan189', TRUE, TRUE),
(2540268595, 3868302408678678000, FALSE, 25, U&'\7f51\76d8\8d44\6e90\6536\85cf(\5938\514b)', 5, 'yunpanqk', TRUE, TRUE),
(2569131519, 7900512394752158000, TRUE, 14, U&'\5929\7ffc\81fb\5f71\8d44\6e90\6536\85cf', -1, 'tyysypzypd', TRUE, TRUE),
(2572331865, -1392708004508921000, FALSE, 55, U&'\5929\7ffc\8d44\6e90\9891\9053', 9, 'txtyzy', TRUE, TRUE),
(2641312701, -516392087781629500, FALSE, 22, U&'\7f51\76d8\8d44\6e90\6536\85cf(123\4e91\76d8)', 3, 'yp123pan', TRUE, TRUE),
(2673757125, 5552044248872124000, FALSE, 57, U&'\4e91\5de2-\7f51\76d8\8d44\6e90\4ea4\6d41\7fa4', -1, 'peccxin', TRUE, FALSE),
(2686241784, 7260421638068036000, TRUE, 6, U&'\7f51\76d8\8d44\6e90\6536\85cf(\7efc\5408)', -1, 'yunpansall', TRUE, TRUE),
(2710552707, 1269619016327949101, TRUE, 2, U&'\80af\5fb7\57fa\306e4K\5f71\89c6\7efc\5408\7535\5f71\4e91\76d8\7ad9', -1, 'XiangxiuNBB', TRUE, TRUE),
(2805439841, -387663177843436700, TRUE, 16, U&'\4e91\5de2-\7f51\76d8\8d44\6e90\9891\9053', -1, 'peccxinpd', TRUE, TRUE); 
CREATE CACHED TABLE "PUBLIC"."TENANT"(
    "ID" INTEGER NOT NULL,
    "EXCLUDE" CHARACTER VARYING,
    "INCLUDE" CHARACTER VARYING,
    "NAME" CHARACTER VARYING(255) NOT NULL
);              
ALTER TABLE "PUBLIC"."TENANT" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_93" PRIMARY KEY("ID");       
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.TENANT;   
CREATE CACHED TABLE "PUBLIC"."TMDB_META"(
    "ID" INTEGER NOT NULL,
    "NAME" CHARACTER VARYING(255),
    "PATH" CHARACTER VARYING(255),
    "SCORE" INTEGER,
    "SITE_ID" INTEGER,
    "TID" INTEGER,
    "TIME" TIMESTAMP,
    "TM_ID" INTEGER,
    "TMDB_ID" INTEGER,
    "TYPE" CHARACTER VARYING(255),
    "year" INTEGER
);           
ALTER TABLE "PUBLIC"."TMDB_META" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_68" PRIMARY KEY("ID");    
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.TMDB_META;
CREATE CACHED TABLE "PUBLIC"."PLAY_URL"(
    "ID" INTEGER NOT NULL,
    "PATH" CHARACTER VARYING NOT NULL,
    "RATING" INTEGER,
    "REFERER" CHARACTER VARYING(255),
    "SITE" INTEGER NOT NULL,
    "TIME" TIMESTAMP,
    "OWNER_UID" INTEGER DEFAULT 0 NOT NULL
);        
ALTER TABLE "PUBLIC"."PLAY_URL" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_9" PRIMARY KEY("ID");      
-- 872 +/- SELECT COUNT(*) FROM PUBLIC.PLAY_URL;               
INSERT INTO "PUBLIC"."PLAY_URL" VALUES
(31, U&'/115\5206\4eab\7d22\5f15', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:47.080061', 0),
(32, U&'/115\5206\4eab\7d22\5f15/4K\539f\76d8 252V 16.94T', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:51.88245', 0),
(33, U&'/115\5206\4eab\7d22\5f15/\8c46\74e3\7535\5f71Top250_12.65TB', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:51.913111', 0),
(34, U&'/115\5206\4eab\7d22\5f15/\8c46\74e3\7535\5f71Top250_12.65TB/194.[\726f\5cad\8857\5c11\5e74\6740\4eba\4e8b\4ef6 A Brighter Summer Day 1991][\53cc\789f][\8c46\74e3\7535\5f71\8bc4\52068.9][CC\7248 4K\4fee\590d\7248 \56fd\8bed \8ffd\52a0\6b63\7247+\82b1\7d6e\7b80\4e2d][blucook#1@CHD-6939][tt0101985][88.05GB]', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:54.591386', 0),
(35, U&'/115\5206\4eab\7d22\5f15/\8c46\74e3\7535\5f71Top250_12.65TB/1.[\8096\7533\514b\7684\6551\8d4e The Shawshank Redemption 1994][\8c46\74e3\7535\5f71\8bc4\52069.7][4K][DIY\4e09\6b21\56fd \4e09\56fd\914d\7b80\7e41+\53cc\8bed\7279\6548\5b57\5e55][SGNB@CHD-165187][tt0111161][68.27GB].iso', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:54.607495', 0),
(36, U&'/115\5206\4eab\7d22\5f15/\8c46\74e3\7535\5f71Top250_12.65TB/10.[\695a\95e8\7684\4e16\754c The Truman Show 1998][\8c46\74e3\7535\5f71\8bc4\52069.4][4K][DIY\56fd\914d\7b80\4f53+\7b80\82f1\53cc\8bed\7279\6548\5b57\5e55 \4fdd\7559Dolby Vision][BHYS@OB-222025][tt0120382][60.16GB].iso', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:54.653298', 0),
(37, U&'/115\5206\4eab\7d22\5f15/\8c46\74e3\7535\5f71Top250_12.65TB/100.[\5510\4f2f\864e\70b9\79cb\9999 Flirting Scholar 1993][\8c46\74e3\7535\5f71\8bc4\52068.7][\6cd5\7248 \81ea\5e26\7ca4\8bed DIY\56fd\53f0\8bed \56fd\7ca4\914d\7b80\7e41\5b57\5e55V2\7248][FFansDIY@\81f3\5c0a\5b9d-HDS-350050][tt0108289][35.68GB].iso', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:54.659809', 0),
(38, U&'/115\5206\4eab\7d22\5f15/\8c46\74e3\7535\5f71Top250_12.65TB/101.[7\53f7\623f\7684\793c\7269 Miracle in Cell No. 7 2013][\8c46\74e3\7535\5f71\8bc4\52068.9][\6e2f\7248DIY\53f0\914d\56fd\8bed \53f0\914d\7b80\7e41+\53cc\8bed\7279\6548\5b57\5e55][bbba@HDS-260777][tt2659414][34.74GB].iso', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:54.663734', 0),
(39, U&'/115\5206\4eab\7d22\5f15/\8c46\74e3\7535\5f71Top250_12.65TB/102.[\88ab\5acc\5f03\7684\677e\5b50\7684\4e00\751f Memories of Matsuko 2006][\8c46\74e3\7535\5f71\8bc4\52068.9][DIY R3TW\7b80\7e41\5b57\5e55][DIY@HDH-46227][tt0768120][39.47GB].iso', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:54.701361', 0),
(40, U&'/115\5206\4eab\7d22\5f15/\8c46\74e3\7535\5f71Top250_12.65TB/103.[\8759\8760\4fa0\ff1a\9ed1\6697\9a91\58eb\5d1b\8d77 The Dark Knight Rises 2012][\8c46\74e3\7535\5f71\8bc4\52068.9][4K][DIY\6b21\56fd \56fd\914d\7b80\7e41\53cc\8bed\7279\6548][SGnb@CHD-32598][tt1345836][92.53GB].iso', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:54.736998', 0),
(41, U&'/115\5206\4eab\7d22\5f15/\8c46\74e3\7535\5f71Top250_12.65TB/104.[\751c\871c\871c Comrades: Almost a Love Story 1996][\8c46\74e3\7535\5f71\8bc4\52068.9][\53f0\7248DIY\6b21\56fd \56fd\7ca4\914d\7b80\4f53\5b57\5e55][BHYS@CHD-123263][tt0117905][24.06GB].iso', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:54.75398', 0),
(42, U&'/115\5206\4eab\7d22\5f15/\8c46\74e3\7535\5f71Top250_12.65TB/105.[\7231\5728\9ece\660e\7834\6653\524d Before Sunrise 1995][\8c46\74e3\7535\5f71\8bc4\52068.8][[CC\7248 DIY\56fd\8bed\7b80\4f53+\7b80\82f1\53cc\8bed\7279\6548\5b57\5e55][BHYS@OB-235953][tt0112471][45.68GB].iso', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:54.784736', 0),
(43, U&'/115\5206\4eab\7d22\5f15/\8c46\74e3\7535\5f71Top250_12.65TB/106.[\8bf7\4ee5\4f60\7684\540d\5b57\547c\5524\6211 Call Me by Your Name 2017][\8c46\74e3\7535\5f71\8bc4\52068.8][4K][DIY\7b80\4f53+\53cc\8bed\7279\6548\5b57\5e55 \4fdd\7559Vision][BHYS@OB-214507][tt5726616][81.96GB].iso', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:54.817302', 0),
(44, U&'/115\5206\4eab\7d22\5f15/\8c46\74e3\7535\5f71Top250_12.65TB/107.[\7b2c\516d\611f The Sixth Sense 1999][\8c46\74e3\7535\5f71\8bc4\52068.9][DIY\56fd\914d\7b80\7e41+\53cc\8bed\7279\6548\5b57\5e55 \83dc\5355\4fee\6539][bbba@HDS-263245][tt0167404][29.30GB].iso', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:54.821722', 0);           
INSERT INTO "PUBLIC"."PLAY_URL" VALUES
(45, U&'/115\5206\4eab\7d22\5f15/\8c46\74e3\7535\5f71Top250_12.65TB/108.[\8d85\80fd\9646\6218\961f Big Hero 6 2014][\8c46\74e3\7535\5f71\8bc4\52068.7][4K][DIY\56fd\7ca4\53f0\8bed \7b80\4f53+\7b80\82f1\53cc\8bed\7279\6548\5b57\5e55][BHYS@OB-243908][tt2245084][52.48GB].iso', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:54.852483', 0),
(46, U&'/115\5206\4eab\7d22\5f15/\8c46\74e3\7535\5f71Top250_12.65TB/109.[\5165\6b93\5e08 Departures 2008][\8c46\74e3\7535\5f71\8bc4\52068.9][Arrow\7248DIY\56fd\914d\7b80\7e41\7279\6548\5b57\5e55][BHYS@CHD-100193][tt1069238][36.77GB].iso', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:54.868763', 0),
(47, U&'/115\5206\4eab\7d22\5f15/\8c46\74e3\7535\5f71Top250_12.65TB/11.[\8f9b\5fb7\52d2\7684\540d\5355 Schindler''s List 1993][4K][\8c46\74e3\7535\5f71\8bc4\52069.5][DIY\53cc\6b21\4e16\4ee3\56fd\8bed \7b80\7e41+\53cc\8bed\7279\6548\5b57\5e55][LianHH@CHD-48307][tt0108052][102.27GB].iso', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:54.885794', 0),
(48, U&'/115\5206\4eab\7d22\5f15/\8c46\74e3\7535\5f71Top250_12.65TB/110.[\91cd\5e86\68ee\6797 Chungking Express 1994][4K][\8c46\74e3\7535\5f71\8bc4\52068.8][\5fb7\7248 \81ea\5e26\7ca4\8bedDIY\7b80\7e41+\53cc\8bed\7279\6548\5b57\5e55 \4fdd\7559Dolby Vision][BHYS@OB-200354][tt0109424][58.89GB].iso', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:54.902326', 0),
(49, U&'/115\5206\4eab\7d22\5f15/\8c46\74e3\7535\5f71Top250_12.65TB/111.[\65ad\80cc\5c71 Brokeback Mountain 2005][\8c46\74e3\7535\5f71\8bc4\52068.8][\5fb7\7248 DIY\7b80\4f53+\7b80\82f1\53cc\8bed\7279\6548\5b57\5e55][BHYS@OB-232330][tt0388795][40.57GB].iso', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:54.914098', 0),
(50, U&'/115\5206\4eab\7d22\5f15/\8c46\74e3\7535\5f71Top250_12.65TB/112.[\526a\5200\624b\7231\5fb7\534e Edward Scissorhands 1990][\8c46\74e3\7535\5f71\8bc4\52068.7][\6b27\7248 4K\4fee\590d\7248 \7b80\7e41\5b57\5e55][PCH-CHD-108540][tt0099487][34.70GB] .iso', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:54.918167', 0),
(51, U&'/115\5206\4eab\7d22\5f15/\8c46\74e3\7535\5f71Top250_12.65TB/113.[\5e7d\7075\516c\4e3b Princess Mononoke 1997][\8c46\74e3\7535\5f71\8bc4\52068.9][\539f\76d8DIY\56fd\7ca4\82f1\65e5\914d\97f3 \7b80\7e41+\53cc\8bed\5b57\5e55][Audies-197807][tt0119698][44.38].iso', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:54.922013', 0),
(52, U&'/115\5206\4eab\7d22\5f15/\8c46\74e3\7535\5f71Top250_12.65TB/114.[\52c7\6562\7684\5fc3 Braveheart 1995][\8c46\74e3\7535\5f71\8bc4\52068.9][4K][DIY\53cc\56fd\8bed\7b80\7e41\82f1\7279\6548 \4fdd\7559Dolby Vision][sGnB@CHD-96392][tt0112573][87.02GB].iso', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:54.924857', 0),
(53, U&'/115\5206\4eab\7d22\5f15/\8c46\74e3\7535\5f71Top250_12.65TB/115.[\7231\5728\65e5\843d\9ec4\660f\65f6 Before Sunset 2004][\8c46\74e3\7535\5f71\8bc4\52068.9][CC\7248DIY\56fd\8bed \7b80\4f53+\7b80\82f1\53cc\8bed\7279\6548\5b57\5e55][BHYS@OB-236102][tt0381681][45.90GB].iso', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:54.948682', 0),
(54, U&'/115\5206\4eab\7d22\5f15/\8c46\74e3\7535\5f71Top250_12.65TB/116.[\5bc4\751f\866b Parasite 2019][\8c46\74e3\7535\5f71\8bc4\52068.8][4K][\6cd5\7248 DIY\7b80\7e41+\53cc\8bed\7279\6548\5b57\5e55][BHYS@CHD-82505][tt6751668][89.52GB].iso', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:54.951788', 0),
(55, U&'/115\5206\4eab\7d22\5f15/\8c46\74e3\7535\5f71Top250_12.65TB/117.[\83ca\6b21\90ce\7684\590f\5929 Kikujiro 1999][\8c46\74e3\7535\5f71\8bc4\52068.9][\82f1\7248 DIY\56fd\914d\97f3\8f68\5bf9\5e94\7b80\7e41\7279\6548\4e2d\5b57][BHYS@OB-195221][tt0199683][40.44GB].iso', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:54.992061', 0),
(56, U&'/115\5206\4eab\7d22\5f15/\8c46\74e3\7535\5f71Top250_12.65TB/118.[\501f\4e1c\897f\7684\5c0f\4eba\963f\8389\57c3\8482 The Secret World of Arrietty 2010][\8c46\74e3\7535\5f71\8bc4\52068.9][\539f\76d8\56fd\7ca4\65e5\8bed\4e2d\5b57][CHD-34854][tt1568921][46.54GB].iso', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:55.039977', 0),
(57, U&'/115\5206\4eab\7d22\5f15/\8c46\74e3\7535\5f71Top250_12.65TB/119.[\6d88\5931\7684\7231\4eba Gone Girl 2014][\8c46\74e3\7535\5f71\8bc4\52068.9][\6b27\7248 DIY\7b80\7e41+\53cc\8bed\7279\6548\5b57\5e55][BHYS@OB-214824][tt2267998][40.25GB].iso', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:55.073344', 0);    
INSERT INTO "PUBLIC"."PLAY_URL" VALUES
(58, U&'/115\5206\4eab\7d22\5f15/\8c46\74e3\7535\5f71Top250_12.65TB/12.[\5fe0\72ac\516b\516c\7684\6545\4e8b Hachi: A Dog''s Tale 2009][\8c46\74e3\7535\5f71\8bc4\52069.4][DIY\9ad8\7801\97f3\8f68 \7b80\7e41+\53cc\8bed\7279\6548\5b57\5e55][bbba@HDS-303192][tt1028532][24.56GB].iso', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:55.104442', 0),
(59, U&'/115\5206\4eab\7d22\5f15/\8c46\74e3\7535\5f71Top250_12.65TB/120.[\65e0\4eba\77e5\6653 Nobody Knows 2004][\8c46\74e3\7535\5f71\8bc4\52069.1][\65e5\7248 DIY\7b80\7e41\5b57\5e55][Audies-CHD-342861][tt0408664][44.65GB].iso', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:55.165472', 0),
(60, U&'/115\5206\4eab\7d22\5f15/\8c46\74e3\7535\5f71Top250_12.65TB/121.[\672a\9ebb\7684\90e8\5c4b Perfect Blue 1997][\8c46\74e3\7535\5f71\8bc4\52069.1][\65e5\7248 SJ\6846\67b6 DIY\7b80\7e41\5b57\5e55][blucook#352@CHD-52329][tt0156887][45.72GB].iso', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:55.169315', 0),
(61, U&'/115\5206\4eab\7d22\5f15/\8c46\74e3\7535\5f71Top250_12.65TB/122.[\9633\5149\707f\70c2\7684\65e5\5b50 In the Heat of the Sun 1994][\8c46\74e3\7535\5f71\8bc4\52068.8][\6cd5\7248 4K\4fee\590d\7248\81ea\5e26\56fd\8bed DIY\56fd\8bed\7b80\7e41\5b57\5e55V2\7248][FFansDIY@\81f3\5c0a\5b9d-HDS-346241][tt0111786][45.98GB].iso', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:55.234007', 0),
(62, U&'/115\5206\4eab\7d22\5f15/\8c46\74e3\7535\5f71Top250_12.65TB/123.[\65f6\7a7a\604b\65c5\4eba About Time 2013][\8c46\74e3\7535\5f71\8bc4\52068.8][DIY\56fd\8bed \56fd\914d\7b80\4f53+\7b80\82f1\53cc\8bed\7279\6548\5b57\5e55][BHYS@OB-208876][tt2194499][44.99GB].iso', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:55.50002', 0),
(63, U&'/115\5206\4eab\7d22\5f15/\8c46\74e3\7535\5f71Top250_12.65TB/124.[\5b8c\7f8e\7684\4e16\754c A Perfect World 1993][\8c46\74e3\7535\5f71\8bc4\52068.8][DIY\7b80\7e41\5b57\5e55 \53cc\8bed\5b57\5e55][HFAYN@HDS-271601][tt0107808][35.37GB].iso', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:55.631769', 0),
(64, U&'/115\5206\4eab\7d22\5f15/\8c46\74e3\7535\5f71Top250_12.65TB/125.[\5029\5973\5e7d\9b42 A Chinese Ghost Story 1987][\8c46\74e3\7535\5f71\8bc4\52068.8][\534e\5f55\7248 DIY\65e5\7248\7ca4\8bed7.1 \56fd\914d\7b80\7e41\5b57\5e55][doraemon-TTG-442894][tt0093978][39.18GB].iso', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:55.738608', 0),
(65, U&'/115\5206\4eab\7d22\5f15/\8c46\74e3\7535\5f71Top250_12.65TB/126[\5929\4f7f\7231\7f8e\4e3d Amelie 2001][\8c46\74e3\7535\5f71\8bc4\52068.7][DIY\56fd\8bed \56fd\914d\7b80\4f53+\7b80\82f1\53cc\8bed\7279\6548\5b57\5e55][BHYS@OB-237608][tt0211915][44.95GB].iso', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:55.754169', 0),
(66, U&'/115\5206\4eab\7d22\5f15/\8c46\74e3\7535\5f71Top250_12.65TB/127.[\5c0f\68ee\6797 \590f\79cb\7bc7 Little Forest: Summer|Autumn 2014][\8c46\74e3\7535\5f71\8bc4\52069.0][\65e5\7248 DIY\7b80\7e41\7279\6548\5b57\5e55][BHYS@CHD-71941][tt3474600][36.64GB].iso', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:55.873123', 0),
(67, U&'/115\5206\4eab\7d22\5f15/\8c46\74e3\7535\5f71Top250_12.65TB/128.[\54c8\5229\00b7\6ce2\7279\4e0e\706b\7130\676f Harry Potter and the Goblet of Fire 2005][4K][\8c46\74e3\7535\5f71\8bc4\52068.8][\53f0\7248 \81ea\5e26\56fd\7ca4\53cc\8bed\7e41\4e2d DIY\516c\6620\56fd\914d \7b80\7e41\82f1\7279\6548\56db\5b57\5e55][sGnB@CHD-99762][tt0330373][63.72GB.iso', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:55.972742', 0),
(68, U&'/115\5206\4eab\7d22\5f15/\8c46\74e3\7535\5f71Top250_12.65TB/129.[\4fa7\8033\503e\542c Whisper of the Heart 1995][\8c46\74e3\7535\5f71\8bc4\52068.9][\81ea\5e26\56fd\7ca4\53cc\8bed DIY\7b80\7e41+\53cc\8bed\5b57\5e55][Audies-TTG-623719][tt0113824][46.71GB].iso', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:56.054843', 0),
(69, U&'/115\5206\4eab\7d22\5f15/\8c46\74e3\7535\5f71Top250_12.65TB/13.[\6d77\4e0a\94a2\7434\5e08 The Legend of 1900 1998][4K][\8c46\74e3\7535\5f71\8bc4\52069.3][\5fb7\7248 DIY\7b80\4f53+\7b80\4f53\53cc\8bed\7279\6548\5b57\5e55\4fdd\7559Dolby Vision][BHYS@OB-242898][tt0120731][60.12GB].iso', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:56.062139', 0),
(70, U&'/115\5206\4eab\7d22\5f15/\8c46\74e3\7535\5f71Top250_12.65TB/130.[\9a6f\9f99\9ad8\624b How to Train Your Dragon 2010][\8c46\74e3\7535\5f71\8bc4\52068.8][4K][\6e2f\7248 \539f\76d8\56fd\7ca4\4e2d\5b57][TTG-374473][tt0892769][41.07GB].iso', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:56.239865', 0);    
INSERT INTO "PUBLIC"."PLAY_URL" VALUES
(71, U&'/115\5206\4eab\7d22\5f15/\8c46\74e3\7535\5f71Top250_12.65TB/131.[\5e78\798f\7ec8\70b9\7ad9 The Terminal 2004][\8c46\74e3\7535\5f71\8bc4\52068.8][DIY\56fd\8bed \56fd\914d\7b80\7e41+\7b80\82f1\53cc\8bed\7279\6548\5b57\5e55][BHYS@OB-229163][tt0362227][40.93GB].iso', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:56.243943', 0),
(72, U&'/115\5206\4eab\7d22\5f15/\8c46\74e3\7535\5f71Top250_12.65TB/132.[\4e00\4e2a\53eb\6b27\7ef4\7684\7537\4eba\51b3\5b9a\53bb\6b7b A Man Called Ove 2015][\8c46\74e3\7535\5f71\8bc4\52068.9][\7f8e\7248 DIY\7b80\4f53+\7b80\82f1\53cc\8bed\5b57\5e55][BHYS@OB-208656][tt4080728][40.50GB].iso', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:56.393445', 0),
(73, U&'/115\5206\4eab\7d22\5f15/\8c46\74e3\7535\5f71Top250_12.65TB/133.[\6559\72363 The Godfather Part III 1990][\8c46\74e3\7535\5f71\8bc4\52069.0][4K][\6e2f\7248 DIY\4e09\56fd\8bed \56fd\914d\7b80\7e41+\53cc\8bed\7279\6548\5b57\5e55 \4fdd\7559Dolby Vision][sGnb@CHD-195422][tt0099674][91.63GB].iso', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:56.507536', 0),
(74, U&'/115\5206\4eab\7d22\5f15/\8c46\74e3\7535\5f71Top250_12.65TB/134.[\602a\517d\7535\529b\516c\53f8 Monsters Inc 2001][\8c46\74e3\7535\5f71\8bc4\52068.8][\53f0\7248 \56fd\7ca4\914d\97f3\6d17\7248\7ec8\6781\6536\85cf][TTG-224755][tt0198781][45.36GB].iso', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:56.576073', 0),
(75, U&'/115\5206\4eab\7d22\5f15/\8c46\74e3\7535\5f71Top250_12.65TB/135.[\65b0\4e16\754c New World 2013][\8c46\74e3\7535\5f71\8bc4\52068.9][\82f1\7248 DIY\7b80\7e41\5b57\5e55][XB663@PTH-101096][tt2625030][36.47GB].iso', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:56.598012', 0),
(76, U&'/115\5206\4eab\7d22\5f15/\8c46\74e3\7535\5f71Top250_12.65TB/136.[\8336\9986 The Teahouse 1982][\8c46\74e3\7535\5f71\8bc4\52069.6][\56fd\7248WCL\539f\76d8 \56fd\8bed \7b80\82f1\5b57\5e55][BHYS@OB-206118][tt1395030][44.57GB].iso', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:56.637022', 0),
(77, U&'/115\5206\4eab\7d22\5f15/\8c46\74e3\7535\5f71Top250_12.65TB/137.[\5c0f\68ee\6797 \51ac\6625\7bc7 Little Forest: Winter|Spring 2015][\8c46\74e3\7535\5f71\8bc4\52069.0][[DIY\7b80\7e41\7279\6548\5b57\5e55+\82b1\7d6e\7279\6548\4e2d\5b57][BHYS@CHD-72081][tt3474602][44.30GB].iso', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:56.650922', 0),
(78, U&'/115\5206\4eab\7d22\5f15/\8c46\74e3\7535\5f71Top250_12.65TB/138.[\73a9\5177\603b\52a8\54583 Toy Story 3 2010][\8c46\74e3\7535\5f71\8bc4\52068.9][4K][DIY\56fd\7ca4\8bed R3\5b98\8bd1\7b80\7e41\4e2d\5b57][DIY@TTG-382291][tt0435761][61.73GB].iso', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:56.665828', 0),
(79, U&'/115\5206\4eab\7d22\5f15/\8c46\74e3\7535\5f71Top250_12.65TB/139.[\50b2\6162\4e0e\504f\89c1 Pride & Prejudice 2005][\8c46\74e3\7535\5f71\8bc4\52068.7][DIY\56fd\8bed \56fd\914d\7b80\7e41+\53cc\8bed\7279\6548\5b57\5e55][BHYS@CHD-100708][tt0414387][41.24GB].iso', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:56.690866', 0),
(80, U&'/115\5206\4eab\7d22\5f15/\8c46\74e3\7535\5f71Top250_12.65TB/14.[\4e09\50bb\5927\95f9\5b9d\83b1\575e 3 Idiots 2009][\8c46\74e3\7535\5f71\8bc4\52069.2][DIY\6b21\56fd \7b80\7e41+\53cc\8bed\7279\6548\5b57\5e55][Stars@CHD-263634][tt1187043][45.54GB].iso', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:56.724918', 0),
(81, U&'/115\5206\4eab\7d22\5f15/\8c46\74e3\7535\5f71Top250_12.65TB/140.[\8424\706b\4e4b\68ee To the Forest of Firefly Lights 2011][\8c46\74e3\7535\5f71\8bc4\52068.9][DIY\56fd\7ca4\53cc\8bed \7b80\7e41\5b57\5e55][jiulinxiri-TTG-411810][tt2061702][22.01GB].iso', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:56.73422', 0),
(82, U&'/115\5206\4eab\7d22\5f15/\8c46\74e3\7535\5f71Top250_12.65TB/141.[\88ab\89e3\6551\7684\59dc\6208 Django Unchained 2012][\8c46\74e3\7535\5f71\8bc4\52068.8][DIY\6b21\56fd \7b80\7e41+\53cc\8bed\7279\6548\5b57\5e55 \91cd\5236\7248][CMCT-HDR-74683][tt1853728][46.27GB].iso', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:56.738394', 0),
(83, U&'/115\5206\4eab\7d22\5f15/\8c46\74e3\7535\5f71Top250_12.65TB/142.[\91dc\5c71\884c Train to Busan 2016][\8c46\74e3\7535\5f71\8bc4\52068.6][4K][\7f8e\7248 DIY\7b80\7e41\7279\6548\5b57\5e55 \4fdd\7559 Dolby Vision][BHYS@OB-203190][tt5700672][55.07GB].iso', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:56.754693', 0);       
INSERT INTO "PUBLIC"."PLAY_URL" VALUES
(84, U&'/115\5206\4eab\7d22\5f15/\8c46\74e3\7535\5f71Top250_12.65TB/~playlist', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:10:56.822802', 0),
(97, U&'/\+01f31e\6211\7684\5938\514b\7f51\76d8/\5938\514b\7f51\76d8/alist-tvbox-temp', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:42:21.435198', 0),
(98, U&'/\+01f31e\6211\7684\5938\514b\7f51\76d8/\5938\514b\7f51\76d8/\6781\5ba2\661f\7403', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:42:25.937643', 0),
(99, U&'/\+01f31e\6211\7684\5938\514b\7f51\76d8/\5938\514b\7f51\76d8/\5938\514b\7cbe\9009\58c1\7eb8', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:42:26.575008', 0),
(100, U&'/\+01f31e\6211\7684\5938\514b\7f51\76d8/\5938\514b\7f51\76d8/\6765\81ea\ff1a\5206\4eab', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:42:27.488544', 0),
(101, U&'/\+01f31e\6211\7684\5938\514b\7f51\76d8/\5938\514b\7f51\76d8/uz\5f71\89c6', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:42:27.764157', 0),
(102, U&'/\+01f31e\6211\7684\5938\514b\7f51\76d8/\5938\514b\7f51\76d8/\5938\514b\7f51\76d8\529f\80fd\4ecb\7ecd.mp4', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:42:28.001186', 0),
(103, U&'/\+01f31e\6211\7684\5938\514b\7f51\76d8/\5938\514b\7f51\76d8/\5938\514b\7f51\76d8\529f\80fd\4ecb\7ecd.png', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:42:28.012589', 0),
(104, U&'/\+01f31e\6211\7684UC\7f51\76d8/UC\7f51\76d8/0000temp', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:42:39.321743', 0),
(105, U&'/\+01f31e\6211\7684UC\7f51\76d8/UC\7f51\76d8/alist-tvbox-temp', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:42:39.55977', 0),
(106, U&'/\+01f31e\6211\7684UC\7f51\76d8/UC\7f51\76d8/drpy', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:42:39.70054', 0),
(107, U&'/\+01f31e\6211\7684UC\7f51\76d8/UC\7f51\76d8/\6765\81ea\ff1a\5206\4eab', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:42:39.825842', 0),
(108, U&'/\+01f31e\6211\7684UC\7f51\76d8/UC\7f51\76d8/\6211\7684\5907\4efd', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:42:39.944046', 0),
(109, U&'/\+01f31e\6211\7684UC\7f51\76d8/UC\7f51\76d8/\6211\7684\89c6\9891', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:42:40.016726', 0),
(110, U&'/\+01f31e\6211\7684UC\7f51\76d8/UC\7f51\76d8/\4e91\6536\85cf\6587\4ef6', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:42:40.10584', 0),
(111, U&'/\+01f31e\6211\7684UC\7f51\76d8/UC\7f51\76d8/01.mkv', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:42:40.196455', 0),
(112, U&'/\6211\7684123\7f51\76d8', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:42:43.227511', 0),
(113, U&'/\6211\7684UC\7f51\76d8', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:42:43.51597', 0),
(114, U&'/\6211\7684\5929\7ffc\4e91\76d8', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:42:43.657517', 0),
(115, U&'/\6211\7684\5938\514b\7f51\76d8', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:42:43.758248', 0),
(116, U&'/\6211\7684\767e\5ea6\7f51\76d8', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:42:44.021504', 0),
(117, U&'/\6211\7684\79fb\52a8\4e91\76d8', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:42:44.087166', 0),
(118, U&'/\6211\7684\8fc5\96f7\4e91\76d8', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:42:44.137894', 0),
(119, U&'/\+01f31e\6211\7684UC\7f51\76d8', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:42:44.255341', 0),
(120, U&'/\+01f31e\6211\7684\5938\514b\7f51\76d8', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:42:44.291778', 0),
(121, U&'/\+01f4c0\6211\7684\963f\91cc\4e91\76d8', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:42:44.294494', 0),
(122, U&'/\6211\7684\767e\5ea6\5206\4eab/temp/baidu@1k12VpyArYB3O9yzQc83NZg@jdcv/S \55dc\8840\6cd5\533b\ff1a\6740\9b54\590d\751f \7b2c\4e00\5b63\ff082025\7f8e\5267\ff09Dexter\ff1aResurrection/~playlist', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:53:10.13305', 0),
(123, U&'/\6211\7684\767e\5ea6\5206\4eab/temp/baidu@1k12VpyArYB3O9yzQc83NZg@jdcv/S \55dc\8840\6cd5\533b\ff1a\6740\9b54\590d\751f \7b2c\4e00\5b63\ff082025\7f8e\5267\ff09Dexter\ff1aResurrection/\55dc\8840\6cd5\533b\ff1a\6740\9b54\590d\751f.S01E01.WY.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-26 17:53:10.693378', 0),
(124, U&'/\6211\7684\767e\5ea6\5206\4eab/temp/baidu@1k12VpyArYB3O9yzQc83NZg@jdcv/S \55dc\8840\6cd5\533b\ff1a\6740\9b54\590d\751f \7b2c\4e00\5b63\ff082025\7f8e\5267\ff09Dexter\ff1aResurrection/\55dc\8840\6cd5\533b\ff1a\6740\9b54\590d\751f.S01E02.WY.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-26 17:53:10.700081', 0);         
INSERT INTO "PUBLIC"."PLAY_URL" VALUES
(125, U&'/\6211\7684\767e\5ea6\5206\4eab/temp/baidu@1k12VpyArYB3O9yzQc83NZg@jdcv/S \55dc\8840\6cd5\533b\ff1a\6740\9b54\590d\751f \7b2c\4e00\5b63\ff082025\7f8e\5267\ff09Dexter\ff1aResurrection/\55dc\8840\6cd5\533b\ff1a\6740\9b54\590d\751f.S01E03.WY.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-26 17:53:10.702356', 0),
(126, U&'/\6211\7684\767e\5ea6\5206\4eab/temp/baidu@1k12VpyArYB3O9yzQc83NZg@jdcv/S \55dc\8840\6cd5\533b\ff1a\6740\9b54\590d\751f \7b2c\4e00\5b63\ff082025\7f8e\5267\ff09Dexter\ff1aResurrection/\55dc\8840\6cd5\533b\ff1a\6740\9b54\590d\751f.S01E04.WY.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-26 17:53:10.705475', 0),
(127, U&'/\6211\7684\767e\5ea6\5206\4eab/temp/baidu@1k12VpyArYB3O9yzQc83NZg@jdcv/S \55dc\8840\6cd5\533b\ff1a\6740\9b54\590d\751f \7b2c\4e00\5b63\ff082025\7f8e\5267\ff09Dexter\ff1aResurrection/\55dc\8840\6cd5\533b\ff1a\6740\9b54\590d\751f.S01E05.WY.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-26 17:53:10.709185', 0),
(128, U&'/\6211\7684\767e\5ea6\5206\4eab/temp/baidu@1k12VpyArYB3O9yzQc83NZg@jdcv/S \55dc\8840\6cd5\533b\ff1a\6740\9b54\590d\751f \7b2c\4e00\5b63\ff082025\7f8e\5267\ff09Dexter\ff1aResurrection/\55dc\8840\6cd5\533b\ff1a\6740\9b54\590d\751f.S01E06.WY.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-26 17:53:10.711586', 0),
(129, U&'/\6211\7684\767e\5ea6\5206\4eab/temp/baidu@1k12VpyArYB3O9yzQc83NZg@jdcv/S \55dc\8840\6cd5\533b\ff1a\6740\9b54\590d\751f \7b2c\4e00\5b63\ff082025\7f8e\5267\ff09Dexter\ff1aResurrection/\55dc\8840\6cd5\533b\ff1a\6740\9b54\590d\751f.S01E07.WY.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-26 17:53:10.715661', 0),
(130, U&'/\6211\7684\767e\5ea6\5206\4eab/temp/baidu@1k12VpyArYB3O9yzQc83NZg@jdcv/S \55dc\8840\6cd5\533b\ff1a\6740\9b54\590d\751f \7b2c\4e00\5b63\ff082025\7f8e\5267\ff09Dexter\ff1aResurrection/\55dc\8840\6cd5\533b\ff1a\6740\9b54\590d\751f.S01E08.WY.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-26 17:53:10.718448', 0),
(131, U&'/\6211\7684\767e\5ea6\5206\4eab/temp/baidu@1k12VpyArYB3O9yzQc83NZg@jdcv/S \55dc\8840\6cd5\533b\ff1a\6740\9b54\590d\751f \7b2c\4e00\5b63\ff082025\7f8e\5267\ff09Dexter\ff1aResurrection/\55dc\8840\6cd5\533b\ff1a\6740\9b54\590d\751f.S01E09.WY.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-26 17:53:10.721431', 0),
(132, U&'/\6211\7684\767e\5ea6\5206\4eab/temp/baidu@1k12VpyArYB3O9yzQc83NZg@jdcv/S \55dc\8840\6cd5\533b\ff1a\6740\9b54\590d\751f \7b2c\4e00\5b63\ff082025\7f8e\5267\ff09Dexter\ff1aResurrection/\55dc\8840\6cd5\533b\ff1a\6740\9b54\590d\751f.S01E10.WY.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-26 17:53:10.72514', 0),
(133, U&'/\6211\7684123\5206\4eab/temp/123@IpPUVv-pTDj@JZMM/~playlist', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:53:16.376805', 0),
(134, U&'/\6211\7684\5929\7ffc\5206\4eab/temp/189@2EZ3aqBZfEjy@/~playlist', NULL, NULL, 1, TIMESTAMP '2026-10-19 17:53:23.229258', 0),
(135, U&'/\6211\7684\5929\7ffc\5206\4eab/temp/189@2EZ3aqBZfEjy@/Dexter.New.Blood.S01E01.Cold.Snap.1080p.BluRay.REMUX.AVC.TrueHD.5.1-\8001K.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-26 17:53:23.271134', 0),
(136, U&'/\6211\7684\5929\7ffc\5206\4eab/temp/189@2EZ3aqBZfEjy@/Dexter.New.Blood.S01E02.Storm.of.Fuck.1080p.BluRay.REMUX.AVC.TrueHD.5.1-\8001K.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-26 17:53:23.274371', 0),
(137, U&'/\6211\7684\5929\7ffc\5206\4eab/temp/189@2EZ3aqBZfEjy@/Dexter.New.Blood.S01E03.Smoke.Signals.1080p.BluRay.REMUX.AVC.TrueHD.5.1-\8001K.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-26 17:53:23.276757', 0),
(138, U&'/\6211\7684\5929\7ffc\5206\4eab/temp/189@2EZ3aqBZfEjy@/Dexter.New.Blood.S01E04.H.is.for.Hero.1080p.BluRay.REMUX.AVC.TrueHD.5.1-\8001K.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-26 17:53:23.283289', 0),
(139, U&'/\6211\7684\5929\7ffc\5206\4eab/temp/189@2EZ3aqBZfEjy@/Dexter.New.Blood.S01E05.Runaway.1080p.BluRay.REMUX.AVC.TrueHD.5.1-\8001K.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-26 17:53:23.285663', 0),
(140, U&'/\6211\7684\5929\7ffc\5206\4eab/temp/189@2EZ3aqBZfEjy@/Dexter.New.Blood.S01E06.Too.Many.Tuna.Sandwiches.1080p.BluRay.REMUX.AVC.TrueHD.5.1-\8001K.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-26 17:53:23.292039', 0),
(141, U&'/\6211\7684\5929\7ffc\5206\4eab/temp/189@2EZ3aqBZfEjy@/Dexter.New.Blood.S01E07.Skin.of.Her.Teeth.1080p.BluRay.REMUX.AVC.TrueHD.5.1-\8001K.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-26 17:53:23.295472', 0);   
INSERT INTO "PUBLIC"."PLAY_URL" VALUES
(142, U&'/\6211\7684\5929\7ffc\5206\4eab/temp/189@2EZ3aqBZfEjy@/Dexter.New.Blood.S01E08.Unfair.Game.1080p.BluRay.REMUX.AVC.TrueHD.5.1-\8001K.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-26 17:53:23.298461', 0),
(143, U&'/\6211\7684\5929\7ffc\5206\4eab/temp/189@2EZ3aqBZfEjy@/Dexter.New.Blood.S01E09.The.Family.Business.1080p.BluRay.REMUX.AVC.TrueHD.5.1-\8001K.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-26 17:53:23.304517', 0),
(144, U&'/\6211\7684\5929\7ffc\5206\4eab/temp/189@2EZ3aqBZfEjy@/Dexter.New.Blood.S01E10.Sins.of.the.Father.1080p.BluRay.REMUX.AVC.TrueHD.5.1-\8001K.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-26 17:53:23.306804', 0),
(145, U&'/\6211\7684123\5206\4eab', NULL, NULL, 1, TIMESTAMP '2026-10-19 18:49:21.00152', 0),
(146, U&'/\6211\7684\5929\7ffc\5206\4eab', NULL, NULL, 1, TIMESTAMP '2026-10-19 18:49:21.017899', 0),
(147, U&'/\6211\7684\767e\5ea6\5206\4eab', NULL, NULL, 1, TIMESTAMP '2026-10-19 18:49:21.028277', 0),
(149, 'https://al.flv.huya.com/huyalive/9999991199561506980-1199561506980-5435845454610825216-2399123137416-10057-A-0-11789837153.flv?ratio=&cdn=AL&name=9999991199561506980-1199561506980-5435845454610825216-2399123137416-10057-A-0-11789837153&uid=1199561506980', NULL, NULL, 0, TIMESTAMP '2026-09-21 16:31:37.824805', 0),
(150, 'https://tx.flv.huya.com/src/9999991199561506980-1199561506980-5435845454610825216-2399123137416-10057-A-0-11789837153.flv?ratio=&cdn=TX&name=9999991199561506980-1199561506980-5435845454610825216-2399123137416-10057-A-0-11789837153&uid=1199561506980', NULL, NULL, 0, TIMESTAMP '2026-09-21 16:31:37.840361', 0),
(151, 'https://hs.flv.huya.com/src/9999991199561506980-1199561506980-5435845454610825216-2399123137416-10057-A-0-11789837153.flv?ratio=&cdn=HS&name=9999991199561506980-1199561506980-5435845454610825216-2399123137416-10057-A-0-11789837153&uid=1199561506980', NULL, NULL, 0, TIMESTAMP '2026-09-21 16:31:37.843394', 0),
(152, 'https://al.flv.huya.com/huyalive/999999631787729-631787729-2713507634069110784-1263698914-10057-A-0-11789728500.flv?ratio=&cdn=AL&name=999999631787729-631787729-2713507634069110784-1263698914-10057-A-0-11789728500&uid=631787729', NULL, NULL, 0, TIMESTAMP '2026-09-21 16:31:51.481583', 0),
(153, 'https://tx.flv.huya.com/src/999999631787729-631787729-2713507634069110784-1263698914-10057-A-0-11789728500.flv?ratio=&cdn=TX&name=999999631787729-631787729-2713507634069110784-1263698914-10057-A-0-11789728500&uid=631787729', NULL, NULL, 0, TIMESTAMP '2026-09-21 16:31:51.484303', 0),
(154, 'https://hs.flv.huya.com/src/999999631787729-631787729-2713507634069110784-1263698914-10057-A-0-11789728500.flv?ratio=&cdn=HS&name=999999631787729-631787729-2713507634069110784-1263698914-10057-A-0-11789728500&uid=631787729', NULL, NULL, 0, TIMESTAMP '2026-09-21 16:31:51.487284', 0),
(155, 'https://aldirect.flv.huya.com/huyalive/1259523217070-1259523217070-4715012271460319232-2519046557596-10057-A-0-1.flv?ratio=&cdn=AL&name=1259523217070-1259523217070-4715012271460319232-2519046557596-10057-A-0-1&uid=1259523217070', NULL, NULL, 0, TIMESTAMP '2026-09-21 16:31:54.132186', 0),
(156, 'https://aldirect.flv.huya.com/huyalive/1259523217070-1259523217070-4715012271460319232-2519046557596-10057-A-0-1.flv?ratio=4000&cdn=AL&name=1259523217070-1259523217070-4715012271460319232-2519046557596-10057-A-0-1&uid=1259523217070', NULL, NULL, 0, TIMESTAMP '2026-09-21 16:31:54.135139', 0),
(157, 'https://aldirect.flv.huya.com/huyalive/1259523217070-1259523217070-4715012271460319232-2519046557596-10057-A-0-1.flv?ratio=2000&cdn=AL&name=1259523217070-1259523217070-4715012271460319232-2519046557596-10057-A-0-1&uid=1259523217070', NULL, NULL, 0, TIMESTAMP '2026-09-21 16:31:54.137726', 0),
(158, 'https://aldirect.flv.huya.com/huyalive/1259523217070-1259523217070-4715012271460319232-2519046557596-10057-A-0-1.flv?ratio=500&cdn=AL&name=1259523217070-1259523217070-4715012271460319232-2519046557596-10057-A-0-1&uid=1259523217070', NULL, NULL, 0, TIMESTAMP '2026-09-21 16:31:54.151219', 0),
(159, 'https://tx.flv.huya.com/src/1259523217070-1259523217070-4715012271460319232-2519046557596-10057-A-0-1.flv?ratio=&cdn=TX&name=1259523217070-1259523217070-4715012271460319232-2519046557596-10057-A-0-1&uid=1259523217070', NULL, NULL, 0, TIMESTAMP '2026-09-21 16:31:54.154062', 0);    
INSERT INTO "PUBLIC"."PLAY_URL" VALUES
(160, 'https://tx.flv.huya.com/src/1259523217070-1259523217070-4715012271460319232-2519046557596-10057-A-0-1.flv?ratio=4000&cdn=TX&name=1259523217070-1259523217070-4715012271460319232-2519046557596-10057-A-0-1&uid=1259523217070', NULL, NULL, 0, TIMESTAMP '2026-09-21 16:31:54.156751', 0),
(161, 'https://tx.flv.huya.com/src/1259523217070-1259523217070-4715012271460319232-2519046557596-10057-A-0-1.flv?ratio=2000&cdn=TX&name=1259523217070-1259523217070-4715012271460319232-2519046557596-10057-A-0-1&uid=1259523217070', NULL, NULL, 0, TIMESTAMP '2026-09-21 16:31:54.168798', 0),
(162, 'https://tx.flv.huya.com/src/1259523217070-1259523217070-4715012271460319232-2519046557596-10057-A-0-1.flv?ratio=500&cdn=TX&name=1259523217070-1259523217070-4715012271460319232-2519046557596-10057-A-0-1&uid=1259523217070', NULL, NULL, 0, TIMESTAMP '2026-09-21 16:31:54.173999', 0),
(163, 'https://hs.flv.huya.com/src/1259523217070-1259523217070-4715012271460319232-2519046557596-10057-A-0-1.flv?ratio=&cdn=HS&name=1259523217070-1259523217070-4715012271460319232-2519046557596-10057-A-0-1&uid=1259523217070', NULL, NULL, 0, TIMESTAMP '2026-09-21 16:31:54.180402', 0),
(164, 'https://hs.flv.huya.com/src/1259523217070-1259523217070-4715012271460319232-2519046557596-10057-A-0-1.flv?ratio=4000&cdn=HS&name=1259523217070-1259523217070-4715012271460319232-2519046557596-10057-A-0-1&uid=1259523217070', NULL, NULL, 0, TIMESTAMP '2026-09-21 16:31:54.192319', 0),
(165, 'https://hs.flv.huya.com/src/1259523217070-1259523217070-4715012271460319232-2519046557596-10057-A-0-1.flv?ratio=2000&cdn=HS&name=1259523217070-1259523217070-4715012271460319232-2519046557596-10057-A-0-1&uid=1259523217070', NULL, NULL, 0, TIMESTAMP '2026-09-21 16:31:54.20047', 0),
(166, 'https://hs.flv.huya.com/src/1259523217070-1259523217070-4715012271460319232-2519046557596-10057-A-0-1.flv?ratio=500&cdn=HS&name=1259523217070-1259523217070-4715012271460319232-2519046557596-10057-A-0-1&uid=1259523217070', NULL, NULL, 0, TIMESTAMP '2026-09-21 16:31:54.203069', 0),
(167, U&'/\6211\7684\767e\5ea6\5206\4eab/temp/baidu@1EEgGdvL5yt7rlODuFFtirA@932q/\91cdz\6848z\516dz\7ec4\ff1a\6d88z\5931z\7684z\8b66z\53f7 (2026) 4K 60\5e27/~playlist', NULL, NULL, 1, TIMESTAMP '2026-10-20 16:32:46.662839', 0),
(168, U&'/\6211\7684\767e\5ea6\5206\4eab/temp/baidu@1EEgGdvL5yt7rlODuFFtirA@932q/\91cdz\6848z\516dz\7ec4\ff1a\6d88z\5931z\7684z\8b66z\53f7 (2026) 4K 60\5e27/S01E01.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:32:48.884688', 0),
(169, U&'/\6211\7684\767e\5ea6\5206\4eab/temp/baidu@1EEgGdvL5yt7rlODuFFtirA@932q/\91cdz\6848z\516dz\7ec4\ff1a\6d88z\5931z\7684z\8b66z\53f7 (2026) 4K 60\5e27/S01E02.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:32:48.902124', 0),
(170, U&'/\6211\7684\767e\5ea6\5206\4eab/temp/baidu@1EEgGdvL5yt7rlODuFFtirA@932q/\91cdz\6848z\516dz\7ec4\ff1a\6d88z\5931z\7684z\8b66z\53f7 (2026) 4K 60\5e27/S01E03.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:32:48.911939', 0),
(171, U&'/\6211\7684\767e\5ea6\5206\4eab/temp/baidu@1EEgGdvL5yt7rlODuFFtirA@932q/\91cdz\6848z\516dz\7ec4\ff1a\6d88z\5931z\7684z\8b66z\53f7 (2026) 4K 60\5e27/S01E04.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:32:48.926116', 0),
(172, U&'/\6211\7684\767e\5ea6\5206\4eab/temp/baidu@1EEgGdvL5yt7rlODuFFtirA@932q/\91cdz\6848z\516dz\7ec4\ff1a\6d88z\5931z\7684z\8b66z\53f7 (2026) 4K 60\5e27/S01E05.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:32:48.931435', 0),
(173, U&'/\6211\7684\767e\5ea6\5206\4eab/temp/baidu@1EEgGdvL5yt7rlODuFFtirA@932q/\91cdz\6848z\516dz\7ec4\ff1a\6d88z\5931z\7684z\8b66z\53f7 (2026) 4K 60\5e27/S01E06.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:32:48.934353', 0),
(174, U&'/\6211\7684\767e\5ea6\5206\4eab/temp/baidu@1EEgGdvL5yt7rlODuFFtirA@932q/\91cdz\6848z\516dz\7ec4\ff1a\6d88z\5931z\7684z\8b66z\53f7 (2026) 4K 60\5e27/S01E07.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:32:48.936813', 0),
(175, U&'/\6211\7684\767e\5ea6\5206\4eab/temp/baidu@1EEgGdvL5yt7rlODuFFtirA@932q/\91cdz\6848z\516dz\7ec4\ff1a\6d88z\5931z\7684z\8b66z\53f7 (2026) 4K 60\5e27/S01E08.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:32:48.949531', 0);             
INSERT INTO "PUBLIC"."PLAY_URL" VALUES
(176, U&'/\6211\7684\767e\5ea6\5206\4eab/temp/baidu@1EEgGdvL5yt7rlODuFFtirA@932q/\91cdz\6848z\516dz\7ec4\ff1a\6d88z\5931z\7684z\8b66z\53f7 (2026) 4K 60\5e27/S01E09.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:32:48.952966', 0),
(177, U&'/\6211\7684\767e\5ea6\5206\4eab/temp/baidu@1EEgGdvL5yt7rlODuFFtirA@932q/\91cdz\6848z\516dz\7ec4\ff1a\6d88z\5931z\7684z\8b66z\53f7 (2026) 4K 60\5e27/S01E10.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:32:48.955888', 0),
(178, U&'/\6211\7684\767e\5ea6\5206\4eab/temp/baidu@1EEgGdvL5yt7rlODuFFtirA@932q/\91cdz\6848z\516dz\7ec4\ff1a\6d88z\5931z\7684z\8b66z\53f7 (2026) 4K 60\5e27/S01E11.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:32:48.958353', 0),
(179, U&'/\6211\7684\767e\5ea6\5206\4eab/temp/baidu@1EEgGdvL5yt7rlODuFFtirA@932q/\91cdz\6848z\516dz\7ec4\ff1a\6d88z\5931z\7684z\8b66z\53f7 (2026) 4K 60\5e27/S01E12.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:32:48.974334', 0),
(180, U&'/\6211\7684\767e\5ea6\5206\4eab/temp/baidu@1EEgGdvL5yt7rlODuFFtirA@932q/\91cdz\6848z\516dz\7ec4\ff1a\6d88z\5931z\7684z\8b66z\53f7 (2026) 4K 60\5e27/S01E13.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:32:48.977786', 0),
(181, U&'/\6211\7684\767e\5ea6\5206\4eab/temp/baidu@1EEgGdvL5yt7rlODuFFtirA@932q/\91cdz\6848z\516dz\7ec4\ff1a\6d88z\5931z\7684z\8b66z\53f7 (2026) 4K 60\5e27/S01E14.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:32:48.992963', 0),
(182, U&'/\6211\7684\767e\5ea6\5206\4eab/temp/baidu@1EEgGdvL5yt7rlODuFFtirA@932q/\91cdz\6848z\516dz\7ec4\ff1a\6d88z\5931z\7684z\8b66z\53f7 (2026) 4K 60\5e27/S01E15.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:32:48.999741', 0),
(183, U&'/\6211\7684\767e\5ea6\5206\4eab/temp/baidu@1EEgGdvL5yt7rlODuFFtirA@932q/\91cdz\6848z\516dz\7ec4\ff1a\6d88z\5931z\7684z\8b66z\53f7 (2026) 4K 60\5e27/S01E16.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:32:49.003021', 0),
(184, U&'/\6211\7684\767e\5ea6\5206\4eab/temp/baidu@1EEgGdvL5yt7rlODuFFtirA@932q/\91cdz\6848z\516dz\7ec4\ff1a\6d88z\5931z\7684z\8b66z\53f7 (2026) 4K 60\5e27/S01E17.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:32:49.011826', 0),
(185, U&'/\6211\7684\767e\5ea6\5206\4eab/temp/baidu@1EEgGdvL5yt7rlODuFFtirA@932q/\91cdz\6848z\516dz\7ec4\ff1a\6d88z\5931z\7684z\8b66z\53f7 (2026) 4K 60\5e27/S01E18.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:32:49.029592', 0),
(186, U&'/\6211\7684\767e\5ea6\5206\4eab/temp/baidu@1EEgGdvL5yt7rlODuFFtirA@932q/\91cdz\6848z\516dz\7ec4\ff1a\6d88z\5931z\7684z\8b66z\53f7 (2026) 4K 60\5e27/S01E19.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:32:49.032682', 0),
(187, U&'/\6211\7684\767e\5ea6\5206\4eab/temp/baidu@1EEgGdvL5yt7rlODuFFtirA@932q/\91cdz\6848z\516dz\7ec4\ff1a\6d88z\5931z\7684z\8b66z\53f7 (2026) 4K 60\5e27/S01E20.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:32:49.03529', 0),
(188, U&'/\6211\7684\767e\5ea6\5206\4eab/temp/baidu@1EEgGdvL5yt7rlODuFFtirA@932q/\91cdz\6848z\516dz\7ec4\ff1a\6d88z\5931z\7684z\8b66z\53f7 (2026) 4K 60\5e27/S01E21.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:32:49.037713', 0),
(189, U&'/\6211\7684\767e\5ea6\5206\4eab/temp/baidu@1EEgGdvL5yt7rlODuFFtirA@932q/\91cdz\6848z\516dz\7ec4\ff1a\6d88z\5931z\7684z\8b66z\53f7 (2026) 4K 60\5e27/S01E22.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:32:49.058664', 0),
(190, U&'/\6211\7684\767e\5ea6\5206\4eab/temp/baidu@1EEgGdvL5yt7rlODuFFtirA@932q/\91cdz\6848z\516dz\7ec4\ff1a\6d88z\5931z\7684z\8b66z\53f7 (2026) 4K 60\5e27/S01E23.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:32:49.06149', 0),
(191, U&'/\6211\7684\767e\5ea6\5206\4eab/temp/baidu@1EEgGdvL5yt7rlODuFFtirA@932q/\91cdz\6848z\516dz\7ec4\ff1a\6d88z\5931z\7684z\8b66z\53f7 (2026) 4K 60\5e27/S01E24.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:32:49.063926', 0),
(192, U&'/\6211\7684\767e\5ea6\5206\4eab/temp/baidu@1EEgGdvL5yt7rlODuFFtirA@932q/\91cdz\6848z\516dz\7ec4\ff1a\6d88z\5931z\7684z\8b66z\53f7 (2026) 4K 60\5e27/S01E25.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:32:49.066379', 0),
(193, U&'/\6211\7684\767e\5ea6\5206\4eab/temp/baidu@1EEgGdvL5yt7rlODuFFtirA@932q/\91cdz\6848z\516dz\7ec4\ff1a\6d88z\5931z\7684z\8b66z\53f7 (2026) 4K 60\5e27/S01E26.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:32:49.07782', 0);  
INSERT INTO "PUBLIC"."PLAY_URL" VALUES
(194, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/~playlist', NULL, NULL, 1, TIMESTAMP '2026-10-20 16:33:36.830933', 0),
(195, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E01.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:37.929254', 0),
(196, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E02.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:37.931934', 0),
(197, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E03.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:37.941506', 0),
(198, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E04.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:37.955567', 0),
(199, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E05.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:37.958301', 0),
(200, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E06.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:37.961002', 0),
(201, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E07.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:37.965772', 0),
(202, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E08.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:37.974662', 0),
(203, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E09.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:37.977191', 0),
(204, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E10.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:37.979569', 0),
(205, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E11.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.00381', 0),
(206, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E12.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.007415', 0),
(207, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E13.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.010147', 0),
(208, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E14.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.022691', 0),
(209, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E15.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.026515', 0),
(210, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E16.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.030046', 0),
(211, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E18.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.036915', 0),
(212, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E19.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.043333', 0),
(213, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E20.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.045899', 0),
(214, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E21.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.054109', 0);  
INSERT INTO "PUBLIC"."PLAY_URL" VALUES
(215, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E22.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.063095', 0),
(216, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E23.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.067104', 0),
(217, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E24.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.076003', 0),
(218, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E25.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.078553', 0),
(219, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E26.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.091684', 0),
(220, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E27.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.094641', 0),
(221, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E28.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.104389', 0),
(222, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E29.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.107016', 0),
(223, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E30.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.109473', 0),
(224, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E31.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.112483', 0),
(225, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E32.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.126263', 0),
(226, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E33.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.139532', 0),
(227, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E34.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.142461', 0),
(228, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E35.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.148317', 0),
(229, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E36.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.150793', 0),
(230, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E37.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.163529', 0),
(231, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E38.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.166145', 0),
(232, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E39.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.168575', 0),
(233, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E40.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.170904', 0),
(234, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E41.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.181448', 0),
(235, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E42.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.184986', 0);       
INSERT INTO "PUBLIC"."PLAY_URL" VALUES
(236, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E43.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.187744', 0),
(237, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E44.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.197696', 0),
(238, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E45.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.203968', 0),
(239, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E46.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.206495', 0),
(240, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E47.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.215875', 0),
(241, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E48.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.218366', 0),
(242, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E49.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.233955', 0),
(243, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E50.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.238746', 0),
(244, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E51.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.241424', 0),
(245, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E52.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.255161', 0),
(246, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E53.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.257911', 0),
(247, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E56.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.260942', 0),
(248, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E59.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.265519', 0),
(249, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E60.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.273966', 0),
(250, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E61.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.276669', 0),
(251, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E62.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.279006', 0),
(252, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E63.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.281456', 0),
(253, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E64.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.294373', 0),
(254, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E65.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.297566', 0),
(255, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E66.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.306162', 0),
(256, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E67.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.308712', 0);       
INSERT INTO "PUBLIC"."PLAY_URL" VALUES
(257, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E68.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.324555', 0),
(258, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E69.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.328864', 0),
(259, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E70.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.331392', 0),
(260, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E71.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.338631', 0),
(261, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E72.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.341536', 0),
(262, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E73.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.345506', 0),
(263, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E74.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.348109', 0),
(264, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E75.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.353987', 0),
(265, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E76.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.356601', 0),
(266, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E77.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.359018', 0),
(267, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E78.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.365497', 0),
(268, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E79.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.368128', 0),
(269, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E80.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.370704', 0),
(270, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E81.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.373188', 0),
(271, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E82.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.376737', 0),
(272, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E83.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.382915', 0),
(273, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E84.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.387599', 0),
(274, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E85.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.39128', 0),
(275, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E86.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.394521', 0),
(276, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E87.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.397902', 0),
(277, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E90.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.401216', 0);        
INSERT INTO "PUBLIC"."PLAY_URL" VALUES
(278, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E91.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.415661', 0),
(279, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E92.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.418443', 0),
(280, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E93.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.424899', 0),
(281, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E94.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.434784', 0),
(282, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E95.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.437232', 0),
(283, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E96.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.43959', 0),
(284, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E97.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.454825', 0),
(285, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E98.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.457451', 0),
(286, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E99.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.460417', 0),
(287, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E100.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.466942', 0),
(288, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@1063180c04f2@/MUSHEN/Tales.of.Herding.Gods.S01E101.2024.2160p.WEB-DL.H264.AAC-HiveWeb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:33:38.474459', 0),
(289, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/~playlist', NULL, NULL, 1, TIMESTAMP '2026-10-20 16:34:07.739382', 0),
(290, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/1.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.365502', 0),
(291, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/2.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.368314', 0),
(292, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/3.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.371231', 0),
(293, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/4.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.394157', 0),
(294, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/5.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.398013', 0),
(295, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/6.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.40087', 0),
(296, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/7.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.412299', 0),
(297, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/8.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.425629', 0),
(298, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/9.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.428263', 0),
(299, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/10.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.430991', 0),
(300, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/11.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.444715', 0);     
INSERT INTO "PUBLIC"."PLAY_URL" VALUES
(301, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/12.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.451285', 0),
(302, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/13.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.464951', 0),
(303, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/14.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.467946', 0),
(304, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/15.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.470681', 0),
(305, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/16.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.484265', 0),
(306, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/17.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.487275', 0),
(307, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/18.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.49016', 0),
(308, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/19.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.498781', 0),
(309, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/20.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.509044', 0),
(310, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/21.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.516496', 0),
(311, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/22.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.519267', 0),
(312, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/23.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.522062', 0),
(313, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/24.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.535627', 0),
(314, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/25.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.538565', 0),
(315, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/26.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.558884', 0),
(316, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/27.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.567663', 0),
(317, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/28.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.578651', 0),
(318, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/29.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.590566', 0),
(319, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/30.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.599283', 0),
(320, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/31.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.602462', 0),
(321, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/32.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.61571', 0),
(322, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/33.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.61863', 0),
(323, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/34.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.6214', 0),
(324, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/35.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.631372', 0),
(325, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/36.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.645131', 0); 
INSERT INTO "PUBLIC"."PLAY_URL" VALUES
(326, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/37.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.648046', 0),
(327, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/38.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.669899', 0),
(328, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/39.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.686297', 0),
(329, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/40.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.689545', 0),
(330, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/41.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.737204', 0),
(331, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/42.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.753617', 0),
(332, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/43.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.779634', 0),
(333, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/44.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.782255', 0),
(334, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/45.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.833226', 0),
(335, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/46.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.844815', 0),
(336, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/47.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.847613', 0),
(337, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/48.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.85409', 0),
(338, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/49.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.857243', 0),
(339, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/50.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.872295', 0),
(340, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/51.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.877814', 0),
(341, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/52.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.883984', 0),
(342, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/53.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.895702', 0),
(343, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/54.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.899125', 0),
(344, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/55.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.913361', 0),
(345, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/56.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.920262', 0),
(346, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/57.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.984273', 0),
(347, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/58.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:08.991283', 0),
(348, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/59.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.030887', 0),
(349, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/60.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.09681', 0),
(350, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/61.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.119846', 0);              
INSERT INTO "PUBLIC"."PLAY_URL" VALUES
(351, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/62.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.151882', 0),
(352, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/63.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.16023', 0),
(353, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/64.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.174508', 0),
(354, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/65.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.194207', 0),
(355, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/66.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.225649', 0),
(356, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/67.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.229059', 0),
(357, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/68.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.24416', 0),
(358, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/69.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.247036', 0),
(359, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/70.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.24983', 0),
(360, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/71.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.252473', 0),
(361, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/72.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.270683', 0),
(362, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/73.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.280008', 0),
(363, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/74.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.294683', 0),
(364, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/75.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.297503', 0),
(365, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/76.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.300254', 0),
(366, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/77.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.314369', 0),
(367, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/78.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.318821', 0),
(368, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/79.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.32184', 0),
(369, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/80.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.335289', 0),
(370, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/81.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.33919', 0),
(371, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/82.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.342478', 0),
(372, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/83.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.345481', 0),
(373, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/84.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.355351', 0),
(374, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/85.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.375032', 0),
(375, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/86.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.377787', 0); 
INSERT INTO "PUBLIC"."PLAY_URL" VALUES
(376, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/87.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.408235', 0),
(377, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/88.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.411357', 0),
(378, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/89.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.426654', 0),
(379, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/90.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.456996', 0),
(380, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/91.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.459949', 0),
(381, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/92.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.495292', 0),
(382, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/93.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.505126', 0),
(383, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/94.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.53649', 0),
(384, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/95.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.563304', 0),
(385, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/96.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.567212', 0),
(386, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/97.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.570704', 0),
(387, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/98.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.59999', 0),
(388, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/99.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.621811', 0),
(389, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/100.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.631246', 0),
(390, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/101.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.653122', 0),
(391, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/102.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.674347', 0),
(392, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/103.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.685437', 0),
(393, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/104.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.706064', 0),
(394, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/105.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.709207', 0),
(395, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/106.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.712265', 0),
(396, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/107.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.739551', 0),
(397, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/108.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.778093', 0),
(398, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/109.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.780786', 0),
(399, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/110.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.809255', 0),
(400, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/111.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.811973', 0);  
INSERT INTO "PUBLIC"."PLAY_URL" VALUES
(401, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/112.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.822303', 0),
(402, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/113.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.835703', 0),
(403, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/114.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.844655', 0),
(404, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/115.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.847307', 0),
(405, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/116.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.855871', 0),
(406, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/117.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.858786', 0),
(407, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/118.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.87476', 0),
(408, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/119.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.877469', 0),
(409, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/120.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.879997', 0),
(410, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/121.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.887083', 0),
(411, U&'/\6211\7684UC\5206\4eab/temp/uc@22026053db534@/\6211\4eec\6109\5feb\7684\597d\65e5\5b50/122.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:09.893396', 0),
(412, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-PQUWv@/The.Princess&#39;s.Gambit\ff082025\ff09\6843\82b1\6620\6c5f\5c71/\675c\6bd4\89c6\754c/~playlist', NULL, NULL, 1, TIMESTAMP '2026-10-20 16:34:35.027822', 0),
(413, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-PQUWv@/The.Princess&#39;s.Gambit\ff082025\ff09\6843\82b1\6620\6c5f\5c71/\675c\6bd4\89c6\754c/The.Princess''s.Gambit.2025.S01E01.2160p.WEB-DL.HEVC.10bit.DV.DDP5.1.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:35.326768', 0),
(414, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-PQUWv@/The.Princess&#39;s.Gambit\ff082025\ff09\6843\82b1\6620\6c5f\5c71/\675c\6bd4\89c6\754c/The.Princess''s.Gambit.2025.S01E02.2160p.WEB-DL.HEVC.10bit.DV.DDP5.1.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:35.329349', 0),
(415, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-PQUWv@/The.Princess&#39;s.Gambit\ff082025\ff09\6843\82b1\6620\6c5f\5c71/\675c\6bd4\89c6\754c/The.Princess''s.Gambit.2025.S01E03.2160p.WEB-DL.HEVC.10bit.DV.DDP5.1.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:35.331742', 0),
(416, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-PQUWv@/The.Princess&#39;s.Gambit\ff082025\ff09\6843\82b1\6620\6c5f\5c71/\675c\6bd4\89c6\754c/The.Princess''s.Gambit.2025.S01E04.2160p.WEB-DL.HEVC.10bit.DV.DDP5.1.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:35.345244', 0),
(417, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-PQUWv@/The.Princess&#39;s.Gambit\ff082025\ff09\6843\82b1\6620\6c5f\5c71/\675c\6bd4\89c6\754c/The.Princess''s.Gambit.2025.S01E05.2160p.WEB-DL.HEVC.10bit.DV.DDP5.1.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:35.356321', 0),
(418, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-PQUWv@/The.Princess&#39;s.Gambit\ff082025\ff09\6843\82b1\6620\6c5f\5c71/\675c\6bd4\89c6\754c/The.Princess''s.Gambit.2025.S01E06.2160p.WEB-DL.HEVC.10bit.DV.DDP5.1.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:35.35907', 0),
(419, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-PQUWv@/The.Princess&#39;s.Gambit\ff082025\ff09\6843\82b1\6620\6c5f\5c71/\675c\6bd4\89c6\754c/The.Princess''s.Gambit.2025.S01E07..2160p.WEB-DL.HEVC.10bit.DV.DDP5.1.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:35.37418', 0),
(420, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-PQUWv@/The.Princess&#39;s.Gambit\ff082025\ff09\6843\82b1\6620\6c5f\5c71/\675c\6bd4\89c6\754c/The.Princess''s.Gambit.2025.S01E08.2160p.WEB-DL.HEVC.10bit.DV.DDP5.1.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:35.376548', 0);           
INSERT INTO "PUBLIC"."PLAY_URL" VALUES
(421, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-PQUWv@/The.Princess&#39;s.Gambit\ff082025\ff09\6843\82b1\6620\6c5f\5c71/\675c\6bd4\89c6\754c/The.Princess''s.Gambit.2025.S01E09.2160p.WEB-DL.HEVC.10bit.DV.DDP5.1.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:35.379156', 0),
(422, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-PQUWv@/The.Princess&#39;s.Gambit\ff082025\ff09\6843\82b1\6620\6c5f\5c71/\675c\6bd4\89c6\754c/The.Princess''s.Gambit.2025.S01E10.2160p.WEB-DL.HEVC.10bit.DV.DDP5.1.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:35.381566', 0),
(423, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-PQUWv@/The.Princess&#39;s.Gambit\ff082025\ff09\6843\82b1\6620\6c5f\5c71/\675c\6bd4\89c6\754c/The.Princess''s.Gambit.2025.S01E11.2160p.WEB-DL.HEVC.10bit.DV.DDP5.1.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:35.390034', 0),
(424, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-PQUWv@/The.Princess&#39;s.Gambit\ff082025\ff09\6843\82b1\6620\6c5f\5c71/\675c\6bd4\89c6\754c/The.Princess''s.Gambit.2025.S01E12.2160p.WEB-DL.HEVC.10bit.DV.DDP5.1.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:35.396074', 0),
(425, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-PQUWv@/The.Princess&#39;s.Gambit\ff082025\ff09\6843\82b1\6620\6c5f\5c71/\675c\6bd4\89c6\754c/The.Princess''s.Gambit.2025.S01E13.2160p.WEB-DL.HEVC.10bit.DV.DDP5.1.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:35.399183', 0),
(426, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-PQUWv@/The.Princess&#39;s.Gambit\ff082025\ff09\6843\82b1\6620\6c5f\5c71/\675c\6bd4\89c6\754c/The.Princess''s.Gambit.2025.S01E14.2160p.WEB-DL.HEVC.10bit.DV.DDP5.1.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:35.405245', 0),
(427, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-PQUWv@/The.Princess&#39;s.Gambit\ff082025\ff09\6843\82b1\6620\6c5f\5c71/\675c\6bd4\89c6\754c/The.Princess''s.Gambit.2025.S01E15.2160p.WEB-DL.HEVC.10bit.DV.DDP5.1.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:35.410909', 0),
(428, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-PQUWv@/The.Princess&#39;s.Gambit\ff082025\ff09\6843\82b1\6620\6c5f\5c71/\675c\6bd4\89c6\754c/The.Princess''s.Gambit.2025.S01E16.2160p.WEB-DL.HEVC.10bit.DV.DDP5.1.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:35.414504', 0),
(429, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-PQUWv@/The.Princess&#39;s.Gambit\ff082025\ff09\6843\82b1\6620\6c5f\5c71/\675c\6bd4\89c6\754c/The.Princess''s.Gambit.2025.S01E17.2160p.WEB-DL.HEVC.10bit.DV.DDP5.1.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:35.416788', 0),
(430, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-PQUWv@/The.Princess&#39;s.Gambit\ff082025\ff09\6843\82b1\6620\6c5f\5c71/\675c\6bd4\89c6\754c/The.Princess&#39;s.Gambit.2025.S01E18.2160p.WEB-DL.HEVC.10bit.DV.DDP5.1.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:35.433507', 0),
(431, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-PQUWv@/The.Princess&#39;s.Gambit\ff082025\ff09\6843\82b1\6620\6c5f\5c71/\675c\6bd4\89c6\754c/The.Princess&#39;s.Gambit.2025.S01E19.2160p.WEB-DL.HEVC.10bit.DV.DDP5.1.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:35.436033', 0),
(432, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-PQUWv@/The.Princess&#39;s.Gambit\ff082025\ff09\6843\82b1\6620\6c5f\5c71/\675c\6bd4\89c6\754c/The.Princess&#39;s.Gambit.2025.S01E20.2160p.WEB-DL.HEVC.10bit.DV.DDP5.1.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:35.438355', 0),
(433, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-PQUWv@/The.Princess&#39;s.Gambit\ff082025\ff09\6843\82b1\6620\6c5f\5c71/\675c\6bd4\89c6\754c/The.Princess&#39;s.Gambit.2025.S01E21.2160p.WEB-DL.HEVC.10bit.DV.DDP5.1.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:35.443712', 0),
(434, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-PQUWv@/The.Princess&#39;s.Gambit\ff082025\ff09\6843\82b1\6620\6c5f\5c71/\675c\6bd4\89c6\754c/The.Princess&#39;s.Gambit.2025.S01E22.2160p.WEB-DL.HEVC.10bit.DV.DDP5.1.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:35.446227', 0),
(435, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-PQUWv@/The.Princess&#39;s.Gambit\ff082025\ff09\6843\82b1\6620\6c5f\5c71/\675c\6bd4\89c6\754c/The.Princess&#39;s.Gambit.2025.S01E23.2160p.WEB-DL.HEVC.10bit.DV.DDP5.1.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:35.455307', 0);            
INSERT INTO "PUBLIC"."PLAY_URL" VALUES
(436, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-PQUWv@/The.Princess&#39;s.Gambit\ff082025\ff09\6843\82b1\6620\6c5f\5c71/\675c\6bd4\89c6\754c/The.Princess&#39;s.Gambit.2025.S01E24.2160p.WEB-DL.HEVC.10bit.DV.DDP5.1.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:35.458336', 0),
(437, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-PQUWv@/The.Princess&#39;s.Gambit\ff082025\ff09\6843\82b1\6620\6c5f\5c71/\675c\6bd4\89c6\754c/The.Princess&#39;s.Gambit.2025.S01E25.2160p.WEB-DL.HEVC.10bit.DV.DDP5.1.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:35.46135', 0),
(438, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-PQUWv@/The.Princess&#39;s.Gambit\ff082025\ff09\6843\82b1\6620\6c5f\5c71/\675c\6bd4\89c6\754c/The.Princess&#39;s.Gambit.2025.S01E26.2160p.WEB-DL.HEVC.10bit.DV.DDP5.1.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:35.474392', 0),
(439, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-PQUWv@/The.Princess&#39;s.Gambit\ff082025\ff09\6843\82b1\6620\6c5f\5c71/\675c\6bd4\89c6\754c/The.Princess&#39;s.Gambit.2025.S01E27.2160p.WEB-DL.HEVC.10bit.DV.DDP5.1.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:35.477271', 0),
(440, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-PQUWv@/The.Princess&#39;s.Gambit\ff082025\ff09\6843\82b1\6620\6c5f\5c71/\675c\6bd4\89c6\754c/The.Princess&#39;s.Gambit.2025.S01E28.2160p.WEB-DL.HEVC.10bit.DV.DDP5.1.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:35.480189', 0),
(441, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-PQUWv@/The.Princess&#39;s.Gambit\ff082025\ff09\6843\82b1\6620\6c5f\5c71/\675c\6bd4\89c6\754c/The.Princess&#39;s.Gambit.2025.S01E29.2160p.WEB-DL.HEVC.10bit.DV.DDP5.1.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:35.500656', 0),
(442, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-PQUWv@/The.Princess&#39;s.Gambit\ff082025\ff09\6843\82b1\6620\6c5f\5c71/\675c\6bd4\89c6\754c/The.Princess&#39;s.Gambit.2025.S01E30.2160p.WEB-DL.HEVC.10bit.DV.DDP5.1.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:35.507355', 0),
(443, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-PQUWv@/The.Princess&#39;s.Gambit\ff082025\ff09\6843\82b1\6620\6c5f\5c71/\675c\6bd4\89c6\754c/The.Princess&#39;s.Gambit.2025.S01E31.2160p.WEB-DL.HEVC.10bit.DV.DDP5.1.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:35.50988', 0),
(444, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-PQUWv@/The.Princess&#39;s.Gambit\ff082025\ff09\6843\82b1\6620\6c5f\5c71/\675c\6bd4\89c6\754c/The.Princess&#39;s.Gambit.2025.S01E32.2160p.WEB-DL.HEVC.10bit.DV.DDP5.1.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:35.515077', 0),
(445, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-PQUWv@/The.Princess&#39;s.Gambit\ff082025\ff09\6843\82b1\6620\6c5f\5c71/\675c\6bd4\89c6\754c/The.Princess&#39;s.Gambit.2025.S01E33.2160p.WEB-DL.HEVC.10bit.DV.DDP5.1.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:35.517358', 0),
(446, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-PQUWv@/The.Princess&#39;s.Gambit\ff082025\ff09\6843\82b1\6620\6c5f\5c71/\675c\6bd4\89c6\754c/The.Princess&#39;s.Gambit.2025.S01E34.2160p.WEB-DL.HEVC.10bit.DV.DDP5.1.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:35.519622', 0),
(447, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-PQUWv@/The.Princess&#39;s.Gambit\ff082025\ff09\6843\82b1\6620\6c5f\5c71/\675c\6bd4\89c6\754c/The.Princess&#39;s.Gambit.2025.S01E35.2160p.WEB-DL.HEVC.10bit.DV.DDP5.1.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:35.534635', 0),
(448, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-PQUWv@/The.Princess&#39;s.Gambit\ff082025\ff09\6843\82b1\6620\6c5f\5c71/\675c\6bd4\89c6\754c/The.Princess&#39;s.Gambit.2025.S01E36.2160p.WEB-DL.HEVC.10bit.DV.DDP5.1.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:35.537165', 0),
(449, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/~playlist', NULL, NULL, 1, TIMESTAMP '2026-10-20 16:34:50.381265', 0),
(450, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/1/\4eac\591c\543b\96fe\ff0865\96c6\ff09\9a6c\70c1\68cb\ff06\6768\6d1b\4edf\ff081080P\ff09/\7b2c01\96c6.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:50.921333', 0),
(451, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/1/\4eac\591c\543b\96fe\ff0865\96c6\ff09\9a6c\70c1\68cb\ff06\6768\6d1b\4edf\ff081080P\ff09/\7b2c02\96c6.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:50.923879', 0); 
INSERT INTO "PUBLIC"."PLAY_URL" VALUES
(452, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/1/\4eac\591c\543b\96fe\ff0865\96c6\ff09\9a6c\70c1\68cb\ff06\6768\6d1b\4edf\ff081080P\ff09/\7b2c03\96c6.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:50.926113', 0),
(453, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/1/\4eac\591c\543b\96fe\ff0865\96c6\ff09\9a6c\70c1\68cb\ff06\6768\6d1b\4edf\ff081080P\ff09/\7b2c04\96c6.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:50.934117', 0),
(454, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/1/\4eac\591c\543b\96fe\ff0865\96c6\ff09\9a6c\70c1\68cb\ff06\6768\6d1b\4edf\ff081080P\ff09/\7b2c05\96c6.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:50.936644', 0),
(455, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/1/\4eac\591c\543b\96fe\ff0865\96c6\ff09\9a6c\70c1\68cb\ff06\6768\6d1b\4edf\ff081080P\ff09/\7b2c06\96c6.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:50.939043', 0),
(456, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/1/\4eac\591c\543b\96fe\ff0865\96c6\ff09\9a6c\70c1\68cb\ff06\6768\6d1b\4edf\ff081080P\ff09/\7b2c07\96c6.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:50.96808', 0),
(457, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/1/\4eac\591c\543b\96fe\ff0865\96c6\ff09\9a6c\70c1\68cb\ff06\6768\6d1b\4edf\ff081080P\ff09/\7b2c08\96c6.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:50.970663', 0),
(458, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/1/\4eac\591c\543b\96fe\ff0865\96c6\ff09\9a6c\70c1\68cb\ff06\6768\6d1b\4edf\ff081080P\ff09/\7b2c09\96c6.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:50.973743', 0),
(459, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/1/\4eac\591c\543b\96fe\ff0865\96c6\ff09\9a6c\70c1\68cb\ff06\6768\6d1b\4edf\ff081080P\ff09/\7b2c10\96c6.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:50.976166', 0),
(460, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/1/\4eac\591c\543b\96fe\ff0865\96c6\ff09\9a6c\70c1\68cb\ff06\6768\6d1b\4edf\ff081080P\ff09/\7b2c11\96c6.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:50.978514', 0),
(461, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/1/\4eac\591c\543b\96fe\ff0865\96c6\ff09\9a6c\70c1\68cb\ff06\6768\6d1b\4edf\ff081080P\ff09/\7b2c12\96c6.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:50.980782', 0),
(462, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/1/\4eac\591c\543b\96fe\ff0865\96c6\ff09\9a6c\70c1\68cb\ff06\6768\6d1b\4edf\ff081080P\ff09/\7b2c13\96c6.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:50.985163', 0),
(463, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/1/\4eac\591c\543b\96fe\ff0865\96c6\ff09\9a6c\70c1\68cb\ff06\6768\6d1b\4edf\ff081080P\ff09/\7b2c14\96c6.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:50.987459', 0),
(464, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/1/\4eac\591c\543b\96fe\ff0865\96c6\ff09\9a6c\70c1\68cb\ff06\6768\6d1b\4edf\ff081080P\ff09/\7b2c15\96c6.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:50.989703', 0),
(465, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/1/\4eac\591c\543b\96fe\ff0865\96c6\ff09\9a6c\70c1\68cb\ff06\6768\6d1b\4edf\ff081080P\ff09/\7b2c16\96c6.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:50.991941', 0),
(466, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/1/\4eac\591c\543b\96fe\ff0865\96c6\ff09\9a6c\70c1\68cb\ff06\6768\6d1b\4edf\ff081080P\ff09/\7b2c17\96c6.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:50.994453', 0),
(467, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/1(1)/\5168\5458\8001\516d\ff0c\6211\771f\4e0d\662f\5927\4f6c\554a\ff08123\96c6\ff09/\7b2c10\96c6.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.223498', 0),
(468, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/1(1)/\5168\5458\8001\516d\ff0c\6211\771f\4e0d\662f\5927\4f6c\554a\ff08123\96c6\ff09/\7b2c11\96c6.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.234085', 0);     
INSERT INTO "PUBLIC"."PLAY_URL" VALUES
(469, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/1(1)/\5168\5458\8001\516d\ff0c\6211\771f\4e0d\662f\5927\4f6c\554a\ff08123\96c6\ff09/\7b2c12\96c6.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.236595', 0),
(470, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/1(1)/\5168\5458\8001\516d\ff0c\6211\771f\4e0d\662f\5927\4f6c\554a\ff08123\96c6\ff09/\7b2c100\96c6.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.23891', 0),
(471, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/1(1)/\5168\5458\8001\516d\ff0c\6211\771f\4e0d\662f\5927\4f6c\554a\ff08123\96c6\ff09/\7b2c101\96c6.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.254052', 0),
(472, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/1(1)/\5168\5458\8001\516d\ff0c\6211\771f\4e0d\662f\5927\4f6c\554a\ff08123\96c6\ff09/\7b2c102\96c6.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.256813', 0),
(473, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/1(1)/\5168\5458\8001\516d\ff0c\6211\771f\4e0d\662f\5927\4f6c\554a\ff08123\96c6\ff09/\7b2c103\96c6.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.259159', 0),
(474, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/1(1)/\5168\5458\8001\516d\ff0c\6211\771f\4e0d\662f\5927\4f6c\554a\ff08123\96c6\ff09/\7b2c104\96c6.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.261771', 0),
(475, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/1(1)/\5168\5458\8001\516d\ff0c\6211\771f\4e0d\662f\5927\4f6c\554a\ff08123\96c6\ff09/\7b2c105\96c6.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.275183', 0),
(476, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/1(1)/\5168\5458\8001\516d\ff0c\6211\771f\4e0d\662f\5927\4f6c\554a\ff08123\96c6\ff09/\7b2c106\96c6.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.279771', 0),
(477, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/1(1)/\5168\5458\8001\516d\ff0c\6211\771f\4e0d\662f\5927\4f6c\554a\ff08123\96c6\ff09/\7b2c107\96c6.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.292712', 0),
(478, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/1(1)/\5168\5458\8001\516d\ff0c\6211\771f\4e0d\662f\5927\4f6c\554a\ff08123\96c6\ff09/\7b2c108\96c6.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.295618', 0),
(479, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/1(1)/\5168\5458\8001\516d\ff0c\6211\771f\4e0d\662f\5927\4f6c\554a\ff08123\96c6\ff09/\7b2c109\96c6.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.304437', 0),
(480, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/1(1)/\5168\5458\8001\516d\ff0c\6211\771f\4e0d\662f\5927\4f6c\554a\ff08123\96c6\ff09/\7b2c110\96c6.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.306757', 0),
(481, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/1(1)/\5168\5458\8001\516d\ff0c\6211\771f\4e0d\662f\5927\4f6c\554a\ff08123\96c6\ff09/\7b2c111\96c6.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.313022', 0),
(482, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/1(1)/\5168\5458\8001\516d\ff0c\6211\771f\4e0d\662f\5927\4f6c\554a\ff08123\96c6\ff09/\7b2c112\96c6.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.327439', 0),
(483, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/1(1)/\5168\5458\8001\516d\ff0c\6211\771f\4e0d\662f\5927\4f6c\554a\ff08123\96c6\ff09/\7b2c113\96c6.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.330398', 0),
(484, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/1(1)/\5168\5458\8001\516d\ff0c\6211\771f\4e0d\662f\5927\4f6c\554a\ff08123\96c6\ff09/\7b2c114\96c6.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.340751', 0),
(485, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/1(1)/\5168\5458\8001\516d\ff0c\6211\771f\4e0d\662f\5927\4f6c\554a\ff08123\96c6\ff09/\7b2c115\96c6.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.355026', 0),
(486, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/1(1)/\5168\5458\8001\516d\ff0c\6211\771f\4e0d\662f\5927\4f6c\554a\ff08123\96c6\ff09/\7b2c116\96c6.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.357269', 0);   
INSERT INTO "PUBLIC"."PLAY_URL" VALUES
(487, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/1(1)/\5168\5458\8001\516d\ff0c\6211\771f\4e0d\662f\5927\4f6c\554a\ff08123\96c6\ff09/\7b2c117\96c6.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.359536', 0),
(488, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/1(1)/\5168\5458\8001\516d\ff0c\6211\771f\4e0d\662f\5927\4f6c\554a\ff08123\96c6\ff09/\7b2c118\96c6.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.362021', 0),
(489, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/1(1)/\5168\5458\8001\516d\ff0c\6211\771f\4e0d\662f\5927\4f6c\554a\ff08123\96c6\ff09/\7b2c119\96c6.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.375859', 0),
(490, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/1(1)/\5168\5458\8001\516d\ff0c\6211\771f\4e0d\662f\5927\4f6c\554a\ff08123\96c6\ff09/\7b2c120\96c6.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.378577', 0),
(491, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/1(1)/\5168\5458\8001\516d\ff0c\6211\771f\4e0d\662f\5927\4f6c\554a\ff08123\96c6\ff09/\7b2c121\96c6.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.381072', 0),
(492, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/1(1)/\5168\5458\8001\516d\ff0c\6211\771f\4e0d\662f\5927\4f6c\554a\ff08123\96c6\ff09/\7b2c122\96c6.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.392321', 0),
(493, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/1(1)/\5168\5458\8001\516d\ff0c\6211\771f\4e0d\662f\5927\4f6c\554a\ff08123\96c6\ff09/\7b2c123\96c6.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.417376', 0),
(494, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/12/12.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.505664', 0),
(495, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/1.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.760853', 0),
(496, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/2.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.773475', 0),
(497, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/3.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.775804', 0),
(498, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/4.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.77916', 0),
(499, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/5.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.793635', 0),
(500, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/6.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.796237', 0),
(501, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/10.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.798589', 0),
(502, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/11.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.801846', 0),
(503, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/12.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.80817', 0),
(504, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/13.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.810444', 0),
(505, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/14.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.82279', 0),
(506, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/15.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.825425', 0);              
INSERT INTO "PUBLIC"."PLAY_URL" VALUES
(507, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/16.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.828247', 0),
(508, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/17.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.836099', 0),
(509, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/18.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.838516', 0),
(510, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/19.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.840734', 0),
(511, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/20.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.853506', 0),
(512, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/21.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.863604', 0),
(513, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/22.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.866652', 0),
(514, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/23.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.8689', 0),
(515, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/24.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.874228', 0),
(516, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/25.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.876579', 0),
(517, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/26.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.884838', 0),
(518, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/27.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.887209', 0),
(519, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/28.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.889516', 0),
(520, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/29.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.891767', 0),
(521, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/30.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.90452', 0),
(522, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/31.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.906888', 0),
(523, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/32.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.918839', 0),
(524, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/33.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.921842', 0),
(525, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/34.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.93411', 0),
(526, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/35.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.936701', 0),
(527, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/36.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.950688', 0);         
INSERT INTO "PUBLIC"."PLAY_URL" VALUES
(528, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/37.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.963478', 0),
(529, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/38.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.966085', 0),
(530, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/39.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.968368', 0),
(531, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/40.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.970615', 0),
(532, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/41.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.978529', 0),
(533, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/42.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.980989', 0),
(534, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/43.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.993635', 0),
(535, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/44.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.997009', 0),
(536, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/45.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:51.999323', 0),
(537, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/46.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:52.001673', 0),
(538, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/47.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:52.005274', 0),
(539, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/48.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:52.013538', 0),
(540, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/49.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:52.015968', 0),
(541, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/50.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:52.029424', 0),
(542, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/51.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:52.031803', 0),
(543, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/52.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:52.043295', 0),
(544, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/53.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:52.046555', 0),
(545, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/54.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:52.049596', 0),
(546, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/55.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:52.06313', 0),
(547, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/56.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:52.065449', 0),
(548, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/57.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:52.068157', 0);      
INSERT INTO "PUBLIC"."PLAY_URL" VALUES
(549, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/58.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:52.070586', 0),
(550, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/59.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:52.078684', 0),
(551, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/60.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:52.081107', 0),
(552, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/61.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:52.095967', 0),
(553, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@QCjSTddJaXb@/9/2/\5f53\5bb6\5a18\5b50\4fcf\592b\90ce\ff0865\96c6\ff09/62.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 16:34:52.098473', 0),
(554, U&'/\6211\7684UC\5206\4eab', NULL, NULL, 1, TIMESTAMP '2026-10-20 19:36:20.250592', 0),
(555, U&'/\6211\7684\5938\514b\5206\4eab', NULL, NULL, 1, TIMESTAMP '2026-10-20 19:36:20.255148', 0),
(556, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab', NULL, NULL, 1, TIMESTAMP '2026-10-20 19:36:20.266705', 0),
(557, U&'/\+01f38e\6211\7684\5957\5a03', NULL, NULL, 1, TIMESTAMP '2026-10-20 19:36:20.274583', 0),
(558, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@uABsSgfqxjv@/\9ed1z\767dz\6e05z\9053z\592b (2026) 4K/~playlist', NULL, NULL, 1, TIMESTAMP '2026-10-20 19:45:29.964126', 0),
(559, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@uABsSgfqxjv@/\9ed1z\767dz\6e05z\9053z\592b (2026) 4K/2026.S01E01.2160p.NF.WEB-DL.HEVC.DDP 5.1-HHWEB.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:30.216499', 0),
(560, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@uABsSgfqxjv@/\9ed1z\767dz\6e05z\9053z\592b (2026) 4K/2026.S01E02.2160p.NF.WEB-DL.HEVC.DDP 5.1-HHWEB.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:30.226187', 0),
(561, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@uABsSgfqxjv@/\9ed1z\767dz\6e05z\9053z\592b (2026) 4K/2026.S01E03.2160p.NF.WEB-DL.HEVC.DDP 5.1-HHWEB.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:30.228322', 0),
(562, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@uABsSgfqxjv@/\9ed1z\767dz\6e05z\9053z\592b (2026) 4K/2026.S01E04.2160p.NF.WEB-DL.HEVC.DDP 5.1-HHWEB.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:30.230114', 0),
(563, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@uABsSgfqxjv@/\9ed1z\767dz\6e05z\9053z\592b (2026) 4K/2026.S01E05.2160p.NF.WEB-DL.HEVC.DDP 5.1-HHWEB.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:30.231861', 0),
(564, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@uABsSgfqxjv@/\9ed1z\767dz\6e05z\9053z\592b (2026) 4K/2026.S01E06.2160p.NF.WEB-DL.HEVC.DDP 5.1-HHWEB.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:30.233619', 0),
(565, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@uABsSgfqxjv@/\9ed1z\767dz\6e05z\9053z\592b (2026) 4K/2026.S01E07.2160p.NF.WEB-DL.HEVC.DDP 5.1-HHWEB.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:30.245975', 0),
(566, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@uABsSgfqxjv@/\9ed1z\767dz\6e05z\9053z\592b (2026) 4K/2026.S01E08.2160p.NF.WEB-DL.HEVC.DDP 5.1-HHWEB.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:30.248092', 0),
(567, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@uABsSgfqxjv@/\9ed1z\767dz\6e05z\9053z\592b (2026) 4K/2026.S01E09.2160p.NF.WEB-DL.HEVC.DDP 5.1-HHWEB.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:30.249891', 0),
(568, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@uABsSgfqxjv@/\9ed1z\767dz\6e05z\9053z\592b (2026) 4K/2026.S01E10.2160p.NF.WEB-DL.HEVC.DDP 5.1-HHWEB.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:30.251853', 0),
(569, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/~playlist', NULL, NULL, 1, TIMESTAMP '2026-10-20 19:45:58.356537', 0),
(570, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a1 (2022)\7b2c1-52\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E01.2160p.WEB-DL.HEVC.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.086496', 0);   
INSERT INTO "PUBLIC"."PLAY_URL" VALUES
(571, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a1 (2022)\7b2c1-52\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E02.2160p.WEB-DL.HEVC.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.089913', 0),
(572, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a1 (2022)\7b2c1-52\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E03.2160p.WEB-DL.HEVC.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.092185', 0),
(573, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a1 (2022)\7b2c1-52\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E04.2160p.WEB-DL.HEVC.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.096229', 0),
(574, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a1 (2022)\7b2c1-52\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E05.2160p.WEB-DL.HEVC.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.098431', 0),
(575, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a1 (2022)\7b2c1-52\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E06.2160p.WEB-DL.HEVC.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.100276', 0),
(576, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a1 (2022)\7b2c1-52\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E07.2160p.WEB-DL.HEVC.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.102135', 0),
(577, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a1 (2022)\7b2c1-52\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E08.2160p.WEB-DL.HEVC.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.107734', 0),
(578, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a1 (2022)\7b2c1-52\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E09.2160p.WEB-DL.HEVC.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.109652', 0),
(579, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a1 (2022)\7b2c1-52\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E10.2160p.WEB-DL.HEVC.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.116314', 0),
(580, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a1 (2022)\7b2c1-52\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E11.2160p.WEB-DL.HEVC.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.118243', 0),
(581, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a1 (2022)\7b2c1-52\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E12.2160p.WEB-DL.HEVC.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.120023', 0),
(582, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a1 (2022)\7b2c1-52\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E13.2160p.WEB-DL.HEVC.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.136869', 0),
(583, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a1 (2022)\7b2c1-52\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E14.2160p.WEB-DL.HEVC.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.139258', 0);          
INSERT INTO "PUBLIC"."PLAY_URL" VALUES
(584, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a1 (2022)\7b2c1-52\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E15.2160p.WEB-DL.HEVC.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.141109', 0),
(585, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a1 (2022)\7b2c1-52\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E16.2160p.WEB-DL.HEVC.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.14861', 0),
(586, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a1 (2022)\7b2c1-52\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E17.2160p.WEB-DL.HEVC.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.150684', 0),
(587, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a1 (2022)\7b2c1-52\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E18.2160p.WEB-DL.HEVC.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.152469', 0),
(588, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a1 (2022)\7b2c1-52\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E19.2160p.WEB-DL.HEVC.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.154221', 0),
(589, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a1 (2022)\7b2c1-52\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E20.2160p.WEB-DL.HEVC.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.17665', 0),
(590, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a1 (2022)\7b2c1-52\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E21.2160p.WEB-DL.HEVC.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.178882', 0),
(591, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a1 (2022)\7b2c1-52\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E22.2160p.WEB-DL.HEVC.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.180701', 0),
(592, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a1 (2022)\7b2c1-52\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E23.2160p.WEB-DL.HEVC.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.182473', 0),
(593, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a1 (2022)\7b2c1-52\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E24.2160p.WEB-DL.HEVC.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.184174', 0),
(594, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a1 (2022)\7b2c1-52\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E25.2160p.WEB-DL.HEVC.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.199946', 0),
(595, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a1 (2022)\7b2c1-52\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E26.2160p.WEB-DL.HEVC.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.202042', 0),
(596, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a1 (2022)\7b2c1-52\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E27.2160p.WEB-DL.HEVC.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.203825', 0);            
INSERT INTO "PUBLIC"."PLAY_URL" VALUES
(597, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a1 (2022)\7b2c1-52\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E28.2160p.WEB-DL.HEVC.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.213194', 0),
(598, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a1 (2022)\7b2c1-52\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E29.2160p.WEB-DL.HEVC.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.225634', 0),
(599, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a1 (2022)\7b2c1-52\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E30.2160p.WEB-DL.HEVC.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.228227', 0),
(600, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a1 (2022)\7b2c1-52\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E31.2160p.WEB-DL.HEVC.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.230064', 0),
(601, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a1 (2022)\7b2c1-52\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E32.2160p.WEB-DL.HEVC.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.231799', 0),
(602, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a1 (2022)\7b2c1-52\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E33.2160p.WEB-DL.HEVC.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.233507', 0),
(603, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a1 (2022)\7b2c1-52\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E34.2160p.WEB-DL.HEVC.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.235384', 0),
(604, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a1 (2022)\7b2c1-52\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E35.2160p.WEB-DL.HEVC.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.237635', 0),
(605, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a1 (2022)\7b2c1-52\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E36.2160p.WEB-DL.HEVC.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.239686', 0),
(606, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a1 (2022)\7b2c1-52\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E37.2160p.WEB-DL.HEVC.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.241431', 0),
(607, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a1 (2022)\7b2c1-52\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E38.2160p.WEB-DL.HEVC.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.254642', 0),
(608, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a1 (2022)\7b2c1-52\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E39.2160p.WEB-DL.HEVC.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.256884', 0),
(609, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a1 (2022)\7b2c1-52\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E40.2160p.WEB-DL.HEVC.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.258759', 0);          
INSERT INTO "PUBLIC"."PLAY_URL" VALUES
(610, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a1 (2022)\7b2c1-52\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E41.2160p.WEB-DL.HEVC.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.26047', 0),
(611, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a1 (2022)\7b2c1-52\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E42.2160p.WEB-DL.HEVC.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.262145', 0),
(612, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a1 (2022)\7b2c1-52\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E43.2160p.WEB-DL.HEVC.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.263831', 0),
(613, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a1 (2022)\7b2c1-52\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E44.2160p.WEB-DL.HEVC.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.27572', 0),
(614, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a1 (2022)\7b2c1-52\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E45.2160p.WEB-DL.HEVC.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.277877', 0),
(615, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a1 (2022)\7b2c1-52\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E46.2160p.WEB-DL.HEVC.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.286493', 0),
(616, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a1 (2022)\7b2c1-52\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E47.2160p.WEB-DL.HEVC.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.288507', 0),
(617, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a1 (2022)\7b2c1-52\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E48.2160p.WEB-DL.HEVC.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.290346', 0),
(618, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a1 (2022)\7b2c1-52\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E49.2160p.WEB-DL.HEVC.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.292144', 0),
(619, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a1 (2022)\7b2c1-52\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E50.2160p.WEB-DL.HEVC.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.301239', 0),
(620, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a1 (2022)\7b2c1-52\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E51.2160p.WEB-DL.HEVC.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.315731', 0),
(621, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a1 (2022)\7b2c1-52\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E52.2160p.WEB-DL.HEVC.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.320349', 0),
(622, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S01E67.2022.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.85674', 0);   
INSERT INTO "PUBLIC"."PLAY_URL" VALUES
(623, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E53.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.859055', 0),
(624, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E54.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.86092', 0),
(625, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E55.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.862669', 0),
(626, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E56.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.864699', 0),
(627, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E57.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.877216', 0),
(628, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E58.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.879024', 0),
(629, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E59.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.88117', 0),
(630, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E60.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.883673', 0),
(631, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E61.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.896634', 0),
(632, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E62.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.898962', 0),
(633, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E63.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.900752', 0),
(634, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E64.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.902617', 0),
(635, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E65.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.904535', 0);          
INSERT INTO "PUBLIC"."PLAY_URL" VALUES
(636, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79 \5e74\756a.Fights.Break.Sphere.2022.S05E66.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.9149', 0),
(637, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E68.2022.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.917925', 0),
(638, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E69.2022.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.919803', 0),
(639, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E70.2022.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.927219', 0),
(640, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E71.2022.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.929159', 0),
(641, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E72.2022.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.931066', 0),
(642, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E73.2022.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.932817', 0),
(643, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E74.2022.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.934578', 0),
(644, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E75.2022.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.946794', 0),
(645, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E76.2022.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.953575', 0),
(646, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E77.2022.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.955798', 0),
(647, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E78.2022.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.959009', 0),
(648, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E79.2022.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.962012', 0);          
INSERT INTO "PUBLIC"."PLAY_URL" VALUES
(649, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E80.2022.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.967022', 0),
(650, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E81.2022.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.970153', 0),
(651, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E82.2022.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.972002', 0),
(652, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E83.2022.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.987275', 0),
(653, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E84.2022.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.989123', 0),
(654, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E85.2022.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.99088', 0),
(655, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E86.2022.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:45:59.993563', 0),
(656, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E87.2022.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.003521', 0),
(657, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E88.2022.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.005999', 0),
(658, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E89.2022.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.008066', 0),
(659, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E90.2022.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.009902', 0),
(660, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E91.2022.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.011828', 0),
(661, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E92.2022.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.013612', 0);         
INSERT INTO "PUBLIC"."PLAY_URL" VALUES
(662, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E93.2022.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.025498', 0),
(663, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E94.2022.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.027909', 0),
(664, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E95.2022.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.029768', 0),
(665, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E96.2022.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.031618', 0),
(666, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E97.2022.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.033408', 0),
(667, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E98.2022.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.035161', 0),
(668, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E99.2022.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.047761', 0),
(669, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E100.2022.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.054806', 0),
(670, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E101.2022.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.057372', 0),
(671, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E102.2022.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.059183', 0),
(672, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E103.2022.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.061082', 0),
(673, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E104.2022.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.077553', 0),
(674, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a2\200e (2023)\7b2c53-105\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E105.2022.2160p.WEB-DL.H265.DDP2.0.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.082963', 0);  
INSERT INTO "PUBLIC"."PLAY_URL" VALUES
(675, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a3\200e (2024)\7b2c106-157\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E106.2022.2160p.WEB-DL.DDP2.0.H265.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.520369', 0),
(676, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a3\200e (2024)\7b2c106-157\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E107.2022.2160p.WEB-DL.DDP2.0.H265.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.526375', 0),
(677, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a3\200e (2024)\7b2c106-157\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E108.2022.2160p.WEB-DL.DDP2.0.H265.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.528326', 0),
(678, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a3\200e (2024)\7b2c106-157\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E109.2022.2160p.WEB-DL.DDP2.0.H265.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.530511', 0),
(679, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a3\200e (2024)\7b2c106-157\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E110.2022.2160p.WEB-DL.DDP2.0.H265.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.534336', 0),
(680, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a3\200e (2024)\7b2c106-157\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E111.2022.2160p.WEB-DL.DDP2.0.H265.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.571467', 0),
(681, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a3\200e (2024)\7b2c106-157\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E112.2022.2160p.WEB-DL.DDP2.0.H265.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.579221', 0),
(682, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a3\200e (2024)\7b2c106-157\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E113.2022.2160p.WEB-DL.DDP2.0.H265.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.587382', 0),
(683, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a3\200e (2024)\7b2c106-157\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E114.2022.2160p.WEB-DL.DDP2.0.H265.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.589573', 0),
(684, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a3\200e (2024)\7b2c106-157\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E115.2022.2160p.WEB-DL.DDP2.0.H265.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.591429', 0),
(685, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a3\200e (2024)\7b2c106-157\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E116.2022.2160p.WEB-DL.DDP2.0.H265.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.593685', 0),
(686, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a3\200e (2024)\7b2c106-157\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E117.2022.2160p.WEB-DL.DDP2.0.H265.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.597823', 0),
(687, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a3\200e (2024)\7b2c106-157\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E118.2022.2160p.WEB-DL.DDP2.0.H265.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.607166', 0);              
INSERT INTO "PUBLIC"."PLAY_URL" VALUES
(688, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a3\200e (2024)\7b2c106-157\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E119.2022.2160p.WEB-DL.DDP2.0.H265.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.610221', 0),
(689, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a3\200e (2024)\7b2c106-157\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E120.2022.2160p.WEB-DL.DDP2.0.H265.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.612127', 0),
(690, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a3\200e (2024)\7b2c106-157\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E121.2022.2160p.WEB-DL.DDP2.0.H265.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.614064', 0),
(691, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a3\200e (2024)\7b2c106-157\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E122.2022.2160p.WEB-DL.DDP2.0.H265.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.6172', 0),
(692, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a3\200e (2024)\7b2c106-157\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E123.2022.2160p.WEB-DL.DDP2.0.H265.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.619373', 0),
(693, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a3\200e (2024)\7b2c106-157\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E124.2022.2160p.WEB-DL.DDP2.0.H265.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.621253', 0),
(694, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a3\200e (2024)\7b2c106-157\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E125.2022.2160p.WEB-DL.DDP2.0.H265.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.623025', 0),
(695, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a3\200e (2024)\7b2c106-157\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E126.2022.2160p.WEB-DL.DDP2.0.H265.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.625481', 0),
(696, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a3\200e (2024)\7b2c106-157\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E127.2022.2160p.WEB-DL.DDP2.0.H265.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.62751', 0),
(697, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a3\200e (2024)\7b2c106-157\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E128.2022.2160p.WEB-DL.DDP2.0.H265.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.633888', 0),
(698, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a3\200e (2024)\7b2c106-157\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E129.2022.2160p.WEB-DL.DDP2.0.H265.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.636008', 0),
(699, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a3\200e (2024)\7b2c106-157\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E130.2022.2160p.WEB-DL.DDP2.0.H265.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.637825', 0),
(700, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a3\200e (2024)\7b2c106-157\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E131.2022.2160p.WEB-DL.DDP2.0.H265.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.639587', 0); 
INSERT INTO "PUBLIC"."PLAY_URL" VALUES
(701, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a3\200e (2024)\7b2c106-157\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E132.2022.2160p.WEB-DL.DDP2.0.H265.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.641568', 0),
(702, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a3\200e (2024)\7b2c106-157\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E133.2022.2160p.WEB-DL.DDP2.0.H265.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.643434', 0),
(703, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a3\200e (2024)\7b2c106-157\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E134.2022.2160p.WEB-DL.DDP2.0.H265.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.650762', 0),
(704, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a3\200e (2024)\7b2c106-157\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E135.2022.2160p.WEB-DL.DDP2.0.H265.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.652993', 0),
(705, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a3\200e (2024)\7b2c106-157\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E136.2022.2160p.WEB-DL.DDP2.0.H265.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.654879', 0),
(706, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a3\200e (2024)\7b2c106-157\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E137.2022.2160p.WEB-DL.DDP2.0.H265.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.656966', 0),
(707, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a3\200e (2024)\7b2c106-157\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E138.2022.2160p.WEB-DL.DDP2.0.H265.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.659685', 0),
(708, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a3\200e (2024)\7b2c106-157\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E139.2022.2160p.WEB-DL.DDP2.0.H265.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.661908', 0),
(709, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a3\200e (2024)\7b2c106-157\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E140.2022.2160p.WEB-DL.DDP2.0.H265.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.668324', 0),
(710, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a3\200e (2024)\7b2c106-157\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E141.2022.2160p.WEB-DL.DDP2.0.H265.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.670328', 0),
(711, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a3\200e (2024)\7b2c106-157\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E142.2022.2160p.WEB-DL.DDP2.0.H265.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.67225', 0),
(712, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a3\200e (2024)\7b2c106-157\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E143.2022.2160p.WEB-DL.DDP2.0.H265.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.687937', 0),
(713, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a3\200e (2024)\7b2c106-157\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E144.2022.2160p.WEB-DL.DDP2.0.H265.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.697499', 0);               
INSERT INTO "PUBLIC"."PLAY_URL" VALUES
(714, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a3\200e (2024)\7b2c106-157\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E145.2022.2160p.WEB-DL.DDP2.0.H265.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.707575', 0),
(715, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a3\200e (2024)\7b2c106-157\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E146.2022.2160p.WEB-DL.DDP2.0.H265.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.717255', 0),
(716, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a3\200e (2024)\7b2c106-157\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E147.2022.2160p.WEB-DL.DDP2.0.H265.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.719222', 0),
(717, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a3\200e (2024)\7b2c106-157\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E148.2022.2160p.WEB-DL.DDP2.0.H265.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.72127', 0),
(718, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a3\200e (2024)\7b2c106-157\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E149.2022.2160p.WEB-DL.DDP2.0.H265.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.723191', 0),
(719, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a3\200e (2024)\7b2c106-157\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E150.2022.2160p.WEB-DL.DDP2.0.H265.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.724988', 0),
(720, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a3\200e (2024)\7b2c106-157\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E151.2022.2160p.WEB-DL.DDP2.0.H265.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.738372', 0),
(721, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a3\200e (2024)\7b2c106-157\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E152.2022.2160p.WEB-DL.DDP2.0.H265.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.740391', 0),
(722, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a3\200e (2024)\7b2c106-157\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E153.2022.2160p.WEB-DL.DDP2.0.H265.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.742227', 0),
(723, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a3\200e (2024)\7b2c106-157\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E154.2022.2160p.WEB-DL.DDP2.0.H265.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.744018', 0),
(724, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a3\200e (2024)\7b2c106-157\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E155.2022.2160p.WEB-DL.DDP2.0.H265.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.752041', 0),
(725, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a3\200e (2024)\7b2c106-157\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E156.2022.2160p.WEB-DL.DDP2.0.H265.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.754161', 0),
(726, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a3\200e (2024)\7b2c106-157\96c6/\6597\7834\82cd\7a79.\5e74\756a.Fights.Break.Sphere.S05E157.2022.2160p.WEB-DL.DDP2.0.H265.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:00.76634', 0);
INSERT INTO "PUBLIC"."PLAY_URL" VALUES
(727, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E158.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.209294', 0),
(728, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E159.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.212007', 0),
(729, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E160.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.217044', 0),
(730, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E161.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.218845', 0),
(731, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E162.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.226299', 0),
(732, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E163.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.228275', 0),
(733, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E164.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.230095', 0),
(734, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E166.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.231916', 0),
(735, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E167.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.233767', 0),
(736, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E168.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.245832', 0),
(737, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E169.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.248021', 0),
(738, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E170.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.254316', 0),
(739, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E171.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.266755', 0),
(740, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E172.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.268731', 0),
(741, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E173.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.270504', 0),
(742, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E174.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.272235', 0);         
INSERT INTO "PUBLIC"."PLAY_URL" VALUES
(743, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E175.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.274649', 0),
(744, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E176.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.281962', 0),
(745, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E177.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.284015', 0),
(746, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E178.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.29318', 0),
(747, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E179.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.295252', 0),
(748, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E180.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.298055', 0),
(749, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E181.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.300059', 0),
(750, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E182.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.301853', 0),
(751, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E183.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.303646', 0),
(752, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E184.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.316396', 0),
(753, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E185.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.318461', 0),
(754, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E186.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.320403', 0),
(755, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E187.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.322372', 0),
(756, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E188.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.32434', 0),
(757, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E189.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.329747', 0),
(758, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E190.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.331857', 0);           
INSERT INTO "PUBLIC"."PLAY_URL" VALUES
(759, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E191.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.333878', 0),
(760, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E192.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.336119', 0),
(761, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E193.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.338074', 0),
(762, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E194.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.339836', 0),
(763, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E195.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.341581', 0),
(764, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E196.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.343357', 0),
(765, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E197.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.3451', 0),
(766, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E198.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.346998', 0),
(767, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E199.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.34877', 0),
(768, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E200.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.350767', 0),
(769, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E201.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.352947', 0),
(770, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E202.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.354879', 0),
(771, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E203.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.356809', 0),
(772, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E204.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.362702', 0),
(773, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E205.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.364623', 0),
(774, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E206.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.373405', 0);            
INSERT INTO "PUBLIC"."PLAY_URL" VALUES
(775, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E207.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.384916', 0),
(776, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E208.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.387384', 0),
(777, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E209.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.389202', 0),
(778, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E210.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.390988', 0),
(779, U&'/\6211\7684123\5206\4eab/temp/123@u9izjv-GwuWv@/6-\6597.\7834.\82cd.\7a79 \5e74\756a(\5408\96c6\ff09/\6597\7834\82cd\7a79 \5e74\756a4 (2025)\7b2c158-208\96c6/S01E211.2025.2160p.WEB-DL.H265.AAC.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:01.392727', 0),
(780, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@o2EbwmLSWJf@/9.14-\4e91\9619/~playlist', NULL, NULL, 1, TIMESTAMP '2026-10-20 19:46:33.180709', 0),
(781, U&'/\+01f234\6211\7684\963f\91cc\5206\4eab/temp/ali@o2EbwmLSWJf@/9.14-\4e91\9619/5.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:33.543059', 0),
(782, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@cbacc0c41819@/\6797\5fc3\5982g/~playlist', NULL, NULL, 1, TIMESTAMP '2026-10-20 19:46:48.981939', 0),
(783, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@cbacc0c41819@/\6797\5fc3\5982g/2.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:49.262926', 0),
(784, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@cbacc0c41819@/\6797\5fc3\5982g/3.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:49.265121', 0),
(785, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@cbacc0c41819@/\6797\5fc3\5982g/4.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:49.273688', 0),
(786, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@cbacc0c41819@/\6797\5fc3\5982g/5.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:49.279517', 0),
(787, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@cbacc0c41819@/\6797\5fc3\5982g/6.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:49.281737', 0),
(788, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@cbacc0c41819@/\6797\5fc3\5982g/7.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:49.283831', 0),
(789, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@cbacc0c41819@/\6797\5fc3\5982g/13.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:49.291424', 0),
(790, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@cbacc0c41819@/\6797\5fc3\5982g/14.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:49.29654', 0),
(791, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@cbacc0c41819@/\6797\5fc3\5982g/15.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:49.29879', 0),
(792, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@cbacc0c41819@/\6797\5fc3\5982g/16.mkv', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:49.302946', 0),
(793, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@cbacc0c41819@/\6797\5fc3\5982g/18.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:49.305044', 0),
(794, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@cbacc0c41819@/\6797\5fc3\5982g/19.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:49.30741', 0),
(795, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@cbacc0c41819@/\6797\5fc3\5982g/20.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:49.31021', 0),
(796, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@cbacc0c41819@/\6797\5fc3\5982g/21.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 19:46:49.314266', 0),
(797, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@acdb7a629a8b@/S \65f6\5149\4ee3\7406\4eba/~playlist', NULL, NULL, 1, TIMESTAMP '2026-10-20 20:04:29.6033', 0);     
INSERT INTO "PUBLIC"."PLAY_URL" VALUES
(798, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@acdb7a629a8b@/S \65f6\5149\4ee3\7406\4eba/\7b2c\4e00\5b63/\756a\5916\7bc7 \6bd4\6b66\62db\4eb2.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 20:04:29.898613', 0),
(799, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@acdb7a629a8b@/S \65f6\5149\4ee3\7406\4eba/\7b2c\4e00\5b63/\7b2c1\8bdd EMMA.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 20:04:29.907258', 0),
(800, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@acdb7a629a8b@/S \65f6\5149\4ee3\7406\4eba/\7b2c\4e00\5b63/\7b2c2\8bdd \79d8\65b9.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 20:04:29.909441', 0),
(801, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@acdb7a629a8b@/S \65f6\5149\4ee3\7406\4eba/\7b2c\4e00\5b63/\7b2c3\8bdd \53ea\8bb8\8f93\ff0c\4e0d\51c6\8d62.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 20:04:29.913848', 0),
(802, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@acdb7a629a8b@/S \65f6\5149\4ee3\7406\4eba/\7b2c\4e00\5b63/\7b2c4\8bdd \544a\767d.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 20:04:29.915644', 0),
(803, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@acdb7a629a8b@/S \65f6\5149\4ee3\7406\4eba/\7b2c\4e00\5b63/\7b2c5\8bdd \544a\522b.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 20:04:29.917313', 0),
(804, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@acdb7a629a8b@/S \65f6\5149\4ee3\7406\4eba/\7b2c\4e00\5b63/\7b2c6\8bdd \5bfb\5b50.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 20:04:29.919548', 0),
(805, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@acdb7a629a8b@/S \65f6\5149\4ee3\7406\4eba/\7b2c\4e00\5b63/\7b2c7\8bdd \6885\59e8.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 20:04:29.921462', 0),
(806, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@acdb7a629a8b@/S \65f6\5149\4ee3\7406\4eba/\7b2c\4e00\5b63/\7b2c8\8bdd \9519\5931\7684\8baf\53f7.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 20:04:29.931633', 0),
(807, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@acdb7a629a8b@/S \65f6\5149\4ee3\7406\4eba/\7b2c\4e00\5b63/\7b2c9\8bdd \5584\610f\7684\6076\679c.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 20:04:29.933528', 0),
(808, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@acdb7a629a8b@/S \65f6\5149\4ee3\7406\4eba/\7b2c\4e00\5b63/\7b2c10\8bdd \5708\5957.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 20:04:29.935236', 0),
(809, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@acdb7a629a8b@/S \65f6\5149\4ee3\7406\4eba/\7b2c\4e00\5b63/\7b2c11\8bdd \5e26\7740\5149\7684\4eba.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 20:04:29.936932', 0),
(810, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@acdb7a629a8b@/S \65f6\5149\4ee3\7406\4eba/\7b2c\4e8c\5b63/\7b2c1\8bdd \5760\843d.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 20:04:30.194103', 0),
(811, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@acdb7a629a8b@/S \65f6\5149\4ee3\7406\4eba/\7b2c\4e8c\5b63/\7b2c2\8bdd \591c\88ad.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 20:04:30.196242', 0),
(812, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@acdb7a629a8b@/S \65f6\5149\4ee3\7406\4eba/\7b2c\4e8c\5b63/\7b2c3\8bdd \4e24\573a\846c\793c.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 20:04:30.198064', 0),
(813, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@acdb7a629a8b@/S \65f6\5149\4ee3\7406\4eba/\7b2c\4e8c\5b63/\7b2c4\8bdd \7167\7247\4e2d\7684\5979\4eec.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 20:04:30.19969', 0),
(814, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@acdb7a629a8b@/S \65f6\5149\4ee3\7406\4eba/\7b2c\4e8c\5b63/\7b2c5\8bdd \6700\540e\7684\665a\9910.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 20:04:30.203204', 0),
(815, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@acdb7a629a8b@/S \65f6\5149\4ee3\7406\4eba/\7b2c\4e8c\5b63/\7b2c6\8bdd \674e\5929\5e0c.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 20:04:30.216321', 0),
(816, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@acdb7a629a8b@/S \65f6\5149\4ee3\7406\4eba/\7b2c\4e8c\5b63/\7b2c7\8bdd \5df7\6218.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 20:04:30.218403', 0),
(817, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@acdb7a629a8b@/S \65f6\5149\4ee3\7406\4eba/\7b2c\4e8c\5b63/\7b2c8\8bdd \4eba\8d28.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 20:04:30.220326', 0);
INSERT INTO "PUBLIC"."PLAY_URL" VALUES
(818, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@acdb7a629a8b@/S \65f6\5149\4ee3\7406\4eba/\7b2c\4e8c\5b63/\7b2c9\8bdd \4e09\4e2a\6545\4e8b.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 20:04:30.222144', 0),
(819, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@acdb7a629a8b@/S \65f6\5149\4ee3\7406\4eba/\7b2c\4e8c\5b63/\7b2c10\8bdd \5373\5174\6f14\51fa.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 20:04:30.223892', 0),
(820, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@acdb7a629a8b@/S \65f6\5149\4ee3\7406\4eba/\7b2c\4e8c\5b63/\7b2c11\8bdd \5bf9\5cd9.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 20:04:30.225672', 0),
(821, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@acdb7a629a8b@/S \65f6\5149\4ee3\7406\4eba/\7b2c\4e8c\5b63/\7b2c12\8bdd \4e0d\80fd\6ca1\6709\597d\54e5\54e5.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 20:04:30.227621', 0),
(822, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@acdb7a629a8b@/S \65f6\5149\4ee3\7406\4eba/\7b2c\4e09\5b63/\7b2c1\8bdd \9057\5fd8\7684\8fc7\53bb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 20:04:31.012518', 0),
(823, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@acdb7a629a8b@/S \65f6\5149\4ee3\7406\4eba/\7b2c\4e09\5b63/\7b2c2\8bdd \56f0\517d.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 20:04:31.023519', 0),
(824, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@acdb7a629a8b@/S \65f6\5149\4ee3\7406\4eba/\7b2c\4e09\5b63/\7b2c3\8bdd \8840\6d17\7f05\631d.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 20:04:31.033196', 0),
(825, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@acdb7a629a8b@/S \65f6\5149\4ee3\7406\4eba/\7b2c\4e09\5b63/\7b2c4\8bdd JAE.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 20:04:31.045153', 0),
(826, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@acdb7a629a8b@/S \65f6\5149\4ee3\7406\4eba/\7b2c\4e09\5b63/\7b2c5\8bdd \63a5\98ce\5bb4.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 20:04:31.047382', 0),
(827, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@acdb7a629a8b@/S \65f6\5149\4ee3\7406\4eba/\7b2c\4e09\5b63/\7b2c6\8bdd \8bd5\63a2.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 20:04:31.049034', 0),
(828, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@acdb7a629a8b@/S \65f6\5149\4ee3\7406\4eba/\7b2c\4e09\5b63/\7b2c7\8bdd \5510\4eba\8857\63a2\6848.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 20:04:31.068989', 0),
(829, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@acdb7a629a8b@/S \65f6\5149\4ee3\7406\4eba/\7b2c\4e09\5b63/H265 HDR/\7b2c1\8bdd \9057\5fd8\7684\8fc7\53bb.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 20:04:31.215685', 0),
(830, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@acdb7a629a8b@/S \65f6\5149\4ee3\7406\4eba/\7b2c\4e09\5b63/H265 HDR/\7b2c2\8bdd \56f0\517d.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 20:04:31.218131', 0),
(831, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@acdb7a629a8b@/S \65f6\5149\4ee3\7406\4eba/\7b2c\4e09\5b63/H265 HDR/\7b2c3\8bdd \8840\6d17\7f05\631d.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 20:04:31.219846', 0),
(832, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@acdb7a629a8b@/S \65f6\5149\4ee3\7406\4eba/\7b2c\4e09\5b63/H265 HDR/\7b2c4\8bdd JAE.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 20:04:31.226879', 0),
(833, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@acdb7a629a8b@/S \65f6\5149\4ee3\7406\4eba/\7b2c\4e09\5b63/H265 HDR/\7b2c5\8bdd \63a5\98ce\5bb4.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 20:04:31.229186', 0),
(834, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@acdb7a629a8b@/S \65f6\5149\4ee3\7406\4eba/\7b2c\4e09\5b63/H265 HDR/\7b2c6\8bdd \8bd5\63a2.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 20:04:31.231773', 0),
(835, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@acdb7a629a8b@/S \65f6\5149\4ee3\7406\4eba/\82f1\90fd\7bc7/\7b2c1\8bdd \4e8e\662f\65f6\95f4\518d\6b21\5f00\59cb\6d41\8f6c.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 20:04:31.355718', 0),
(836, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@acdb7a629a8b@/S \65f6\5149\4ee3\7406\4eba/\82f1\90fd\7bc7/\7b2c2\8bdd \5e8f\5e55.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 20:04:31.357474', 0),
(837, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@acdb7a629a8b@/S \65f6\5149\4ee3\7406\4eba/\82f1\90fd\7bc7/\7b2c3\8bdd \4ed6\4eec.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 20:04:31.359013', 0);      
INSERT INTO "PUBLIC"."PLAY_URL" VALUES
(838, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@acdb7a629a8b@/S \65f6\5149\4ee3\7406\4eba/\82f1\90fd\7bc7/\7b2c4\8bdd And Then There Were None.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 20:04:31.36105', 0),
(839, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@acdb7a629a8b@/S \65f6\5149\4ee3\7406\4eba/\82f1\90fd\7bc7/\7b2c5\8bdd \91cd\9022.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 20:04:31.363182', 0),
(840, U&'/\6211\7684\5938\514b\5206\4eab/temp/quark@acdb7a629a8b@/S \65f6\5149\4ee3\7406\4eba/\82f1\90fd\7bc7/\7b2c6\8bdd \8ff7\5c40.mp4', NULL, NULL, 1, TIMESTAMP '2026-09-27 20:04:31.365254', 0),
(841, 'https://al.flv.huya.com/huyalive/9999991199561506980-1199561506980-5435845454610825216-2399123137416-10057-A-0-11789900379.flv?ratio=&cdn=AL&name=9999991199561506980-1199561506980-5435845454610825216-2399123137416-10057-A-0-11789900379&uid=1199561506980', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:12:59.496099', 0),
(842, 'https://al.flv.huya.com/huyalive/9999991199561506980-1199561506980-5435845454610825216-2399123137416-10057-A-0-11789900379.flv?ratio=2000&cdn=AL&name=9999991199561506980-1199561506980-5435845454610825216-2399123137416-10057-A-0-11789900379&uid=1199561506980', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:12:59.498031', 0),
(843, 'https://al.flv.huya.com/huyalive/9999991199561506980-1199561506980-5435845454610825216-2399123137416-10057-A-0-11789900379.flv?ratio=500&cdn=AL&name=9999991199561506980-1199561506980-5435845454610825216-2399123137416-10057-A-0-11789900379&uid=1199561506980', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:12:59.516828', 0),
(844, 'https://tx.flv.huya.com/src/9999991199561506980-1199561506980-5435845454610825216-2399123137416-10057-A-0-11789900379.flv?ratio=&cdn=TX&name=9999991199561506980-1199561506980-5435845454610825216-2399123137416-10057-A-0-11789900379&uid=1199561506980', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:12:59.518862', 0),
(845, 'https://tx.flv.huya.com/src/9999991199561506980-1199561506980-5435845454610825216-2399123137416-10057-A-0-11789900379.flv?ratio=2000&cdn=TX&name=9999991199561506980-1199561506980-5435845454610825216-2399123137416-10057-A-0-11789900379&uid=1199561506980', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:12:59.529483', 0),
(846, 'https://tx.flv.huya.com/src/9999991199561506980-1199561506980-5435845454610825216-2399123137416-10057-A-0-11789900379.flv?ratio=500&cdn=TX&name=9999991199561506980-1199561506980-5435845454610825216-2399123137416-10057-A-0-11789900379&uid=1199561506980', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:12:59.531283', 0),
(847, 'https://hs.flv.huya.com/src/9999991199561506980-1199561506980-5435845454610825216-2399123137416-10057-A-0-11789900379.flv?ratio=&cdn=HS&name=9999991199561506980-1199561506980-5435845454610825216-2399123137416-10057-A-0-11789900379&uid=1199561506980', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:12:59.533175', 0),
(848, 'https://hs.flv.huya.com/src/9999991199561506980-1199561506980-5435845454610825216-2399123137416-10057-A-0-11789900379.flv?ratio=2000&cdn=HS&name=9999991199561506980-1199561506980-5435845454610825216-2399123137416-10057-A-0-11789900379&uid=1199561506980', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:12:59.534678', 0),
(849, 'https://hs.flv.huya.com/src/9999991199561506980-1199561506980-5435845454610825216-2399123137416-10057-A-0-11789900379.flv?ratio=500&cdn=HS&name=9999991199561506980-1199561506980-5435845454610825216-2399123137416-10057-A-0-11789900379&uid=1199561506980', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:12:59.536213', 0),
(850, 'https://al.flv.huya.com/src/1199632087111-1199632087111-5738984809003220992-2399264297678-10057-A-0-1.flv?ratio=&cdn=AL&name=1199632087111-1199632087111-5738984809003220992-2399264297678-10057-A-0-1&uid=1199632087111', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:04.032034', 0),
(851, 'https://al.flv.huya.com/src/1199632087111-1199632087111-5738984809003220992-2399264297678-10057-A-0-1.flv?ratio=4000&cdn=AL&name=1199632087111-1199632087111-5738984809003220992-2399264297678-10057-A-0-1&uid=1199632087111', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:04.033876', 0);   
INSERT INTO "PUBLIC"."PLAY_URL" VALUES
(852, 'https://al.flv.huya.com/src/1199632087111-1199632087111-5738984809003220992-2399264297678-10057-A-0-1.flv?ratio=2000&cdn=AL&name=1199632087111-1199632087111-5738984809003220992-2399264297678-10057-A-0-1&uid=1199632087111', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:04.035554', 0),
(853, 'https://al.flv.huya.com/src/1199632087111-1199632087111-5738984809003220992-2399264297678-10057-A-0-1.flv?ratio=500&cdn=AL&name=1199632087111-1199632087111-5738984809003220992-2399264297678-10057-A-0-1&uid=1199632087111', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:04.051741', 0),
(854, 'https://tx.flv.huya.com/src/1199632087111-1199632087111-5738984809003220992-2399264297678-10057-A-0-1.flv?ratio=&cdn=TX&name=1199632087111-1199632087111-5738984809003220992-2399264297678-10057-A-0-1&uid=1199632087111', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:04.053712', 0),
(855, 'https://tx.flv.huya.com/src/1199632087111-1199632087111-5738984809003220992-2399264297678-10057-A-0-1.flv?ratio=4000&cdn=TX&name=1199632087111-1199632087111-5738984809003220992-2399264297678-10057-A-0-1&uid=1199632087111', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:04.055462', 0),
(856, 'https://tx.flv.huya.com/src/1199632087111-1199632087111-5738984809003220992-2399264297678-10057-A-0-1.flv?ratio=2000&cdn=TX&name=1199632087111-1199632087111-5738984809003220992-2399264297678-10057-A-0-1&uid=1199632087111', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:04.057132', 0),
(857, 'https://tx.flv.huya.com/src/1199632087111-1199632087111-5738984809003220992-2399264297678-10057-A-0-1.flv?ratio=500&cdn=TX&name=1199632087111-1199632087111-5738984809003220992-2399264297678-10057-A-0-1&uid=1199632087111', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:04.059142', 0),
(858, 'https://hs.flv.huya.com/huyalive/1199632087111-1199632087111-5738984809003220992-2399264297678-10057-A-0-1.flv?ratio=&cdn=HS&name=1199632087111-1199632087111-5738984809003220992-2399264297678-10057-A-0-1&uid=1199632087111', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:04.089307', 0),
(859, 'https://hs.flv.huya.com/huyalive/1199632087111-1199632087111-5738984809003220992-2399264297678-10057-A-0-1.flv?ratio=4000&cdn=HS&name=1199632087111-1199632087111-5738984809003220992-2399264297678-10057-A-0-1&uid=1199632087111', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:04.093034', 0),
(860, 'https://hs.flv.huya.com/huyalive/1199632087111-1199632087111-5738984809003220992-2399264297678-10057-A-0-1.flv?ratio=2000&cdn=HS&name=1199632087111-1199632087111-5738984809003220992-2399264297678-10057-A-0-1&uid=1199632087111', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:04.095488', 0),
(861, 'https://hs.flv.huya.com/huyalive/1199632087111-1199632087111-5738984809003220992-2399264297678-10057-A-0-1.flv?ratio=500&cdn=HS&name=1199632087111-1199632087111-5738984809003220992-2399264297678-10057-A-0-1&uid=1199632087111', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:04.09714', 0),
(862, 'https://al.flv.huya.com/huyalive/999999600834796-600834796-2580565799118831616-1201793048-10057-A-0-11789898429.flv?ratio=&cdn=AL&name=999999600834796-600834796-2580565799118831616-1201793048-10057-A-0-11789898429&uid=600834796', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:11.124315', 0),
(863, 'https://al.flv.huya.com/huyalive/999999600834796-600834796-2580565799118831616-1201793048-10057-A-0-11789898429.flv?ratio=500&cdn=AL&name=999999600834796-600834796-2580565799118831616-1201793048-10057-A-0-11789898429&uid=600834796', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:11.126091', 0),
(864, 'https://tx.flv.huya.com/src/999999600834796-600834796-2580565799118831616-1201793048-10057-A-0-11789898429.flv?ratio=&cdn=TX&name=999999600834796-600834796-2580565799118831616-1201793048-10057-A-0-11789898429&uid=600834796', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:11.128332', 0),
(865, 'https://tx.flv.huya.com/src/999999600834796-600834796-2580565799118831616-1201793048-10057-A-0-11789898429.flv?ratio=500&cdn=TX&name=999999600834796-600834796-2580565799118831616-1201793048-10057-A-0-11789898429&uid=600834796', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:11.129957', 0);           
INSERT INTO "PUBLIC"."PLAY_URL" VALUES
(866, 'https://hs.flv.huya.com/src/999999600834796-600834796-2580565799118831616-1201793048-10057-A-0-11789898429.flv?ratio=&cdn=HS&name=999999600834796-600834796-2580565799118831616-1201793048-10057-A-0-11789898429&uid=600834796', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:11.131462', 0),
(867, 'https://hs.flv.huya.com/src/999999600834796-600834796-2580565799118831616-1201793048-10057-A-0-11789898429.flv?ratio=500&cdn=HS&name=999999600834796-600834796-2580565799118831616-1201793048-10057-A-0-11789898429&uid=600834796', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:11.132932', 0),
(868, 'https://al.flv.huya.com/src/1677942375-1677942375-7206707625197568000-3356008206-10057-A-0-1-imgplus.flv?ratio=&cdn=AL&name=1677942375-1677942375-7206707625197568000-3356008206-10057-A-0-1-imgplus&uid=1677942375', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:16.673445', 0),
(869, 'https://al.flv.huya.com/src/1677942375-1677942375-7206707625197568000-3356008206-10057-A-0-1-imgplus.flv?ratio=500&cdn=AL&name=1677942375-1677942375-7206707625197568000-3356008206-10057-A-0-1-imgplus&uid=1677942375', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:16.681907', 0),
(870, 'https://tx.flv.huya.com/src/1677942375-1677942375-7206707625197568000-3356008206-10057-A-0-1-imgplus.flv?ratio=&cdn=TX&name=1677942375-1677942375-7206707625197568000-3356008206-10057-A-0-1-imgplus&uid=1677942375', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:16.683556', 0),
(871, 'https://tx.flv.huya.com/src/1677942375-1677942375-7206707625197568000-3356008206-10057-A-0-1-imgplus.flv?ratio=500&cdn=TX&name=1677942375-1677942375-7206707625197568000-3356008206-10057-A-0-1-imgplus&uid=1677942375', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:16.685803', 0),
(872, 'https://hs.flv.huya.com/src/1677942375-1677942375-7206707625197568000-3356008206-10057-A-0-1-imgplus.flv?ratio=&cdn=HS&name=1677942375-1677942375-7206707625197568000-3356008206-10057-A-0-1-imgplus&uid=1677942375', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:16.687428', 0),
(873, 'https://hs.flv.huya.com/src/1677942375-1677942375-7206707625197568000-3356008206-10057-A-0-1-imgplus.flv?ratio=500&cdn=HS&name=1677942375-1677942375-7206707625197568000-3356008206-10057-A-0-1-imgplus&uid=1677942375', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:16.688823', 0),
(874, 'https://al.flv.huya.com/huyalive/999999631787729-631787729-2713507634069110784-1263698914-10057-A-0-11789893213.flv?ratio=&cdn=AL&name=999999631787729-631787729-2713507634069110784-1263698914-10057-A-0-11789893213&uid=631787729', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:19.958117', 0),
(875, 'https://al.flv.huya.com/huyalive/999999631787729-631787729-2713507634069110784-1263698914-10057-A-0-11789893213.flv?ratio=500&cdn=AL&name=999999631787729-631787729-2713507634069110784-1263698914-10057-A-0-11789893213&uid=631787729', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:19.959802', 0),
(876, 'https://tx.flv.huya.com/src/999999631787729-631787729-2713507634069110784-1263698914-10057-A-0-11789893213.flv?ratio=&cdn=TX&name=999999631787729-631787729-2713507634069110784-1263698914-10057-A-0-11789893213&uid=631787729', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:19.969367', 0),
(877, 'https://tx.flv.huya.com/src/999999631787729-631787729-2713507634069110784-1263698914-10057-A-0-11789893213.flv?ratio=500&cdn=TX&name=999999631787729-631787729-2713507634069110784-1263698914-10057-A-0-11789893213&uid=631787729', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:19.97124', 0),
(878, 'https://hs.flv.huya.com/src/999999631787729-631787729-2713507634069110784-1263698914-10057-A-0-11789893213.flv?ratio=&cdn=HS&name=999999631787729-631787729-2713507634069110784-1263698914-10057-A-0-11789893213&uid=631787729', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:19.972863', 0),
(879, 'https://hs.flv.huya.com/src/999999631787729-631787729-2713507634069110784-1263698914-10057-A-0-11789893213.flv?ratio=500&cdn=HS&name=999999631787729-631787729-2713507634069110784-1263698914-10057-A-0-11789893213&uid=631787729', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:19.974345', 0),
(880, 'https://al.flv.huya.com/src/2203107383-2203107383-9462274159561146368-4406338222-10057-A-0-1.flv?ratio=&cdn=AL&name=2203107383-2203107383-9462274159561146368-4406338222-10057-A-0-1&uid=2203107383', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:23.704301', 0);           
INSERT INTO "PUBLIC"."PLAY_URL" VALUES
(881, 'https://txdirect.flv.huya.com/huyalive/2203107383-2203107383-9462274159561146368-4406338222-10057-A-0-1.flv?ratio=&cdn=TX&name=2203107383-2203107383-9462274159561146368-4406338222-10057-A-0-1&uid=2203107383', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:23.706747', 0),
(882, 'https://hs.flv.huya.com/src/2203107383-2203107383-9462274159561146368-4406338222-10057-A-0-1.flv?ratio=&cdn=HS&name=2203107383-2203107383-9462274159561146368-4406338222-10057-A-0-1&uid=2203107383', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:23.711272', 0),
(883, 'https://al.flv.huya.com/src/1199613311154-1199613311154-5658342687737118720-2399226745764-10057-A-0-1-imgplus.flv?ratio=&cdn=AL&name=1199613311154-1199613311154-5658342687737118720-2399226745764-10057-A-0-1-imgplus&uid=1199613311154', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:28.1118', 0),
(884, 'https://al.flv.huya.com/src/1199613311154-1199613311154-5658342687737118720-2399226745764-10057-A-0-1-imgplus.flv?ratio=4000&cdn=AL&name=1199613311154-1199613311154-5658342687737118720-2399226745764-10057-A-0-1-imgplus&uid=1199613311154', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:28.113631', 0),
(885, 'https://al.flv.huya.com/src/1199613311154-1199613311154-5658342687737118720-2399226745764-10057-A-0-1-imgplus.flv?ratio=2000&cdn=AL&name=1199613311154-1199613311154-5658342687737118720-2399226745764-10057-A-0-1-imgplus&uid=1199613311154', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:28.115155', 0),
(886, 'https://al.flv.huya.com/src/1199613311154-1199613311154-5658342687737118720-2399226745764-10057-A-0-1-imgplus.flv?ratio=500&cdn=AL&name=1199613311154-1199613311154-5658342687737118720-2399226745764-10057-A-0-1-imgplus&uid=1199613311154', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:28.116559', 0),
(887, 'https://tx.flv.huya.com/src/1199613311154-1199613311154-5658342687737118720-2399226745764-10057-A-0-1-imgplus.flv?ratio=&cdn=TX&name=1199613311154-1199613311154-5658342687737118720-2399226745764-10057-A-0-1-imgplus&uid=1199613311154', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:28.118571', 0),
(888, 'https://tx.flv.huya.com/src/1199613311154-1199613311154-5658342687737118720-2399226745764-10057-A-0-1-imgplus.flv?ratio=4000&cdn=TX&name=1199613311154-1199613311154-5658342687737118720-2399226745764-10057-A-0-1-imgplus&uid=1199613311154', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:28.120974', 0),
(889, 'https://tx.flv.huya.com/src/1199613311154-1199613311154-5658342687737118720-2399226745764-10057-A-0-1-imgplus.flv?ratio=2000&cdn=TX&name=1199613311154-1199613311154-5658342687737118720-2399226745764-10057-A-0-1-imgplus&uid=1199613311154', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:28.122748', 0),
(890, 'https://tx.flv.huya.com/src/1199613311154-1199613311154-5658342687737118720-2399226745764-10057-A-0-1-imgplus.flv?ratio=500&cdn=TX&name=1199613311154-1199613311154-5658342687737118720-2399226745764-10057-A-0-1-imgplus&uid=1199613311154', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:28.124132', 0),
(891, 'https://hs.flv.huya.com/src/1199613311154-1199613311154-5658342687737118720-2399226745764-10057-A-0-1-imgplus.flv?ratio=&cdn=HS&name=1199613311154-1199613311154-5658342687737118720-2399226745764-10057-A-0-1-imgplus&uid=1199613311154', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:28.125744', 0),
(892, 'https://hs.flv.huya.com/src/1199613311154-1199613311154-5658342687737118720-2399226745764-10057-A-0-1-imgplus.flv?ratio=4000&cdn=HS&name=1199613311154-1199613311154-5658342687737118720-2399226745764-10057-A-0-1-imgplus&uid=1199613311154', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:28.127225', 0),
(893, 'https://hs.flv.huya.com/src/1199613311154-1199613311154-5658342687737118720-2399226745764-10057-A-0-1-imgplus.flv?ratio=2000&cdn=HS&name=1199613311154-1199613311154-5658342687737118720-2399226745764-10057-A-0-1-imgplus&uid=1199613311154', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:28.128626', 0),
(894, 'https://hs.flv.huya.com/src/1199613311154-1199613311154-5658342687737118720-2399226745764-10057-A-0-1-imgplus.flv?ratio=500&cdn=HS&name=1199613311154-1199613311154-5658342687737118720-2399226745764-10057-A-0-1-imgplus&uid=1199613311154', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:28.130426', 0);   
INSERT INTO "PUBLIC"."PLAY_URL" VALUES
(895, 'https://al.flv.huya.com/huyalive/9999991259524971388-1259524971388-4722547009897103360-2519050066232-10057-A-0-11789900766.flv?ratio=&cdn=AL&name=9999991259524971388-1259524971388-4722547009897103360-2519050066232-10057-A-0-11789900766&uid=1259524971388', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:35.740516', 0),
(896, 'https://tx.flv.huya.com/src/9999991259524971388-1259524971388-4722547009897103360-2519050066232-10057-A-0-11789900766.flv?ratio=&cdn=TX&name=9999991259524971388-1259524971388-4722547009897103360-2519050066232-10057-A-0-11789900766&uid=1259524971388', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:35.742327', 0),
(897, 'https://hs.flv.huya.com/src/9999991259524971388-1259524971388-4722547009897103360-2519050066232-10057-A-0-11789900766.flv?ratio=&cdn=HS&name=9999991259524971388-1259524971388-4722547009897103360-2519050066232-10057-A-0-11789900766&uid=1259524971388', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:35.74391', 0),
(898, 'https://al.flv.huya.com/src/1199665096295-1199665096295-5880758174750867456-2399330316046-10057-A-0-1.flv?ratio=&cdn=AL&name=1199665096295-1199665096295-5880758174750867456-2399330316046-10057-A-0-1&uid=1199665096295', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:39.114646', 0),
(899, 'https://al.flv.huya.com/src/1199665096295-1199665096295-5880758174750867456-2399330316046-10057-A-0-1.flv?ratio=500&cdn=AL&name=1199665096295-1199665096295-5880758174750867456-2399330316046-10057-A-0-1&uid=1199665096295', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:39.121779', 0),
(900, 'https://tx.flv.huya.com/src/1199665096295-1199665096295-5880758174750867456-2399330316046-10057-A-0-1.flv?ratio=&cdn=TX&name=1199665096295-1199665096295-5880758174750867456-2399330316046-10057-A-0-1&uid=1199665096295', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:39.123931', 0),
(901, 'https://tx.flv.huya.com/src/1199665096295-1199665096295-5880758174750867456-2399330316046-10057-A-0-1.flv?ratio=500&cdn=TX&name=1199665096295-1199665096295-5880758174750867456-2399330316046-10057-A-0-1&uid=1199665096295', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:39.127395', 0),
(902, 'https://hs.flv.huya.com/src/1199665096295-1199665096295-5880758174750867456-2399330316046-10057-A-0-1.flv?ratio=&cdn=HS&name=1199665096295-1199665096295-5880758174750867456-2399330316046-10057-A-0-1&uid=1199665096295', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:39.129229', 0),
(903, 'https://hs.flv.huya.com/src/1199665096295-1199665096295-5880758174750867456-2399330316046-10057-A-0-1.flv?ratio=500&cdn=HS&name=1199665096295-1199665096295-5880758174750867456-2399330316046-10057-A-0-1&uid=1199665096295', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:13:39.134069', 0),
(904, 'https://al.flv.huya.com/src/1199630267421-1199630267421-5731169299964362752-2399260658298-10057-A-0-1.flv?ratio=&cdn=AL&name=1199630267421-1199630267421-5731169299964362752-2399260658298-10057-A-0-1&uid=1199630267421', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:15:37.938707', 0),
(905, 'https://al.flv.huya.com/src/1199630267421-1199630267421-5731169299964362752-2399260658298-10057-A-0-1.flv?ratio=4000&cdn=AL&name=1199630267421-1199630267421-5731169299964362752-2399260658298-10057-A-0-1&uid=1199630267421', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:15:37.946014', 0),
(906, 'https://al.flv.huya.com/src/1199630267421-1199630267421-5731169299964362752-2399260658298-10057-A-0-1.flv?ratio=2000&cdn=AL&name=1199630267421-1199630267421-5731169299964362752-2399260658298-10057-A-0-1&uid=1199630267421', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:15:37.94781', 0),
(907, 'https://al.flv.huya.com/src/1199630267421-1199630267421-5731169299964362752-2399260658298-10057-A-0-1.flv?ratio=500&cdn=AL&name=1199630267421-1199630267421-5731169299964362752-2399260658298-10057-A-0-1&uid=1199630267421', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:15:37.961226', 0),
(908, 'https://tx.flv.huya.com/src/1199630267421-1199630267421-5731169299964362752-2399260658298-10057-A-0-1.flv?ratio=&cdn=TX&name=1199630267421-1199630267421-5731169299964362752-2399260658298-10057-A-0-1&uid=1199630267421', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:15:37.963229', 0);            
INSERT INTO "PUBLIC"."PLAY_URL" VALUES
(909, 'https://tx.flv.huya.com/src/1199630267421-1199630267421-5731169299964362752-2399260658298-10057-A-0-1.flv?ratio=4000&cdn=TX&name=1199630267421-1199630267421-5731169299964362752-2399260658298-10057-A-0-1&uid=1199630267421', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:15:37.96502', 0),
(910, 'https://tx.flv.huya.com/src/1199630267421-1199630267421-5731169299964362752-2399260658298-10057-A-0-1.flv?ratio=2000&cdn=TX&name=1199630267421-1199630267421-5731169299964362752-2399260658298-10057-A-0-1&uid=1199630267421', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:15:37.966774', 0),
(911, 'https://tx.flv.huya.com/src/1199630267421-1199630267421-5731169299964362752-2399260658298-10057-A-0-1.flv?ratio=500&cdn=TX&name=1199630267421-1199630267421-5731169299964362752-2399260658298-10057-A-0-1&uid=1199630267421', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:15:37.968504', 0),
(912, 'https://hs.flv.huya.com/huyalive/1199630267421-1199630267421-5731169299964362752-2399260658298-10057-A-0-1.flv?ratio=&cdn=HS&name=1199630267421-1199630267421-5731169299964362752-2399260658298-10057-A-0-1&uid=1199630267421', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:15:37.980722', 0),
(913, 'https://hs.flv.huya.com/huyalive/1199630267421-1199630267421-5731169299964362752-2399260658298-10057-A-0-1.flv?ratio=4000&cdn=HS&name=1199630267421-1199630267421-5731169299964362752-2399260658298-10057-A-0-1&uid=1199630267421', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:15:37.982515', 0),
(914, 'https://hs.flv.huya.com/huyalive/1199630267421-1199630267421-5731169299964362752-2399260658298-10057-A-0-1.flv?ratio=2000&cdn=HS&name=1199630267421-1199630267421-5731169299964362752-2399260658298-10057-A-0-1&uid=1199630267421', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:15:37.98402', 0),
(915, 'https://hs.flv.huya.com/huyalive/1199630267421-1199630267421-5731169299964362752-2399260658298-10057-A-0-1.flv?ratio=500&cdn=HS&name=1199630267421-1199630267421-5731169299964362752-2399260658298-10057-A-0-1&uid=1199630267421', NULL, NULL, 0, TIMESTAMP '2026-09-21 20:15:38.000477', 0);      
CREATE CACHED TABLE "PUBLIC"."MSUB_EPISODE_FALLBACK"(
    "ID" INTEGER NOT NULL,
    "SUBSCRIPTION_ID" INTEGER NOT NULL,
    "EPISODE" INTEGER NOT NULL,
    "SITE_ID" CHARACTER VARYING(16) NOT NULL,
    "RESOURCE_ID" CHARACTER VARYING(64) NOT NULL,
    "LINE" CHARACTER VARYING(128),
    "TITLE" CHARACTER VARYING(255),
    "URL" CHARACTER VARYING(1024),
    "STATE" CHARACTER VARYING(16) DEFAULT 'ACTIVE' NOT NULL,
    "VALIDATED_AT" BIGINT,
    "EXPIRES_AT" BIGINT
);          
ALTER TABLE "PUBLIC"."MSUB_EPISODE_FALLBACK" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_8D1" PRIMARY KEY("ID");       
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.MSUB_EPISODE_FALLBACK;    
CREATE INDEX "PUBLIC"."IDX_MSUB_EF_SUB" ON "PUBLIC"."MSUB_EPISODE_FALLBACK"("SUBSCRIPTION_ID" NULLS FIRST);    
CREATE CACHED TABLE "PUBLIC"."OFFLINE_DOWNLOAD_TASK"(
    "ID" INTEGER NOT NULL,
    "ACCOUNT_ID" INTEGER,
    "CREATED_TIME" TIMESTAMP,
    "FOLDER" BOOLEAN DEFAULT FALSE,
    "INFO_HASH" CHARACTER VARYING(255),
    "STATUS" CHARACTER VARYING(255),
    "TARGET_PATH" CHARACTER VARYING,
    "TASK_NAME" CHARACTER VARYING(255),
    "UPDATED_TIME" TIMESTAMP,
    "URL_HASH" CHARACTER VARYING(64) NOT NULL,
    "SUBSCRIPTION_ID" INTEGER,
    "EPISODE" INTEGER,
    "CLEANUP_STATE" CHARACTER VARYING(16),
    "CLEANUP_ATTEMPTS" INTEGER,
    "CLEANUP_TIME" TIMESTAMP,
    "COMPLETED_TIME" TIMESTAMP,
    "SHARE_URL" CHARACTER VARYING(500)
);   
ALTER TABLE "PUBLIC"."OFFLINE_DOWNLOAD_TASK" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_5" PRIMARY KEY("ID");         
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.OFFLINE_DOWNLOAD_TASK;    
CREATE CACHED TABLE "PUBLIC"."DRIVER_ACCOUNT"(
    "ID" INTEGER NOT NULL,
    "ADDITION" CHARACTER VARYING,
    "CONCURRENCY" INTEGER,
    "COOKIE" CHARACTER VARYING,
    "DISABLED" BOOLEAN DEFAULT FALSE,
    "FOLDER" CHARACTER VARYING(255),
    "MASTER" BOOLEAN NOT NULL,
    "NAME" CHARACTER VARYING(255),
    "PASSWORD" CHARACTER VARYING(255),
    "SAFE_PASSWORD" CHARACTER VARYING(255),
    "TOKEN" CHARACTER VARYING,
    "TYPE" SMALLINT,
    "USE_PROXY" BOOLEAN DEFAULT FALSE,
    "USERNAME" CHARACTER VARYING(255),
    "OWNER_UID" INTEGER DEFAULT 0 NOT NULL,
    "SHARED" BOOLEAN DEFAULT TRUE NOT NULL
);             
ALTER TABLE "PUBLIC"."DRIVER_ACCOUNT" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_6" PRIMARY KEY("ID");
-- 9 +/- SELECT COUNT(*) FROM PUBLIC.DRIVER_ACCOUNT;           
INSERT INTO "PUBLIC"."DRIVER_ACCOUNT" VALUES
(1, '{"chunk_size":256,"page_size":1000,"limit_rate":2,"access_token":"","refresh_token":"","device_id":"","delete_code":"","cloud_id":"","link_method":"download","type":"personal_new","auto_checkin":false}', 2, 'ctoken=LtruqCOiS9jtICl7y42_qzk8; __pus=0d543a9813df1f77589eeeaa511eb98aAAQBT2UMvGULcSgK5I8lEZ/9J9fR8Sk9BApQKoZC7RuK0VFM5F89zIlPESzCx3kHMzud+xMl8tYwiPi3zstvAMq3; __kp=329f6470-b40c-11f1-b975-f13eeb4132bb; __kps=AATCvnkKo1dOsxwwbCb7Bd9M; __ktd=ZbNr3CURv43fCz4cx6cTDg==; __uid=AATCvnkKo1dOsxwwbCb7Bd9M; __puus=04d57046cad129565442b54e56a478ffAAQMB3J4IvEU+7WVfyDC61uPbz8jfl6gtnSQc9Tl5FT2gejVNvN4e6oIergOAwHj7j1sYSDpfSXOALCbA6ekxRhGlGrBaXSVmsg6MUD0ZBN99hYswfjUwIB0qO+N4+g2ogkwzFXPnS80vlFYLWuhXc3K/cO8m1aD+SHliS+4d7nQuVO81Z8opwI4+J8/DHTQhpK29WheDb7rJH5o4laVC5+R', FALSE, '0', TRUE, U&'\5938\514b\7f51\76d8', '', '', '', 0, FALSE, '', 0, TRUE),
(2, '{"chunk_size":256,"page_size":1000,"limit_rate":2,"access_token":"","refresh_token":"","device_id":"","delete_code":"","cloud_id":"","link_method":"download","type":"personal_new","auto_checkin":false}', 2, 'ctoken=_rqFsNvgxBfjYj4v-KhaO_vl; __pus=b2118d52b99208844ab612fc8e5d946dAARkk0aQqFWF8KVr68/CPoVvxc6JWv8QOh3uUi1aR2KnhBRunuYJDIpH3obcJKikzCBFwSUWWE2FYFAQTYwRb1Lu; __kp=a10654f0-b40c-11f1-8327-3930bfe34f50; __kps=AAQ7/BnmQR0PmZ9jQrVet9Sm; __ktd=CkStgY9Jr5PpjjD/PHAQSA==; __uid=AAQ7/BnmQR0PmZ9jQrVet9Sm; UDRIVE_TRANSFER_SESS=UqKsYAGi0gabFLXZc8yW-UTsNFRGHEaq-N0NkOORGhZiVMRDy8NdAnmp5dyDiEVqj-lmIXOjnpHy8eVhUxvTJ5nwQ18Bzd7C5yVTVwEK0BZKgvBlwwYwIIJCdPr8UHxVxX4C-gQJQ5umZVcX0GoaFHwNbNmQrSWxQWy6Uadf0F8UbYyMzGp3ZN3-AzQNnVjt; __puus=551267aa921b379c0e6c9c96ef20fc19AARyadpjYGpda0jZdHOn61c1N7UQ24dW6yGbUKEjcFptp6KxgxgEPepiqT0aCllEDZVxCfW6/F8MjA9uqe0r01FvUgoz699O1Q0HkU1r5gmqwEp8mFjW4CJ7CRLqR09yxbiDyPrtHVSehTMRo7njw9PawHLClZ/VhiPmkTf+SYHaNoVjGBTuvEA/QMjeOXXD59g=', FALSE, '0', TRUE, U&'UC\7f51\76d8', '', '', '', 1, FALSE, '', 0, TRUE),
(3, '{"chunk_size":256,"page_size":1000,"limit_rate":2,"access_token":"","refresh_token":"","device_id":"","delete_code":"","cloud_id":"","link_method":"streaming","type":"personal_new","auto_checkin":false}', 2, 'ctoken=kWMP9i16IkkG8INNxx7nrROt; __pus=a7f8bafe6aa6ed1a22ae77b06ac603cbAATgBNsuv8wW/rfYMp5M7XnaipIkhOCur30ougbxPoMGUW5Ur05P0ve1k0euMCdfXo2UqKfC8UP56xSJ7Avc6wwt; __kp=b51fe690-b40c-11f1-a95b-c3cda7b9f4fa; __kps=AATCvnkKo1dOsxwwbCb7Bd9M; __ktd=ZbNr3CURv43fCz4cx6cTDg==; __uid=AATCvnkKo1dOsxwwbCb7Bd9M; __puus=6279aef1f223b3b2d8dc8f6f769c868eAAQMB3J4IvEU+7WVfyDC61uPkrPGA8K4QOe2dvvObBGaA/WLv4tr/yaTtxQGz40klvK9X3mp71Qzj71V4nER+Clo2ncvJ/UEXxqmnRtgIczCDhgpcbjI8tGqDVhYz8aOEQV1naIBQTFZB8ZidlegZ3WuO+mQOeXsn9kMqy1KlHOX8RUHLOMj/ExMVP7czruUt/cssNTQmraFP2G7zIKrdaN1', FALSE, '0', TRUE, U&'\5938\514bTV', '', '', 'eyJhbGciOiJIUzI1NiIsIlR5cGUiOiJKd3QiLCJ0eXAiOiJKV1QifQ.eyJvcGVuSWQiOiI3MDFjMGJmNWI0NDU0NTk0ODUwNmNhNTA2ZDI0NDFhZCIsImV4cCI6MTgyMTM0NjIyNCwidG9rZW4iOiJjM2QxNGI4MmJhNWM0N2YzYmY3NGFiNjMzNTdiZjAxMCJ9.WUg3jUZihff4NuRf6mW3jI-cvmSWWrAHtfxAzZgvkaE', 7, FALSE, '', 0, TRUE),
(4, '{"chunk_size":256,"page_size":1000,"limit_rate":2,"access_token":"","refresh_token":"","device_id":"","delete_code":"","cloud_id":"","link_method":"download","type":"personal_new","auto_checkin":false}', 2, 'ctoken=72spQnw1U2b9BODAuxZOq6Di; __pus=b5c133f1e7bf9187773fee745d18eea0AAR5dquVjgs54Kb4nTWHpLVlA9vddIKF4UdeLkInY0L4aSlpuBbPV1uj+jb5+jQ5NaI1dx8VyhXO1m/HHUJAYL2W; __kp=dc1a89d0-b40c-11f1-8789-bde4a31c0829; __kps=AAQ7/BnmQR0PmZ9jQrVet9Sm; __ktd=CkStgY9Jr5PpjjD/PHAQSA==; __uid=AAQ7/BnmQR0PmZ9jQrVet9Sm; UDRIVE_TRANSFER_SESS=KWKs_0N3ww3mR-62i4c1w9Vfgsu7mt0Wuahr6GRpkyoQMWJM5pH8TEgn1WWEiH3gAcurifoUcA2-ZYM7xBEucecCicC-OUc5Iq6N2Dlh_TbSVTTH8EtxGb72io--NKTWX8g-TIXzJ5uY8bBq4YKyWhv8DQNLxYG6IDW0dS5-NIroWg05ijuenSAOO7hxDY06; __puus=e62028efe7c4e18a3256b1acb5c4669cAARyadpjYGpda0jZdHOn61c1i2sXsmtakoZ9KHZCgciYRvFXIUwHP917Ejp+xaa6lGtM21tbFUuRO/RpVG/2+lzPIE7buco+UjCekeI7PIkoCs3Hepnu8YwqZ7AyOHsZBY7/nW/ju7gdmJvCEmIvkUUGAhx63gPMhbnG7gzcz2IXmJOvv41Y5TTfyOFQ1c5LPKE=', FALSE, '0', TRUE, 'UC-TV', '', '', 'eyJhbGciOiJIUzI1NiIsIlR5cGUiOiJKd3QiLCJ0eXAiOiJKV1QifQ.eyJvcGVuSWQiOiJhM2RkMjgyOGU5MzY0ZmI3YTgzNzdmYTY4YzdhMzNlMiIsImV4cCI6MTgyMTM0NjI4OCwidG9rZW4iOiJiYjFkNTUxOTJhMWE0MTQyOTQ4ZWUzNTNkMmU2ZDM4NyJ9.kUVuE3lhKDIBC8kFZKY0v_K7FGwNjpRhW3gYZdFLztU', 8, FALSE, '', 0, TRUE);   
INSERT INTO "PUBLIC"."DRIVER_ACCOUNT" VALUES
(5, '{"chunk_size":256,"page_size":1000,"limit_rate":2,"access_token":"","refresh_token":"","device_id":"","delete_code":"","cloud_id":"","link_method":"download","type":"personal_new","auto_checkin":false}', 2, '', FALSE, '', TRUE, U&'\8fc5\96f7', 'wjj3565198', '', '', 6, FALSE, '+86 19832044555', 0, TRUE),
(6, '{"chunk_size":256,"page_size":1000,"limit_rate":2,"access_token":"","refresh_token":"","device_id":"","delete_code":"","cloud_id":"","link_method":"download","type":"personal_new","auto_checkin":true}', 2, '', FALSE, '-11', TRUE, U&'\5929\7ffc', '3565198wjj', '', '', 5, FALSE, '15027908866', 0, TRUE),
(7, '{"chunk_size":256,"page_size":1000,"limit_rate":2,"access_token":"","refresh_token":"","device_id":"","delete_code":"","cloud_id":"","link_method":"download","type":"personal_new","auto_checkin":false}', 2, '', FALSE, '', TRUE, U&'\79fb\52a8', '', '', 'cGM6MTk4MzIwNDQ1NTU6eDAyQ3V0Und8MXxSQ1N8MTc3OTk3ODc0OTM1N3xFZURlSl9obDVPS3RwRVhoRTMyYkU5Ml9TMHFXX0dUQjVBUEFob0ZYZGVPTUpUTEgySEs5ajdHSHFEYlV6a0ZFWGI5SnV0WEEzcGhxVEdqTGhZVU5scmMwTnNsLkRkRVAuYlJDZFpEbElmbFZWZ3B6enRlQmNiR1BTOXE1MFdMLjR2UW95eG9sNzhMdTVwRy5YYWdnWV81eVhkN1YzZVhiczk4ajI5X3dMRk0t', 4, FALSE, '', 0, TRUE),
(8, '{"chunk_size":256,"page_size":1000,"limit_rate":2,"access_token":"","refresh_token":"","device_id":"","delete_code":"","cloud_id":"","link_method":"download","type":"personal_new","auto_checkin":false}', 2, '', FALSE, '0', TRUE, '123', '3565198wjj', '', '', 3, FALSE, '19832044555', 0, TRUE),
(9, '{"chunk_size":256,"page_size":1000,"limit_rate":2,"access_token":"","refresh_token":"","device_id":"","delete_code":"","cloud_id":"","link_method":"download","type":"personal_new","auto_checkin":true}', 2, '122.bb8e747b3173daa675db01e0db61c12c.Y5SymVeSbopBalecCjt7nsP16AZMzLxxZQtxEXe.kvkSug', FALSE, '/', TRUE, U&'\767e\5ea6\7f51\76d8', '', '', '', 10, FALSE, '', 0, TRUE);       
CREATE INDEX "PUBLIC"."IDX_DRIVER_ACCOUNT_TYPE_USERNAME" ON "PUBLIC"."DRIVER_ACCOUNT"("TYPE" NULLS FIRST, "USERNAME" NULLS FIRST);             
CREATE INDEX "PUBLIC"."IDX_DRIVER_ACCOUNT_TYPE_NAME" ON "PUBLIC"."DRIVER_ACCOUNT"("TYPE" NULLS FIRST, "NAME" NULLS FIRST);     
CREATE CACHED TABLE "PUBLIC"."PLAYBACK_TOKEN"(
    "ID" INTEGER NOT NULL,
    "UID" INTEGER NOT NULL,
    "TOKEN" CHARACTER VARYING(64) NOT NULL,
    "NAME" CHARACTER VARYING(128),
    "CREATED_TIME" BIGINT NOT NULL,
    "LAST_USED_AT" BIGINT NOT NULL,
    "SYNC_SCOPE" CHARACTER VARYING(255)
);        
ALTER TABLE "PUBLIC"."PLAYBACK_TOKEN" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_12" PRIMARY KEY("ID");               
-- 1 +/- SELECT COUNT(*) FROM PUBLIC.PLAYBACK_TOKEN;           
INSERT INTO "PUBLIC"."PLAYBACK_TOKEN" VALUES
(1, 1, '7e68d8b547564bc68f4c8b8341bb41ad', 'wjjxqx', 1789863643999, 1789961086028, NULL);         
CREATE UNIQUE NULLS DISTINCT INDEX "PUBLIC"."UK_PB_TOKEN" ON "PUBLIC"."PLAYBACK_TOKEN"("TOKEN" NULLS FIRST);   
CREATE CACHED TABLE "PUBLIC"."MSUB_EPISODE"(
    "ID" INTEGER NOT NULL,
    "SUBSCRIPTION_ID" INTEGER NOT NULL,
    "SEASON" INTEGER NOT NULL,
    "NUMBER" INTEGER NOT NULL,
    "TITLE" CHARACTER VARYING(255),
    "AIR_TIME" BIGINT,
    "AIRED" BOOLEAN
);
ALTER TABLE "PUBLIC"."MSUB_EPISODE" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_47" PRIMARY KEY("ID"); 
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.MSUB_EPISODE;             
CREATE INDEX "PUBLIC"."IDX_MSUB_EPISODE_SUB" ON "PUBLIC"."MSUB_EPISODE"("SUBSCRIPTION_ID" NULLS FIRST);        
CREATE CACHED TABLE "PUBLIC"."MEDIA_SUBSCRIPTION_NOTIFY_TASK"(
    "ID" INTEGER NOT NULL,
    "SUBSCRIPTION_ID" INTEGER NOT NULL,
    "STATUS" CHARACTER VARYING(16) DEFAULT 'PENDING' NOT NULL,
    "ATTEMPTS" INTEGER DEFAULT 0,
    "NEXT_ATTEMPT_AT" BIGINT DEFAULT 0,
    "LAST_ERROR" CHARACTER VARYING(500) DEFAULT '',
    "CREATED_TIME" BIGINT NOT NULL,
    "SENT_TIME" BIGINT
);   
ALTER TABLE "PUBLIC"."MEDIA_SUBSCRIPTION_NOTIFY_TASK" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_1C" PRIMARY KEY("ID");               
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.MEDIA_SUBSCRIPTION_NOTIFY_TASK;           
CREATE INDEX "PUBLIC"."IDX_MSUB_NOTIFY_DUE" ON "PUBLIC"."MEDIA_SUBSCRIPTION_NOTIFY_TASK"("STATUS" NULLS FIRST, "NEXT_ATTEMPT_AT" NULLS FIRST); 
CREATE INDEX "PUBLIC"."IDX_MSUB_NOTIFY_SUB" ON "PUBLIC"."MEDIA_SUBSCRIPTION_NOTIFY_TASK"("SUBSCRIPTION_ID" NULLS FIRST);       
CREATE CACHED TABLE "PUBLIC"."MEDIA_SUBSCRIPTION_EVENT"(
    "ID" INTEGER NOT NULL,
    "SUBSCRIPTION_ID" INTEGER NOT NULL,
    "TYPE" CHARACTER VARYING(32) NOT NULL,
    "DETAIL" CHARACTER VARYING,
    "CREATED_TIME" BIGINT NOT NULL
);   
ALTER TABLE "PUBLIC"."MEDIA_SUBSCRIPTION_EVENT" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_8D" PRIMARY KEY("ID");     
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.MEDIA_SUBSCRIPTION_EVENT; 
CREATE INDEX "PUBLIC"."IDX_MSUB_EVENT" ON "PUBLIC"."MEDIA_SUBSCRIPTION_EVENT"("SUBSCRIPTION_ID" NULLS FIRST, "CREATED_TIME" NULLS FIRST);      
CREATE CACHED TABLE "PUBLIC"."USER_PREFERENCE"(
    "ID" INTEGER NOT NULL,
    "UID" INTEGER NOT NULL,
    "CONFIG" CHARACTER VARYING,
    "UPDATED_TIME" BIGINT
);            
ALTER TABLE "PUBLIC"."USER_PREFERENCE" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_D7" PRIMARY KEY("ID");              
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.USER_PREFERENCE;          
CREATE UNIQUE NULLS DISTINCT INDEX "PUBLIC"."UK_USER_PREFERENCE_UID" ON "PUBLIC"."USER_PREFERENCE"("UID" NULLS FIRST);         
CREATE CACHED TABLE "PUBLIC"."MEDIA_METADATA"(
    "ID" INTEGER NOT NULL,
    "PROVIDER" CHARACTER VARYING(16) NOT NULL,
    "META_ID" CHARACTER VARYING(64) NOT NULL,
    "SEASON" INTEGER NOT NULL,
    "STATUS" CHARACTER VARYING(16) NOT NULL,
    "PAYLOAD" CHARACTER VARYING NOT NULL,
    "FETCH_TIME" BIGINT NOT NULL
);               
ALTER TABLE "PUBLIC"."MEDIA_METADATA" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_D9" PRIMARY KEY("ID");               
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.MEDIA_METADATA;           
CREATE UNIQUE NULLS DISTINCT INDEX "PUBLIC"."IDX_MEDIA_META_KEY" ON "PUBLIC"."MEDIA_METADATA"("PROVIDER" NULLS FIRST, "META_ID" NULLS FIRST, "SEASON" NULLS FIRST);            
CREATE CACHED TABLE "PUBLIC"."MEDIA_SUBSCRIPTION_RESOURCE"(
    "ID" INTEGER NOT NULL,
    "SUBSCRIPTION_ID" INTEGER NOT NULL,
    "LINK" CHARACTER VARYING(1024) NOT NULL,
    "TYPE" INTEGER,
    "SOURCE" CHARACTER VARYING(16),
    "TITLE" CHARACTER VARYING(255),
    "PASSWORD" CHARACTER VARYING(128),
    "EPISODES_FOUND" INTEGER,
    "SCORE" INTEGER,
    "CHECKED_TIME" BIGINT,
    "CREATED_TIME" BIGINT NOT NULL,
    "MOUNT_PATH" CHARACTER VARYING(512),
    "SHARE_ID" INTEGER,
    "STATE" CHARACTER VARYING(16) DEFAULT 'CANDIDATE' NOT NULL,
    "LINK_HASH" CHARACTER VARYING(64),
    "PINNED" BOOLEAN,
    "START_EPISODE" INTEGER,
    "SEASON_STARTS" CHARACTER VARYING(120),
    "FAIL_KIND" CHARACTER VARYING(16)
);               
ALTER TABLE "PUBLIC"."MEDIA_SUBSCRIPTION_RESOURCE" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_BF" PRIMARY KEY("ID");  
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.MEDIA_SUBSCRIPTION_RESOURCE;              
CREATE UNIQUE NULLS DISTINCT INDEX "PUBLIC"."UK_MSUB_RESOURCE" ON "PUBLIC"."MEDIA_SUBSCRIPTION_RESOURCE"("SUBSCRIPTION_ID" NULLS FIRST, "LINK_HASH" NULLS FIRST);              
CREATE CACHED TABLE "PUBLIC"."MSUB_EPISODE_SOURCE"(
    "ID" INTEGER NOT NULL,
    "EPISODE_ID" INTEGER NOT NULL,
    "RESOURCE_ID" INTEGER NOT NULL,
    "REL_PATH" CHARACTER VARYING(512) NOT NULL,
    "FILE_SIZE" BIGINT,
    "STATE" CHARACTER VARYING(16) DEFAULT 'LISTED' NOT NULL,
    "SUCCESS_COUNT" INTEGER DEFAULT 0,
    "FAIL_COUNT" INTEGER DEFAULT 0,
    "LAST_VERIFIED_TIME" BIGINT
);       
ALTER TABLE "PUBLIC"."MSUB_EPISODE_SOURCE" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_B9" PRIMARY KEY("ID");          
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.MSUB_EPISODE_SOURCE;      
CREATE INDEX "PUBLIC"."IDX_MSUB_ES_RESOURCE" ON "PUBLIC"."MSUB_EPISODE_SOURCE"("RESOURCE_ID" NULLS FIRST);     
CREATE CACHED TABLE "PUBLIC"."DEAD_LINK"(
    "ID" INTEGER NOT NULL,
    "LINK" CHARACTER VARYING(1024) NOT NULL,
    "REASON" CHARACTER VARYING(255),
    "FAIL_COUNT" INTEGER DEFAULT 0,
    "TIME" BIGINT NOT NULL
);       
ALTER TABLE "PUBLIC"."DEAD_LINK" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_49" PRIMARY KEY("ID");    
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.DEAD_LINK;
CREATE UNIQUE NULLS DISTINCT INDEX "PUBLIC"."UK_DEAD_LINK_LINK" ON "PUBLIC"."DEAD_LINK"("LINK" NULLS FIRST);   
CREATE CACHED TABLE "PUBLIC"."SUBSCRIPTION"(
    "ID" INTEGER NOT NULL,
    "NAME" CHARACTER VARYING(255),
    "OVERRIDE" CHARACTER VARYING,
    "SID" CHARACTER VARYING(255),
    "SORT" CHARACTER VARYING(255),
    "URL" CHARACTER VARYING(255),
    "OWNER_UID" INTEGER DEFAULT 0 NOT NULL
);              
ALTER TABLE "PUBLIC"."SUBSCRIPTION" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_9E" PRIMARY KEY("ID"); 
-- 7 +/- SELECT COUNT(*) FROM PUBLIC.SUBSCRIPTION;             
INSERT INTO "PUBLIC"."SUBSCRIPTION" VALUES
(1, U&'\9ed8\8ba4', NULL, '0', NULL, NULL, 0),
(2, U&'\996d\592a\786c', NULL, '1', NULL, U&'http://www.\996d\592a\786c.com/tv', 0),
(3, U&'\83dc\59ae\4e1d', U&'{\000a  "lives" : [ {\000a    "name" : "\6dd8\4e2b\4e2b",\000a    "type" : 1,\000a    "url" : "https://www.xinsite.top/tv.m3u",\000a    "playerType" : 2,\000a    "ua" : "okHttp/Mod-1.5.0.0",\000a    "epg" : "https://gitee.com/taksssss/tv/raw/main/epg/112114.xml.gz?ch={name}&date={date}",\000a    "timeout" : 0,\000a    "boot" : false,\000a    "pass" : false\000a  } ],\000a  "sites" : [ {\000a    "key" : "taoyaya",\000a    "name" : "\6781\5ba2\5f71\89c6",\000a    "type" : 1,\000a    "api" : "https://vip.xinsite.top//tvbox_proxy.php/provide/vod/at/json/",\000a    "searchable" : 1,\000a    "quickSearch" : 1,\000a    "filterable" : 1,\000a    "changeable" : 1,\000a    "style" : {\000a      "type" : "oval"\000a    },\000a    "order" : 0\000a  } ]\000a}', '2', NULL, U&'https://tv.\83dc\59ae\4e1d.top', 0),
(4, 'PG', '', 'pg', NULL, '/pg/jsm.json', 0),
(5, 'OK', NULL, 'ok', NULL, 'http://ok321.top/ok', 0),
(6, U&'\771f\5fc3', NULL, 'zx', NULL, '/zx/FongMi.json', 0),
(7, U&'\6f47\6d12', NULL, 'xs', NULL, '/static/xs/TVBoxOSC/tvbox/api.json', 0);         
CREATE INDEX "PUBLIC"."IDX_SUBSCRIPTION_URL" ON "PUBLIC"."SUBSCRIPTION"("URL" NULLS FIRST);    
CREATE CACHED TABLE "PUBLIC"."MEDIA_SUBSCRIPTION"(
    "ID" INTEGER NOT NULL,
    "UID" INTEGER NOT NULL,
    "NAME" CHARACTER VARYING(255) NOT NULL,
    "KEYWORD" CHARACTER VARYING(255),
    "SEASON" INTEGER,
    "DOUBAN_ID" INTEGER,
    "FILTER_CONFIG" CHARACTER VARYING,
    "MODE" CHARACTER VARYING(16) DEFAULT 'FOLLOW',
    "ACCOUNT_ID" INTEGER,
    "MOUNT_PATH" CHARACTER VARYING(512),
    "SHARE_ID" INTEGER,
    "EXPECTED_EPISODES" INTEGER,
    "CURRENT_EPISODES" INTEGER,
    "MAX_EPISODE" INTEGER,
    "STATUS" CHARACTER VARYING(16) DEFAULT 'ACTIVE' NOT NULL,
    "STALL_COUNT" INTEGER DEFAULT 0,
    "CHECK_INTERVAL_HOURS" INTEGER,
    "NEXT_CHECK_TIME" BIGINT,
    "LAST_CHECK_TIME" BIGINT,
    "CREATED_TIME" BIGINT NOT NULL,
    "UPDATED_TIME" BIGINT,
    "META_PROVIDER" CHARACTER VARYING(16),
    "META_ID" CHARACTER VARYING(64),
    "OFFICIAL_EPISODES" INTEGER,
    "OFFICIAL_TOTAL" INTEGER,
    "OFFICIAL_STATUS" CHARACTER VARYING(16),
    "NEXT_AIR_TIME" BIGINT,
    "META_SYNC_TIME" BIGINT,
    "ACCOUNT_IDS" CHARACTER VARYING,
    "SCHEDULE" CHARACTER VARYING,
    "CROSS_DRIVE" BOOLEAN DEFAULT FALSE,
    "ALIASES" CHARACTER VARYING,
    "MAIN_DRIVES" CHARACTER VARYING(64),
    "COVER_URL" CHARACTER VARYING(512),
    "CAUGHT_UP_EPISODE" INTEGER,
    "TG_MESSAGE_ID" BIGINT,
    "TG_CHAT_ID" CHARACTER VARYING(64),
    "CUSTOM_AIR_CLOCK" CHARACTER VARYING(5),
    "SEASON_START_EPISODE" INTEGER,
    "MANUAL_TOTAL_EPISODES" INTEGER,
    "MAGNET_OFFLINE" BOOLEAN DEFAULT FALSE,
    "CUSTOM_KEYWORDS" CHARACTER VARYING,
    "AIR_WEEKDAYS" CHARACTER VARYING(13),
    "SELF_SHARE" BOOLEAN DEFAULT FALSE
);       
ALTER TABLE "PUBLIC"."MEDIA_SUBSCRIPTION" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_E2" PRIMARY KEY("ID");           
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.MEDIA_SUBSCRIPTION;       
CREATE INDEX "PUBLIC"."IDX_MSUB_UID" ON "PUBLIC"."MEDIA_SUBSCRIPTION"("UID" NULLS FIRST);      
CREATE INDEX "PUBLIC"."IDX_MSUB_SCHEDULE" ON "PUBLIC"."MEDIA_SUBSCRIPTION"("STATUS" NULLS FIRST, "NEXT_CHECK_TIME" NULLS FIRST);               
ALTER TABLE "PUBLIC"."MSUB_EPISODE_SOURCE" ADD CONSTRAINT "PUBLIC"."UK_MSUB_EPISODE_SOURCE" UNIQUE NULLS DISTINCT ("EPISODE_ID", "RESOURCE_ID");               
ALTER TABLE "PUBLIC"."MSUB_EPISODE" ADD CONSTRAINT "PUBLIC"."UK_MSUB_EPISODE" UNIQUE NULLS DISTINCT ("SUBSCRIPTION_ID", "SEASON", "NUMBER");   
ALTER TABLE "PUBLIC"."ALIST_ALIAS" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_4AC" UNIQUE NULLS DISTINCT ("PATH");    
ALTER TABLE "PUBLIC"."MSUB_EPISODE_FALLBACK" ADD CONSTRAINT "PUBLIC"."UK_MSUB_EPISODE_FALLBACK" UNIQUE NULLS DISTINCT ("SUBSCRIPTION_ID", "EPISODE");          
ALTER TABLE "PUBLIC"."TMDB_META" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_685" UNIQUE NULLS DISTINCT ("PATH");      
ALTER TABLE "PUBLIC"."CONFIG_FILE" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_83" UNIQUE NULLS DISTINCT ("PATH");     
ALTER TABLE "PUBLIC"."SESSION" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_A11" UNIQUE NULLS DISTINCT ("TOKEN");       
ALTER TABLE "PUBLIC"."X_USER" ADD CONSTRAINT "PUBLIC"."UK_X_USER_USERNAME" UNIQUE NULLS DISTINCT ("USERNAME"); 
ALTER TABLE "PUBLIC"."SHARE" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_4B3" UNIQUE NULLS DISTINCT ("PATH");          
